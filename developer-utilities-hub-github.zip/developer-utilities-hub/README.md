# Developer Utilities Hub

منصة Next.js (App Router) لأدوات المطورين، أدوات تعمل بالكامل داخل المتصفح.

الحالة الحالية: **JSON Formatter & Validator** + **JSON → TypeScript** + **قسم المقالات** + **لوحة تحكم المدير**.

## التشغيل

```bash
npm install
npm run dev
```

ثم افتح `http://localhost:3000`.

## البناء والفحص

```bash
npm run typecheck   # tsc --noEmit
npm run lint        # eslint (flat config)
npm run build       # build إنتاجي
npm start
```

## متغيرات البيئة

انسخ `.env.example` إلى `.env.local` ثم عدّل القيم:

| المتغير | مطلوب | الوصف |
| --- | --- | --- |
| `NEXT_PUBLIC_SITE_URL` | نعم | النطاق الحقيقي (metadata وsitemap وrobots وOpenGraph) |
| `NEXT_PUBLIC_CONTACT_EMAIL` | نعم | بريد المالك والتواصل |
| `NEXT_PUBLIC_OWNER_NAME` | لا | اسم المالك الظاهر في About/Privacy/Footer |
| `NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION` | لا | رمز التحقق من Google Search Console |
| `NEXT_PUBLIC_ADSENSE_CLIENT` | لا | `ca-pub-XXXXXXXXXXXXXXXX` — لتفعيل AdSense |
| `NEXT_PUBLIC_ADSENSE_SLOT` | لا | رقم وحدة إعلانية، مثال `1234567890` |
| `ADSENSE_CLIENT` | لا | `pub-XXXXXXXXXXXXXXXX` — يُستخدم في `app/ads.txt/route.ts` |
| `ADMIN_PASSWORD_HASH` | للوحة المدير | هاش كلمة المرور بصيغة `salt:digest` |
| `ADMIN_SESSION_SECRET` | للوحة المدير | سر توقيع الجلسات (ولّده عشوائياً) |
| `UPSTASH_REDIS_REST_URL` | للنشر | رابط Upstash لتخزين دائم على Netlify |
| `UPSTASH_REDIS_REST_TOKEN` | للنشر | رمز Upstash |
| `MAINTENANCE` | لا | `1` لإغلاق الموقع بـ 503 على الخادم |

ملاحظة: الصفحات تُبنى static، أما مسارات `/api/*` و`/admin` فتُنفَّذ على الخادم عند النشر.
أي تغيير في متغيرات `NEXT_PUBLIC_*` يحتاج إعادة بناء (`npm run build`) ثم إعادة النشر.

## البنية

- `app/` صفحات App Router + SEO (metadata, sitemap, robots, manifest, ads.txt, OG image, 404, error)
- `components/` مكونات قابلة لإعادة الاستخدام (Client components تُوسم بـ `"use client"`)
- `lib/site.ts` إعدادات الموقع، المالك، AdSense، وقائمة الأدوات (مصدر واحد للحقيقة)
- `lib/json-tools.ts` منطق تنسيق/تصغير/فرز/تحليل JSON (نقي، بدون React)
- `lib/json-to-typescript.ts` منطق توليد واجهات TypeScript من JSON (نقي)
- `components/JsonFormatter.tsx` و `components/JsonToTypescript.tsx` الأدوات

### إضافة أداة جديدة

1. أضف عنصراً إلى `tools` في `lib/site.ts` (المسار، العنوان، الوصف، الكلمات المفتاحية، الميزات، الأسئلة).
2. أنشئ `app/tools/<slug>/page.tsx` مع `metadata` وJSON-LD (انظر `app/tools/json-formatter/page.tsx`).
3. سجّل الأيقونة في `components/ToolIcon.tsx` (اختياري، الافتراضي `braces`).
4. الصفحة `app/tools` والأدوات الشائعة في `Header`/`Footer` تتحدث تلقائياً من `lib/site.ts`.

## المقالات

المقالات في `lib/articles.ts` كمحتوى منظّم (كتل: فقرات، عناوين، قوائم، كود، جداول، صناديق ملاحظة).

- أضف عنصراً جديداً إلى `articles` ثم شغّل البناء — المسار `generateStaticParams` يبنيهم تلقائياً.
- `cover` يستخدم `https://picsum.photos/seed/<seed>/1600/900` (صور ثابتة وقابلة للتبديل).
  لاستبدالها بصور Unsplash محددة، غيّر `cover` إلى رابط مباشر مثل
  `https://images.unsplash.com/photo-<id>?w=1600&q=80&auto=format&fit=crop`
  (النطاق مُصرَّح به مسبقاً في `images.remotePatterns`).
- كل مقال ينشر JSON-LD من نوع `BlogPosting` تلقائياً، ويدخل في `sitemap.xml` عبر `app/sitemap.ts`.
- `theme` يحدد هوية المقال (لون + رسمة) من `lib/page-themes.ts`.

## هوية كل صفحة

`components/AutoPageSkin.tsx` في `app/layout.tsx` يختار هوية الصفحة من المسار تلقائياً:

| المسار | الهوية | الرسمة |
| --- | --- | --- |
| `/` | زمردي | `grid` |
| `/tools` | أزرق | `circuit` |
| `/tools/json-formatter` | بنفسجي | `braces` |
| `/tools/json-to-typescript` | كهرماني | `layers` |
| `/articles` | فيروزي | `waves` |
| `/about` | برتقالي | `orbit` |
| `/contact` | وردي | `waves` |
| `/privacy` و`/terms` و`/cookies` و`/disclaimer` | سماوي | `layers` |

التعريفات في `lib/page-themes.ts` (لون فاتح + لون داكن لكل هوية)، والرسوم في `components/PageArt.tsx`.
لإضافة هوية جديدة: أضف مدخلاً في `pageThemes` ثم حالة في `themeFor` داخل `AutoPageSkin.tsx`.

## لوحة تحكم المدير

المسار: `/admin` (لا يوجد له رابط في الموقع، وهو `noindex`).

### التفعيل

```bash
# 1) ولّد هاش كلمة المرور
node scripts/hash-admin-password.mjs "كلمة-المرور-القوية"

# 2) ضع الناتج في .env.local أو في Netlify
ADMIN_PASSWORD_HASH=<salt>:<digest>
ADMIN_SESSION_SECRET=<32+ حرف عشوائي>
```

بدون `ADMIN_PASSWORD_HASH` أو `ADMIN_PASSWORD` تُرجع مسارات الإدارة `404` ويُعطَّل `/admin` كلياً.

### التخزين

يختار `lib/admin/store.ts` المحرك تلقائياً:

- **Upstash** عند وجود `UPSTASH_REDIS_REST_URL` + `UPSTASH_REDIS_REST_TOKEN` — وهو المطلوب على Netlify.
- **ملف محلي** `data/store.json` في غير ذلك (للتطوير فقط، ومُستثنى في `.gitignore`).

### الأمان

- الجلسة cookie موقّعة بـ HMAC اسمها `duh_admin`، صلاحيتها 7 أيام و`httpOnly` + `sameSite=lax`.
- `middleware.ts` يفحص وجود الكوكي فقط ويحوّل `/admin` إلى `/admin/login`؛ التحقق الحقيقي في طبقة API.
- تحديد المعدل: 5 محاولات دخول لكل 15 دقيقة لكل عنوان IP.
- لا يوجد رابط للوحة في `Header` أو `Footer`.

### المسارات البرمجية

| المسار | الوظيفة |
| --- | --- |
| `POST /api/admin/login` | تسجيل الدخول وضبط الكوكي |
| `POST /api/admin/logout` | إنهاء الجلسة |
| `GET /api/admin/session` | حالة الدخول |
| `GET/POST /api/admin/settings` | إعدادات الموقع (المالك، الإعلان، الصيانة، الإعلانات، التتبع) |
| `GET/POST /api/admin/tools` | إظهار/إخفاء الأدوات وعناوينها المخصصة |
| `GET/POST /api/admin/stats` | إحصائيات الزيارات / تصفيرها |
| `GET /api/config` | الإعدادات العامة (يقرأها `SiteConfigProvider`) |
| `POST /api/track` | تسجيل زيارة (يستثني `/admin` و`/api`) |

### الصيانة

- من اللوحة: يحجب الزوار في متصفحهم فقط عبر `SiteConfigProvider`.
- على الخادم: `MAINTENANCE=1` ثم إعادة نشر، فيعيد `middleware.ts` حالة `503` لكل الزوار
  (مع استثناء صفحات قانونية وصفحة الدخول ولوحة المدير).

## التصميم

- Tailwind CSS v4 عبر `@import "tailwindcss"` وCSS variables في `app/globals.css`.
- الهوية: أخضر زمردي. الوضع الفاتح/الداكن عبر `.dark` + `ThemeProvider` مع خيار "حسب النظام".
- الخلفية: تدرّج متحرك + شبكة، تُعطَّل تلقائياً مع `prefers-reduced-motion`.
- لإضافة خطوط أو صور خارجية، راجع `app/globals.css` (`.app-bg`, `--glow-*`, `--grid-line`).

## الإعلانات

- `components/AdSlot.tsx` هو المكوّن الوحيد المستخدم في الصفحات:
  - إذا لم يُضبط `NEXT_PUBLIC_ADSENSE_CLIENT` + `NEXT_PUBLIC_ADSENSE_SLOT` يعرض مساحة بديلة.
  - بعد ضبطهما يعرض وحدة AdSense عبر `components/AdSenseSlot.tsx`.
- `components/ConsentProvider.tsx` يعرض شريط موافقة على ملفات تعريف الارتباط، ولا يُحمَّل AdSense إلا بعد الموافقة (يُحفظ القرار في `localStorage` بمفتاح `duh-ads-consent`).
- `app/ads.txt/route.ts` يولّد `ads.txt` من `ADSENSE_CLIENT` عند النشر على `/ads.txt`.

## قبل النشر ( checklists )

### 1) أساسيات
1. `NEXT_PUBLIC_SITE_URL` = نطاقك الحقيقي (HTTPS).
2. `NEXT_PUBLIC_CONTACT_EMAIL` = بريدك.
3. `NEXT_PUBLIC_OWNER_NAME` = اسمك (يظهر كمالك في About/Privacy/Footer).
4. `npm run check && npm run build` ثم انشر مجلد `.next` أو اربطه بـ Vercel/Netlify.
5. تأكد من عمل: `https://yourdomain.com/sitemap.xml` و `/robots.txt` و `/ads.txt` و `/icon.svg` و `/opengraph-image`.

### 2) Google Search Console
1. أضف الموقع كخاصية `Domain` (يفضل) وأضف `robots.txt` إلى الـSitemap.
2. ضع `NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION=<token>` لإخراج وسم `google-site-verification` تلقائياً.

### 3) AdSense (بعد موافقة Google)
1. فعّل "قانونية موافقة المستخدم" (UMP) من لوحة AdSense وأضف روابط الخصوصية والكوكيز.
2. ضع `ADSENSE_CLIENT=pub-...` و`NEXT_PUBLIC_ADSENSE_CLIENT=ca-pub-...` و`NEXT_PUBLIC_ADSENSE_SLOT=<slot>` ثم أعد البناء.
3. تأكد أن `/ads.txt` يعرض سطر `google.com, pub-..., DIRECT, f08c47fec0942fa0` في لوحة AdSense (حالة Approved).
4. استبدل مواضع `AdSlot` بعدد كافٍ من الوحدات (3 على الأقل لكل صفحة) ولا تضع إعلانات قريبة من زر تنزيل.
4. لا تستخدم أنماطاً مضللة، ولا تكدّس وحدات إعلانية، ولا تضع إعلانات قريبة من أزرار التنزيل.

### 5) لوحة المدير على Netlify
1. أنشئ قاعدة Redis مجانية في Upstash وانسخ `UPSTASH_REDIS_REST_URL` و`UPSTASH_REDIS_REST_TOKEN` إلى إعدادات Netlify (بدونها تُفقد الإعدادات والإحصائيات).
2. `ADMIN_PASSWORD_HASH` و`ADMIN_SESSION_SECRET` في متغيرات Netlify (وليس `NEXT_PUBLIC_`، حتى لا تُكشف في المتصفح).
3. تحقّق أن `/admin` يعيد التوجيه إلى `/admin/login`، وأن `/api/admin/settings` يعيد `401` بدون جلسة.
4. ⚠️ لا تضع كلمة المرور نفسها في `ADMIN_PASSWORD` في الإنتاج؛ استخدم الهاش فقط.

### 4) محتوى وسياسات
1. راجع نصوص: الخصوصية، ملفات تعريف الارتباط، الشروط، إخلاء المسؤولية، من نحن، اتصل بنا.
2. وجود الصفحات لا يضمن قبول AdSense؛ القرار بيد Google.
3. راجع النصوص مع مختص إذا كان جمهورك في دول تطبّق GDPR/CCPA.
4. لا تنشر أدوات تنتهك حقوق طرف آخر، واذكر مصادر الأدوات غير الأصلية.
