export type SortMode = "none" | "asc" | "desc" | "size";

export type ParseError = {
  message: string;
  line: number;
  column: number;
  position: number | null;
};

export function describeParseError(error: unknown, input: string): ParseError {
  const raw = error instanceof Error ? error.message : "JSON غير صالح.";
  const match = raw.match(/position\s+(\d+)/i);
  if (!match) {
    return { message: raw, line: 0, column: 0, position: null };
  }
  const position = Number(match[1]);
  const before = input.slice(0, position);
  const line = before.split("\n").length;
  const column = position - before.lastIndexOf("\n");
  return { message: raw, line, column, position };
}

function sizeOf(value: unknown): number {
  try {
    return JSON.stringify(value)?.length ?? 0;
  } catch {
    return 0;
  }
}

function sortDeep(value: unknown, mode: SortMode): unknown {
  if (Array.isArray(value)) return value.map(item => sortDeep(item, mode));
  if (value && typeof value === "object") {
    const entries = Object.entries(value as Record<string, unknown>).map(([key, item]) => [
      key,
      sortDeep(item, mode)
    ]) as [string, unknown][];

    entries.sort((a, b) => {
      if (mode === "asc") return a[0].localeCompare(b[0], "en");
      if (mode === "desc") return b[0].localeCompare(a[0], "en");
      return sizeOf(b[1]) - sizeOf(a[1]);
    });

    return Object.fromEntries(entries);
  }
  return value;
}

export function stringifyJson(value: unknown, indent: number | string, sort: SortMode): string {
  const prepared = sort === "none" ? value : sortDeep(value, sort);
  return JSON.stringify(prepared, null, indent);
}

export type JsonStats = {
  bytes: number;
  keys: number;
  values: number;
  depth: number;
  objects: number;
  arrays: number;
  strings: number;
  numbers: number;
  booleans: number;
  nulls: number;
};

export function analyzeJson(value: unknown, raw: string): JsonStats {
  const stats: JsonStats = {
    bytes: new Blob([raw]).size,
    keys: 0,
    values: 0,
    depth: 0,
    objects: 0,
    arrays: 0,
    strings: 0,
    numbers: 0,
    booleans: 0,
    nulls: 0
  };

  const walk = (node: unknown, depth: number) => {
    stats.depth = Math.max(stats.depth, depth);
    stats.values += 1;

    if (Array.isArray(node)) {
      stats.arrays += 1;
      node.forEach(item => walk(item, depth + 1));
      return;
    }

    if (node && typeof node === "object") {
      stats.objects += 1;
      for (const item of Object.values(node as Record<string, unknown>)) {
        stats.keys += 1;
        walk(item, depth + 1);
      }
      return;
    }

    if (typeof node === "string") stats.strings += 1;
    else if (typeof node === "number") stats.numbers += 1;
    else if (typeof node === "boolean") stats.booleans += 1;
    else stats.nulls += 1;
  };

  walk(value, 0);
  return stats;
}

export function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes.toLocaleString("en-US")} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

export function escapeJsonString(value: unknown): string {
  return JSON.stringify(value)
    .replace(/^"|"$/g, "")
    .replace(/\\"/g, '"')
    .replace(/\\n/g, "\\n");
}
