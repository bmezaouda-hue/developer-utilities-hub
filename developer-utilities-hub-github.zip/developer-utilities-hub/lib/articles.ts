export type ArticleBlock =
  | { type: "p"; text: string }
  | { type: "h2"; text: string; id: string }
  | { type: "h3"; text: string; id: string }
  | { type: "ul"; items: string[] }
  | { type: "ol"; items: string[] }
  | { type: "code"; lang: string; file?: string; code: string }
  | { type: "callout"; tone: "tip" | "warn" | "info"; title: string; text: string }
  | { type: "table"; head: string[]; rows: string[][] };

export type Article = {
  slug: string;
  title: string;
  description: string;
  category: string;
  publishedAt: string;
  updatedAt?: string;
  readingMinutes: number;
  keywords: string;
  cover: string;
  coverAlt: string;
  theme: string;
  excerpt: string;
  body: ArticleBlock[];
};

const cover = (seed: string) => `https://picsum.photos/seed/${seed}/1600/900`;

export const articles: Article[] = [
  {
    slug: "json-errors-common-causes",
    title: "أخطاء JSON الشائعة: لماذا يفشل التحليل وكيف تصلحها بسرعة",
    description:
      "دليل عملي لأشهر أخطاء JSON وكيفية تحديد موضعها بدقة: الفواصل الزائدة، الاقتباس المفرد، التعليقات، القيم غير القياسية، وأخطاء الأرقام.",
    category: "JSON",
    publishedAt: "2026-02-11",
    updatedAt: "2026-03-02",
    readingMinutes: 9,
    keywords: "json errors invalid json json parse error أخطاء json تصحيح json",
    cover: cover("json-braces-code"),
    coverAlt: "أقواس ومحارف برمجية على شاشة",
    theme: "formatter",
    excerpt:
      "رسالة الخطأ في JSON نادراً ما تكون غامضة؛ هي ببساطة ناقصة سياق. في هذا الدليل نأخذ كل خطأ شائع ونحلله سطراً بسطر لتعرف أين المشكلة فعلاً.",
    body: [
      {
        type: "p",
        text: "كل من عمل مع واجهات برمجية صادف رسالة خطأ واحدة لا توضّح موضع المشكلة: «Unexpected token». المشكلة أن JSON صارم جداً، والملفات في المشاريع الحقيقية يكتبها أناس وأدوات مختلفة. في هذا الدليل نأخذ الأخطاء الأكثر تكراراً، ونفسر سبب كل خطأ، وكيف تصل إلى موضعه الصحيح بدل التخمين."
      },
      {
        type: "callout",
        tone: "info",
        title: "قاعدة ذهبية",
        text: "JSON ليس JavaScript. كل ما هو صالح في JavaScript لا يمكن بالضرورة وضعه داخل JSON. أشهر ثلاثة مصادر للمشاكل هي التعليقات، والاقتباس المفرد، والفواصل الزائدة."
      },
      { type: "h2", id: "trailing-comma", text: "الفاصلة الزائدة" },
      {
        type: "p",
        text: "الفاصلة الزائدة في نهاية كائن أو مصفوفة قبل القوس الختامي خطأ قاتل. JSON صارم هنا ولا يسامح، بينما معظم لغات البرمجة تسمح بها:"
      },
      {
        type: "code",
        lang: "json",
        file: "broken.json",
        code: `{
  "name": "Sara",
  "roles": ["admin", "editor",],
}`
      },
      {
        type: "p",
        text: "السبب واضح: بعد قيمة \"editor\" توجد فاصلة، ثم يأتي القوس الختامي مباشرة. عند التحليل ستحصل على شيء كهذا:"
      },
      {
        type: "code",
        lang: "text",
        file: "المخرجات",
        code: `SyntaxError: Unexpected token ']'
  "roles": ["admin", "editor",]
                                 ^`
      },
      {
        type: "callout",
        tone: "tip",
        title: "كيف تحدد الموضع بدقة",
        text: "في معظم المحللات، رقم الموضع في رسالة الخطأ يشير إلى نهاية الجزء الذي فشلت قراءته، وقد يكون قبل الحرف الخاطئ ببضع مواضع. قسّم الملف إلى أقسام صغيرة لتحديد المنطقة، أو استخدم أداة التنسيق التي ترفع رقم السطر والعمود مباشرة."
      },
      { type: "h2", id: "single-quotes", text: "الاقتباس المفرد والقيم غير المحمية" },
      {
        type: "p",
        text: "JSON يفرض الاقتباس المزدوج حول كل مفتاح وكل قيمة نصية. استخدام علامة مفردة بدل المزدوج شائع جداً، خاصة في الملفات التي يولّدها بعض الأدوات:"
      },
      {
        type: "code",
        lang: "json",
        file: "broken.json",
        code: `{
  'name': 'Sara',
  active: true
}`
      },
      {
        type: "ul",
        items: [
          "السطر الأول يستخدم علامة اقتباس مفردة للمفتاح والقيمة، وصحيح أن يكون مزدوجاً.",
          "الحقل active منطقي، ولذلك لا يحتاج علامات اقتباس حوله.",
          "القيم المنطقية true و false و null هي الاستثناء الوحيد الذي لا يحتاج اقتباساً."
        ]
      },
      {
        type: "callout",
        tone: "warn",
        title: "خطأ يخفيه التنسيق الجيد",
        text: "إذا كان حول حقل نصي مسافة قبل علامة الاقتباس أو بعدها، فإن القيم التي تراها في المحرر ستبدو سليمة بينما النتيجة تكون مختلفة تماماً. تأكد دائماً من عدم وجود مسافة داخل علامات الاقتباس."
      },
      { type: "h2", id: "comments", text: "التعليقات غير مسموح بها" },
      {
        type: "p",
        text: "لا يوجد تعليق بسطر واحد ولا تعليق متعدد الأسطر داخل JSON. هذا يختلف عن ملفات إعداد مثل tsconfig.json التي تسمح بالتعليقات، لكنه ينطبق على أي ملف .json عادي وعلى استجابات الـ API:"
      },
      {
        type: "code",
        lang: "json",
        file: "broken.json",
        code: `{
  // اسم المستخدم
  "username": "sara"
}`
      },
      {
        type: "p",
        text: "إذا كان لديك ملف يحتوي تعليقات، فالحل العملي هو إزالتها قبل الإرسال.Albديل الأنظف هو نقل التعليق إلى حقل يحمله:"
      },
      {
        type: "code",
        lang: "json",
        file: "valid.json",
        code: `{
  "_comment": "اسم المستخدم",
  "username": "sara"
}`
      },
      { type: "h2", id: "non-standard-values", text: "قيم غير قياسية: NaN و Infinity و undefined" },
      {
        type: "p",
        text: "هذه القيم موجودة في JavaScript لكنها غير موجودة في معيار JSON. محاولة وضعها داخل ملف JSON تنتج إما خطأ مفاجئاً أو تحويلاً صامتاً: "
      },
      {
        type: "code",
        lang: "javascript",
        file: "ما الذي يحدث",
        code: `const data = { score: NaN, count: Infinity, extra: undefined };

// عند التحويل إلى JSON:
// { "score": null, "count": null }  <- تحويل إلى null
// الحقل extra يختفي تماماً`
      },
      {
        type: "ul",
        items: [
          "القيمة NaN تتحول إلى null عند التحويل. إذا كان null غير مقبول في نظامك، استخدم قيمة بديلة مثل صفر أو سلسلة نصية.",
          "القيمة undefined تُحذف من الناتج تلقائياً، فإذا كان الحقل إجبارياً فسيختفي بصمت دون أي رسالة خطأ.",
          "القيمة Infinity في المصفوفات تتحول إلى null، وقد يظهر ذلك كأرقام فارغة في لوحة التحليلات."
        ]
      },
      {
        type: "callout",
        tone: "tip",
        title: "نقطة تفتيش قبل الإرسال",
        text: "أضف خطوة واحدة قبل أي طلب شبكة: حاول تحليل البيانات بـ JSON.parse داخل كتلة معالجة خطأ، وسجّل نص الخطأ مع طول البيانات وعدد أسطرها. هذه الخطوة وحدها تختصر وقت التشخيص بشكل كبير."
      },
      { type: "h2", id: "number-format", text: "أرقام بصيغة غير صحيحة" },
      {
        type: "p",
        text: "JSON لا يسمح للأرقام أن تبدأ بصفر، ولا يسمح بفاصلة عشرية، ولا يسمح لعلامة عشرية أن تسبق الرقم أو تتبعه. الأخطاء التالية شائعة عند كتابة الأرقام يدوياً:"
      },
      {
        type: "code",
        lang: "json",
        file: "broken.json",
        code: `{
  "zip": 01234,
  "price": 10,50,
  "ratio": 1.
}`
      },
      {
        type: "ul",
        items: [
          "الرمز البريدي 01234 يبدأ بصفر، اجعله سلسلة نصية entre قوسين: \"01234\".",
          "السعر يجب أن يستخدم النقطة العشرية لا الفاصلة: 10.50.",
          "الرقم 1. ينتهي بنقطة، ويجب حذف النقطة أو إضافة أرقام بعدها."
        ]
      },
      {
        type: "table",
        head: ["الرسالة", "السبب الأرجح", "الحل"],
        rows: [
          ["Unexpected token }", "فاصلة زائدة أو قوس زائد", "احذف الفاصلة قبل القوس الختامي"],
          ["Unexpected token '", "اقتباس مفرد بدل المزدوج", "استبدل العلامة المفردة بالمزدوجة"],
          ["Unexpected token N", "قيمة NaN أو Infinity", "استبدلها بقيمة قياسية"],
          ["Unexpected non-whitespace", "تعليق أو نص خارج البنية", "احذف التعليقات"],
          ["Unexpected end of input", "قوس أو علامة اقتباس ناقصة", "تحقق من إغلاق كل الأقواس"]
        ]
      },
      { type: "h2", id: "empty-response", text: "الخطأ الذي لا علاقة له بصيغة JSON" },
      {
        type: "p",
        text: "أحياناً لا تكون رسالة الخطأ عن JSON إطلاقاً، بل عن أن ما وصلك ليس JSON أصلاً. الأسباب الشائعة:"
      },
      {
        type: "ol",
        items: [
          "المحتوى فارغ تماماً، إما لأن الطلب أُلغي أو انتهت مهلته.",
          "صفحة خطأ بصيغة HTML من الخادم، مثل خطأ 500، فالحل في الخادم لا في البيانات.",
          "البيانات ملفوفة في كائن خارجي فأنت تحاول تحليل الكود المصدري بدل المصفوفة.",
          "ترويسة نوع المحتوى لا تطابق المحتوى الفعلي."
        ]
      },
      {
        type: "code",
        lang: "javascript",
        file: "التشخيص",
        code: `const res = await fetch("/api/data");
console.log(res.status, res.headers.get("content-type"));
const text = await res.text();
console.log(text.slice(0, 120)); // افحص النص قبل التحليل
const data = JSON.parse(text);`
      },
      {
        type: "callout",
        tone: "info",
        title: "الخلاصة",
        text: "معظم أخطاء JSON سببها أحد أربعة: فاصلة زائدة، أو خطأ في الاقتباس، أو تعليق، أو قيمة غير قياسية. ابدأ بهذه الأربعة، واقرأ رقم السطر في أداة التنسيق، وستصلح غالباً خلال ثوانٍ."
      }
    ]
  },
  {
    slug: "json-to-typescript-safe-types",
    title: "من JSON إلى TypeScript: كيف تتحول البيانات غير الموثوقة إلى أنواع آمنة",
    description:
      "كيف تستفيد من تحويل JSON إلى أنواع TypeScript دون أن تنتهي بأنواع هشة: القيم الفارغة، تعدد الأنواع، وتجنب any، مع التحقق وقت التشغيل.",
    category: "TypeScript",
    publishedAt: "2026-02-24",
    readingMinutes: 11,
    keywords: "json to typescript typescript interfaces types safe types أنواع TypeScript",
    cover: cover("typescript-shield"),
    coverAlt: "درع رمزي يمثل حماية الأنواع",
    theme: "typescript",
    excerpt:
      "تحويل JSON إلى واجهات TypeScript هو الخطوة الأولى، لكنه ليس الأمان الكامل. هذا الدليل يوضح ما الذي تلتقطه الأداة تلقائياً، وما الذي يبقى عليك التحقق منه.",
    body: [
      {
        type: "p",
        text: "عند استقبال بيانات من واجهة برمجية، أول ما يخطر ببال المطور هو كيف أحوّلها إلى أنواع. الأداة في هذا الموقع تفعل ذلك في ثوانٍ، لكن النتيجة ليست نهاية القصة. الفهم الصحيح للفرق بين الشكل المتوقع والسلوك الفعلي هو ما يفصل بين كود آمن وكود ينهار في الإنتاج."
      },
      { type: "h2", id: "generated-vs-real", text: "ما الذي تلتقطه الأداة فعلاً" },
      {
        type: "p",
        text: "أداة التحويل تمر على ملف JSON حقيقي، لذا ترى القيم الموجودة فيه فقط. هذا يعني:"
      },
      {
        type: "ul",
        items: [
          "إذا ظهر حقل في مثال واحد فقط، قد يُولَّد كنص بينما هو رقم في بقية الحالات.",
          "إذا ظهر الحقل بقيمة فارغة في موضع ما، ستظهر خاصية تقبل القيمة الفارغة.",
          "إذا رأيت نوعين مختلفين في الحقل نفسه، ستحصل على نوع بديل وهذا صحيح."
        ]
      },
      {
        type: "callout",
        tone: "warn",
        title: "العينة الواحدة ليست نوعاً",
        text: "إذا كان الخادم يُرجع أحياناً قيمة نصية وأحياناً رقماً في الحقل نفسه، وولّدت النوع من عينة واحدة، فسيكون النوع خاطئاً. عالج ذلك يدوياً أو خذ عينة من حالات متعددة."
      },
      { type: "h2", id: "nullable-union", text: "الفرق بين الحقل الغائب والقيمة الفارغة" },
      {
        type: "p",
        text: "أكثر مصادر أخطاء TypeScript هو الخلط بين مفتاح غير موجود ومفتاح موجود قيمته فارغة. الحالة الثالثة هي مفتاح قد لا يوجد أصلاً، وهي أصعب الحالات: "
      },
      {
        type: "table",
        head: ["الحالة في البيانات", "الشكل الصحيح", "الشرح"],
        rows: [
          ["المفتاح غائب تماماً", "field?: string", "قد لا يوجد المفتاح أصلاً"],
          ["المفتاح موجود وقيمته null", "field: string | null", "المفتاح موجود لكن القيمة فارغة"],
          ["المفتاح قد يكون أياً منهما", "field: string | null | undefined", "الأكثر أماناً مع بيانات خارجية"]
        ]
      },
      {
        type: "code",
        lang: "typescript",
        file: "types.ts",
        code: `type User = {
  id: number;
  name: string;
  nickname: string | null;    // موجود دائماً لكن قد تكون القيمة فارغة
  avatar?: string;            // قد لا يوجد المفتاح أصلاً
  role: "admin" | "editor" | "viewer" | null;
};`
      },
      { type: "h2", id: "unions", text: "استخدم نوعاً بديلاً محدداً بدل أي نص" },
      {
        type: "p",
        text: "إن كان حقل مقيّداً بقائمة قيم، فاجعله نوعاً بديلاً من قيم محددة. هذا ينقل الخطأ من وقت التشغيل إلى وقت الترجمة، وهو أنجح بكثير:"
      },
      {
        type: "code",
        lang: "typescript",
        file: "before-after.ts",
        code: `// قبل: أي نص مقبول
type Order = { status: string };

// بعد: القيم المسموحة محددة
type OrderStatus = "pending" | "paid" | "shipped" | "cancelled";
type Order = { status: OrderStatus };

// الآن هذا خطأ ترجمة، قبل أن يصل إلى الإنتاج
const bad: Order = { status: "deliverd" };`
      },
      {
        type: "callout",
        tone: "tip",
        title: "استخرج القيم من مكان واحد",
        text: "بدل كتابة قائمة القيم يدوياً داخل النوع، ثبّتها كمجموعة ثابتة واستخرج النوع منها. هذا يمنع الأخطاء الطباعية ويجعل القائمة في مكان واحد يسهل تحديثه."
      },
      { type: "h2", id: "avoid-any", text: "تجنب any والتأكيدات العشوائية" },
      {
        type: "p",
        text: "إن استخدمت any فأنت تطفئ فحص الأنواع. الأفضل استخدام unknown الذي يفرض عليك التحقق قبل الاستخدام:"
      },
      {
        type: "code",
        lang: "typescript",
        file: "narrowing.ts",
        code: `function render(data: unknown) {
  // TypeScript يفرض عليك التحقق قبل الاستخدام
  if (typeof data === "object" && data !== null && "name" in data) {
    const name = (data as { name: string }).name;
    console.log(name);
  }
}`
      },
      { type: "h2", id: "runtime-validation", text: "الأنواع لا تحميك عند التشغيل" },
      {
        type: "p",
        text: "النوع في TypeScript يُمسح عند الترجمة، فلا يوجد تحقق فعلي من أن الخادم يُرجع ما أعلنه. لذلك فإن التحقق وقت التشغيل ضروري مع البيانات القادمة من الخارج: "
      },
      {
        type: "code",
        lang: "typescript",
        file: "validate.ts",
        code: `type User = { id: number; name: string };

function isUser(value: unknown): value is User {
  return (
    typeof value === "object" &&
    value !== null &&
    typeof (value as User).id === "number" &&
    typeof (value as User).name === "string"
  );
}

const data: unknown = await fetch("/api/user").then(res => res.json());

if (isUser(data)) {
  console.log(data.name); // أصبح آمناً هنا
}`
      },
      {
        type: "callout",
        tone: "info",
        title: "متى يكفي التحويل وحده",
        text: "إذا كانت البيانات من مصدرك أنت، مثل ملف إعدادات ثابت، فالتحويل وحده كافٍ تماماً. أما بيانات الغير من واجهات خارجية فتحتاج تحققاً وقت التشغيل، أو مكتبة تحقق تحوّل الأنواع وتتحقق منها في آن واحد."
      },
      { type: "h2", id: "workflow", text: "سير عمل مقترح" },
      {
        type: "ol",
        items: [
          "خزّن الاستجابة الحقيقية من الواجهة البرمجية في ملف JSON.",
          "ولّد الأنواع تلقائياً من هذا الملف.",
          "راجع الأنواع يدوياً: عدّل الخصائص الاختيارية والقيم الفارغة وتعدد الأنواع.",
          "أضف التحقق وقت التشغيل عند الحد الذي تدخل فيه البيانات غير الموثوقة.",
          "اكتب اختبارات للحالات الحدّية: مفتاح غائب، قيمة فارغة، ونوع خاطئ."
        ]
      },
      {
        type: "p",
        text: "هذا السير يحوّل النسخ واللصق إلى عملية قابلة للمراجعة، وهذا بالضبط ما تحتاجه في مشروع حقيقي."
      }
    ]
  },
  {
    slug: "nextjs-performance-checklist",
    title: "تسريع تطبيقات Next.js: تسعة تحسينات قابلة للقياس",
    description:
      "دليل عملي لتحسين أداء تطبيقات Next.js: مكونات الخادم، تقسيم الحزم، الخطوط، الصور، وتخزين البيانات. كل تحسين مشروح مع سبب تأثيره على وقت التحميل.",
    category: "Next.js",
    publishedAt: "2026-03-05",
    readingMinutes: 12,
    keywords: "nextjs performance optimization next.js أداء تحسين سرعة",
    cover: cover("nextjs-speed-lights"),
    coverAlt: "أضواء سريعة توحي بالأداء",
    theme: "tools",
    excerpt:
      "الأداء ليس شعارات، بل هو الوقت الذي يضغط فيه المستخدم على زر فيظهر رد فعل. هذه التحسينات التسعة مصممة لتكون قابلة للقياس قبل وبعد، لا مجرد نصائح عامة.",
    body: [
      {
        type: "p",
        text: "كثير من النصائح الشائعة عن أداء Next.js عامة أكثر من اللازم. هذا الدليل يركّز على التحسينات التي يمكنك قياسها فعلياً، فترى الفرق في رقم حقيقي قبل وبعد التغيير."
      },
      { type: "h2", id: "measure-first", text: "قِس أولاً ثم حسّن" },
      {
        type: "p",
        text: "قبل أي تعديل، سجّل خط الأساس. افحص حجم الحزمة، وقس أرقام الأداء الأساسية من Lighthouse في وضع التصفح الخاص لتفادي الكاش. بدون خط أساس لا تستطيع إثبات أن تحسينك فعل شيئاً."
      },
      {
        type: "code",
        lang: "bash",
        file: "أوامر القياس",
        code: `# حجم الحزمة
npx @next/bundle-analyzer

# قياس الأداء
npx lighthouse http://localhost:3000 --view`
      },
      { type: "h2", id: "server-components", text: "اجعل المكونات تعمل على الخادم ما لم تحتج متصفحاً" },
      {
        type: "p",
        text: "أكبر مكسب في تقليل JavaScript هو عدم إرساله أصلاً. المكوّن الذي يعمل على الخادم ينفّذ هناك ولا يصل إلى المتصفح إلا الناتج النهائي. أضف توجيه_use client في أقل عدد ممكن من المواضع، ولا تضعه في ملف مشترك عالٍ في الشجرة."
      },
      {
        type: "code",
        lang: "tsx",
        file: "هيكل مثالي",
        code: `// مكوّن خادم، بدون توجيه_use client
export default async function Page() {
  const data = await getData();

  return (
    <div>
      <StaticInfo items={data} />
      <InteractiveChart data={data} />
    </div>
  );
}`
      },
      {
        type: "callout",
        tone: "tip",
        title: "القاعدة",
        text: "كلما كان توحيد_use client أقرب إلى أسفل الشجرة، قلّت المساحة التي يصبح فيها كل ما تحتها جزءاً من حزمة المتصفح. اجعل أصغر وحدة تحتاج تفاعلاً هي نقطة البداية."
      },
      { type: "h2", id: "dynamic-import", text: "حمّل المكتبات الثقيلة عند الحاجة" },
      {
        type: "p",
        text: "محرر أكواد كبير أو مكتبة تواريخ ثقيلة أو أي مخطط بياني ضخم يجب ألا يدخل الحزمة الأساسية إن لم يكن مطلوباً في أول رسم. استخدم التحميل الكسول مع عنصر بديل أثناء الانتظار:"
      },
      {
        type: "code",
        lang: "tsx",
        file: "lazy-chart.tsx",
        code: `import dynamic from "next/dynamic";

const Chart = dynamic(() => import("./Chart"), {
  ssr: false,
  loading: () => <div className="h-64 animate-pulse rounded-xl" />
});

export function ChartSlot({ data }: { data: number[] }) {
  return <Chart data={data} />;
}`
      },
      { type: "h2", id: "images", text: "الصور: استخدم المكوّن المخصص وصيغاً حديثة" },
      {
        type: "p",
        text: "الصور غالباً أكبر مساهم في بطء أول ظهور للمحتوى. المكوّن المخصص في Next.js يضيف الأبعاد المطلوبة، ويحمّل الصورة الكسول، ويحوّلها لصيغ حديثة. تأكد من أربعة أشياء:"
      },
      {
        type: "ul",
        items: [
          "استخدم مكوّن الصور المخصص بدل وسم الصورة الخام دائماً.",
          "اضبط خاصية المقاسات بشكل صحيح إذا كانت الصورة متجاوبة.",
          "اجعل الأولوية لصورة الظهور الأول فقط، لا لكل الصور.",
          "عند استخدام نطاق خارجي، أضفه إلى قائمة النطاقات المسموح بها في الإعدادات."
        ]
      },
      { type: "h2", id: "fonts", text: "الخطوط: استضفها ذاتياً مع عرض فوري" },
      {
        type: "p",
        text: "الخطوط الكبيرة تبطئ ظهور المحتوى لأن المتصفح ينتظر تحميلها. استخدم أداة الخطوط في Next.js لتضمين الخط تلقائياً مع أفضل سلوك للعرض:"
      },
      {
        type: "code",
        lang: "tsx",
        file: "layout.tsx",
        code: `import { IBM_Plex_Sans_Arabic } from "next/font/google";

const arabic = IBM_Plex_Sans_Arabic({
  subsets: ["arabic"],
  weight: ["400", "600", "700"],
  display: "swap"
});

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html className={arabic.className}>{children}</html>;
}`
      },
      { type: "h2", id: "memoization", text: "لا تعِد حساب ما لم يتغير" },
      {
        type: "p",
        text: "إن كان لديك حساب ثقيل داخل دالة العرض، استخدم useMemo للقيم المشتقة، وmemo للمكونات التي تستقبل خصائص مستقرة:"
      },
      {
        type: "code",
        lang: "tsx",
        file: "memo.tsx",
        code: `import { memo, useMemo } from "react";

const Chart = memo(function Chart({ points }: { points: Point[] }) {
  const max = useMemo(() => Math.max(...points.map(p => p.y)), [points]);
  return <svg>{/* ارسم المخطط */}</svg>;
});

export default Chart;`
      },
      {
        type: "callout",
        tone: "warn",
        title: "لا تفرط في حفظ النتائج",
        text: "لكل من useMemo و memo تكلفة. استخدمهما فقط إذا أثبت القياس أن إعادة الرسم مكلفة فعلاً، أو إذا كانت القيمة تُحسب بشكل ثقيل حقاً."
      },
      { type: "h2", id: "data-fetching", text: "استرجاع البيانات: التوازي والتخزين المؤقت" },
      {
        type: "p",
        text: "طلبان متسلسلان يعنيان ضعف زمن الانتظار. اطلبهما معاً، واستخدم التخزين المؤقت لتفادي إعادة الجلب في كل زيارة:"
      },
      {
        type: "code",
        lang: "typescript",
        file: "data.ts",
        code: `// طلبان معاً
const [users, posts] = await Promise.all([getUsers(), getPosts()]);

// أو مع تخزين مؤقت
const users = unstable_cache(getUsers, ["users"], { revalidate: 300 })();`
      },
      { type: "h2", id: "waterfalls", text: "أزل شلال الانتظار" },
      {
        type: "p",
        text: "أخطر حالة ليست بيانات بطيئة، بل بيانات متسلسلة ينتظر بعضها بعضاً. إذا كان الطلب الثاني يحتاج نتيجة الأول، يمكنك أحياناً إظهار جزء من الصفحة فوراً باستخدام عنصر الانتظار:"
      },
      {
        type: "code",
        lang: "tsx",
        file: "page.tsx",
        code: `import { Suspense } from "react";

export default function Page() {
  return (
    <>
      <Header />
      <Suspense fallback={<ListSkeleton />}>
        <SlowList />
      </Suspense>
    </>
  );
}`
      },
      { type: "h2", id: "checklist", text: "قائمة تحقق سريعة" },
      {
        type: "table",
        head: ["التحسين", "الأثر المتوقع", "الجهد"],
        rows: [
          ["استخدام مكوّن الصور المخصص", "خفض وقت ظهور المحتوى الأول", "منخفض"],
          ["استضافة الخط ذاتياً مع عرض فوري", "تحسن في الظهور والاستقرار", "منخفض"],
          ["تحميل كسول للمكتبات الثقيلة", "إنقاص حزمة الجافاسكربت الأولى", "متوسط"],
          ["تقليل حدود مكونات المتصفح", "تقليل الترطيب وحجم الحزمة", "متوسط"],
          ["طلب البيانات بالتوازي", "تقليل زمن استجابة الخادم", "منخفض"],
          ["عنصر الانتظار للأجزاء البطيئة", "استجابة أسرع للمستخدم", "متوسط"],
          ["القياس المستمر", "معرفة الأولويات الفعلية", "مستمر"]
        ]
      },
      {
        type: "callout",
        tone: "info",
        title: "من أين تبدأ",
        text: "أعلى نسبة تحسين مقابل أقل جهد تأتي عادةً من ثلاثة أشياء: الصور، والخطوط، وتقليل ما يعمل في المتصفح. ابدأ بهذه الثلاثة ثم انتقل إلى ما بعدها."
      }
    ]
  },
  {
    slug: "api-debugging-playbook",
    title: "دليل تشخيص مشاكل الواجهات البرمجية: من ظهور الخطأ إلى إصلاحه",
    description:
      "منهجية عملية لتشخيص أخطاء الـ API: تقسيم المشكلة إلى طبقات، قراءة رموز الحالة، مشاكل النطاقات والتقاطع، وتتبّع الطلب حتى تصل للسبب الحقيقي.",
    category: "تصحيح الأخطاء",
    publishedAt: "2026-03-20",
    readingMinutes: 10,
    keywords: "api debugging cors 500 401 REST debugging أخطاء API تشخيص",
    cover: cover("network-connections"),
    coverAlt: "شبكة من الخطوط المتشابكة تمثّل طلبات الشبكة",
    theme: "about",
    excerpt:
      "عبارة الطلب فشل ليست معلومة. هذا الدليل يحوّل الخطأ الغامض إلى خطوات محددة: أين يقع الفشل، ولماذا، وكيف نعرف سببه في أقل وقت ممكن.",
    body: [
      {
        type: "p",
        text: "كل خطأ في واجهة برمجية يقع في واحدة من ثلاث طبقات: الشبكة، أو الطلب نفسه، أو الخادم. تقسيم المشكلة إلى هذه الطبقات يوفّر عليك ساعات من التخمين. هذا الدليل يتبع هذا التقسيم خطوة بخطوة."
      },
      { type: "h2", id: "layers", text: "الطبقات الثلاث وأين يقع خطأك" },
      {
        type: "ol",
        items: [
          "طبقة الشبكة: لم يصل الطلب أصلاً أو انقطع في الطريق. تشمل مشاكل اسم النطاق، وشهادات الأمان، وجدار الحماية.",
          "طبقة الطلب: وصل الطلب لكن تفاصيله خاطئة. العنوان، والطريقة، والترويسات، والمحتوى.",
          "طبقة الخادم: وصل الطلب كما يجب لكن الخادم رفضه. منطق خاطئ، أو أذونات، أو قاعدة بيانات."
        ]
      },
      {
        type: "callout",
        tone: "tip",
        title: "أسرع طريقة",
        text: "افتح أدوات المطوّر تبويب الشبكة، أعد إرسال الطلب، واقرأ رمز الحالة في الاستجابة. الرمز نفسه يحدد لك فوراً أي طبقة عليك التركيز."
      },
      { type: "h2", id: "status-codes", text: "رموز الحالة التي ستراها كثيراً" },
      {
        type: "table",
        head: ["الرمز", "المعنى", "السبب الشائع"],
        rows: [
          ["400", "طلب غير صالح", "محتوى تالف أو حقل ناقص"],
          ["401", "غير مصرّح", "رمز دخول ناقص أو منتهي"],
          ["403", "ممنوع", "الرمز صالح لكن الصلاحية غير كافية"],
          ["404", "غير موجود", "مسار خاطئ أو طريقة غير مدعومة"],
          ["405", "طريقة غير مسموحة", "استخدام طلب بدل آخر على المسار نفسه"],
          ["409", "تعارض", "مخالفة قيد التفرّد في قاعدة البيانات"],
          ["422", "غير قابل للمعالجة", "بيانات ناقصة أو خارج النطاق المسموح"],
          ["429", "طلبات كثيرة", "تجاوز حد المعدل المسموح"],
          ["500", "خطأ داخلي", "استثناء لم يُعالَج في الخادم"]
        ]
      },
      {
        type: "p",
        text: "التمييز الأهم بين 401 و 403. الأول يعني أن الخادم لا يعرف من أنت، والثاني يعني أنه يعرفك لكنك غير مخوّل. هذا يحدد هل المشكلة في رمز الدخول أم في الصلاحيات."
      },
      { type: "h2", id: "network-layer", text: "طبقة الشبكة ومشاكل النطاقات" },
      {
        type: "p",
        text: "مشكلة النطاق المتقاطع هي أشهر عقبة أمام مطوّري الواجهات. المتصفح يمنع قراءة استجابة من نطاق مختلف إلا إذا سمح الخادم بذلك. الرسالة في الكونسول واضحة:"
      },
      {
        type: "code",
        lang: "text",
        file: "رسالة نموذجية",
        code: `Access to fetch at 'https://api.example.com/data'
from origin 'https://myapp.vercel.app' has been blocked by CORS policy:
No 'Access-Control-Allow-Origin' header is present.`
      },
      {
        type: "ul",
        items: [
          "هذا الخطأ يحدث غالباً بعد وصول الطلب إلى الخادم، أي أن الاستجابة وصلت لكن المتصفح يرفض عرضها.",
          "الحل يكون على الخادم بإضافة ترويسة السماح بالنطاق، أو باستخدام وسيط في تطبيقك.",
          "عند إرسال بيانات اعتماد، لا يمكنك استخدام علامة النجمة، بل يجب تحديد النطاق بدقة.",
          "فشل طلب ما قبل الإرسال غالباً يعني أن الخادم لا يعالج هذا الطلب التمهيدي قبل الطلب الحقيقي."
        ]
      },
      {
        type: "callout",
        tone: "warn",
        title: "لا تعتمد عليه للحماية",
        text: "النطاق المتقاطع دفاع في المتصفح، لا حماية في الخادم. لا تعتمد عليه لتقييد الوصول إلى بيانات حساسة، بل استخدم مصادقة ورموز دخول يتحقق منها الخادم نفسه."
      },
      { type: "h2", id: "request-layer", text: "طبقة الطلب: أخطاء خفيّة" },
      { type: "h3", id: "content-type", text: "نوع المحتوى لا يطابق المحتوى" },
      {
        type: "p",
        text: "إذا أرسلت البيانات بصيغة JSON لكن بدون ترويسة نوع المحتوى، فلن يقرأها الخادم، وستحصل على خطأ 400 أو على محتوى فارغ:"
      },
      {
        type: "code",
        lang: "javascript",
        file: "خطأ شائع",
        code: `// خطأ: لا توجد ترويسة نوع المحتوى
fetch("/api/items", { method: "POST", body: JSON.stringify(data) });

// صحيح
fetch("/api/items", {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(data)
});`
      },
      { type: "h3", id: "stale-cache", text: "الذاكرة المؤقتة تخفي التغييرات" },
      {
        type: "p",
        text: "أحياناً يكون الكود صحيحاً لكن التعديل لا يظهر بسبب ذاكرة المتصفح أو الخدمة. عطّل التخزين المؤقت أثناء التطوير:"
      },
      {
        type: "code",
        lang: "javascript",
        file: "تعطيل الذاكرة المؤقتة",
        code: `fetch("/api/items", { cache: "no-store" });

// أو أضف معاملاً متغيراً أثناء التطوير
fetch("/api/items?t=" + Date.now());`
      },
      { type: "h2", id: "server-layer", text: "طبقة الخادم: أين يختبئ خطأ 500" },
      {
        type: "p",
        text: "رمز 500 يعني استثناءً لم يُعالَج. ابحث في سجلات الخادم عن أثر الخطأ الكامل بدل التخمين. الأسباب الشائعة:"
      },
      {
        type: "ul",
        items: [
          "متغير بيئة غير معرّف، فيظهر كقيمة فارغة غير متوقعة في مكان ما.",
          "استعلام قاعدة بيانات على عمود غير موجود.",
          "محاولة تحليل جسم الطلب وهو فارغ، فتنهار العملية.",
          "وعد غير معالَج في دالة لا تدعم الأساليب غير المتزامنة.",
          "فشل استدعاء خدمة خارجية، ويُبلّغ كخطأ داخلي رغم أن المشكلة في الشبكة."
        ]
      },
      {
        type: "code",
        lang: "typescript",
        file: "معالجة أخطاء متدرجة",
        code: `export async function POST(request: Request) {
  try {
    const body = await request.json();

    if (!body?.email) {
      return Response.json({ error: "email_required" }, { status: 422 });
    }

    const result = await save(body);
    return Response.json(result, { status: 201 });
  } catch (err) {
    console.error("POST /api/items failed:", err);
    return Response.json({ error: "internal_error" }, { status: 500 });
  }
}`
      },
      { type: "h2", id: "logging", text: "سجلات تكفي لتشخيص أي خطأ" },
      {
        type: "callout",
        tone: "info",
        title: "الحد الأدنى من التسجيل",
        text: "في كل معالج طلب، سجّل الطريقة والمسار، ورمز الحالة الناتج، ومعرّف طلب فريد. أضف هذا المعرّف في ترويسة كل استجابة، فهو ما يربط سجلات المتصفح بسجلات الخادم."
      },
      {
        type: "ol",
        items: [
          "ولّد معرف طلب فريد في الطبقة الوسيطة لكل طلب.",
          "مرره في ترويسة مخصصة للاستجابة.",
          "سجّله مع كل خطأ في الخادم.",
          "اعرضه في المتصفح عند إرسال بلاغ عن مشكلة."
        ]
      },
      { type: "h2", id: "playbook", text: "خطوات التشخيص المتكررة" },
      {
        type: "table",
        head: ["الخطوة", "السؤال الذي تجيب عنه"],
        rows: [
          ["اقرأ رمز الحالة", "أي طبقة هي الفاشلة؟"],
          ["افتح الطلب المرسل", "ما الذي أرسلته فعلاً؟"],
          ["افتح الاستجابة", "ماذا ردّ الخادم بالضبط؟"],
          ["راجع الكونسول", "هل هناك خطأ نطاق أو ترطيب؟"],
          ["جرّب من الطرفية", "هل المشكلة في المتصفح أم في الواجهة؟"]
        ]
      },
      {
        type: "code",
        lang: "bash",
        file: "اختبار مستقل عن المتصفح",
        code: `curl -i -X POST https://api.example.com/items \\
  -H "Content-Type: application/json" \\
  -d '{"name":"test"}'`
      },
      {
        type: "callout",
        tone: "tip",
        title: "قوة سطر الأوامر",
        text: "إذا نجح الطلب من الطرفية وفشل في المتصفح، فالمشكلة ليست في الواجهة البرمجية بل في المتصفح: نطاق متقاطع، أو ذاكرة مؤقتة، أو حالة التطبيق. هذه المقارنة وحدها تختصر التشخيص إلى النصف."
      }
    ]
  }
];

export function getArticle(slug: string): Article | undefined {
  return articles.find(article => article.slug === slug);
}

export function articleUrl(slug: string) {
  return `/articles/${slug}`;
}
