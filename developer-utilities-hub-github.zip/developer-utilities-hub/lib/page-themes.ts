export type ArtVariant = "grid" | "waves" | "orbit" | "circuit" | "braces" | "layers";

export type PageTheme = {
  id: string;
  label: string;
  art: ArtVariant;
  light: { accent: string; strong: string; soft: string; ink: string };
  dark: { accent: string; strong: string; soft: string; ink: string };
};

const make = (
  id: string,
  label: string,
  art: ArtVariant,
  light: PageTheme["light"],
  dark: PageTheme["dark"]
): PageTheme => ({ id, label, art, light, dark });

export const pageThemes: Record<string, PageTheme> = {
  home: make("home", "الرئيسية — زمردي", "grid", {
    accent: "#0f9d76",
    strong: "#047857",
    soft: "#10b9811f",
    ink: "#ffffff"
  }, {
    accent: "#34d399",
    strong: "#6ee7b7",
    soft: "#34d3991f",
    ink: "#04211a"
  }),

  tools: make("tools", "الأدوات — أزرق", "circuit", {
    accent: "#2563eb",
    strong: "#1d4ed8",
    soft: "#3b82f61f",
    ink: "#ffffff"
  }, {
    accent: "#60a5fa",
    strong: "#93c5fd",
    soft: "#3b82f61f",
    ink: "#04211a"
  }),

  formatter: make("formatter", "المنسّق — بنفسجي", "braces", {
    accent: "#7c3aed",
    strong: "#6d28d9",
    soft: "#8b5cf61f",
    ink: "#ffffff"
  }, {
    accent: "#a78bfa",
    strong: "#c4b5fd",
    soft: "#8b5cf61f",
    ink: "#16082e"
  }),

  typescript: make("typescript", "محول TS — كهرماني", "layers", {
    accent: "#d97706",
    strong: "#b45309",
    soft: "#f59e0b1f",
    ink: "#ffffff"
  }, {
    accent: "#fbbf24",
    strong: "#fcd34d",
    soft: "#f59e0b1f",
    ink: "#2a1a00"
  }),

  articles: make("articles", "المقالات — فيروزي", "waves", {
    accent: "#0d9488",
    strong: "#0f766e",
    soft: "#14b8a61f",
    ink: "#ffffff"
  }, {
    accent: "#2dd4bf",
    strong: "#5eead4",
    soft: "#14b8a61f",
    ink: "#04211a"
  }),

  about: make("about", "من نحن — برتقالي", "orbit", {
    accent: "#ea580c",
    strong: "#c2410c",
    soft: "#f973161f",
    ink: "#ffffff"
  }, {
    accent: "#fb923c",
    strong: "#fdba74",
    soft: "#f973161f",
    ink: "#2a1000"
  }),

  contact: make("contact", "اتصل بنا — وردي", "waves", {
    accent: "#db2777",
    strong: "#be185d",
    soft: "#ec48991f",
    ink: "#ffffff"
  }, {
    accent: "#f472b6",
    strong: "#f9a8d4",
    soft: "#ec48991f",
    ink: "#2b0416"
  }),

  legal: make("legal", "صفحات قانونية — سماوي", "layers", {
    accent: "#0369a1",
    strong: "#075985",
    soft: "#0ea5e91f",
    ink: "#ffffff"
  }, {
    accent: "#38bdf8",
    strong: "#7dd3fc",
    soft: "#0ea5e91f",
    ink: "#04202e"
  })
};

export function getTheme(id: string): PageTheme {
  return pageThemes[id] ?? pageThemes.home;
}

export function themeStyle(theme: PageTheme): React.CSSProperties {
  return {
    "--sk-accent": theme.light.accent,
    "--sk-accent-strong": theme.light.strong,
    "--sk-accent-soft": theme.light.soft,
    "--sk-accent-ink": theme.light.ink,
    "--sk-accent-d": theme.dark.accent,
    "--sk-accent-strong-d": theme.dark.strong,
    "--sk-accent-soft-d": theme.dark.soft,
    "--sk-accent-ink-d": theme.dark.ink
  } as React.CSSProperties;
}
