export const siteConfig = {
  name: "Developer Utilities Hub",
  shortName: "Dev Utilities",
  title: "Developer Utilities Hub — أدوات المطورين",
  tagline: "أدوات المطورين، أسرع وأبسط.",
  description:
    "مجموعة سريعة وخصوصية من أدوات المطورين اليومية تعمل مباشرة داخل المتصفح دون رفع بياناتك إلى أي خادم.",
  url: (process.env.NEXT_PUBLIC_SITE_URL ?? "https://example.com").replace(/\/$/, ""),
  email: process.env.NEXT_PUBLIC_CONTACT_EMAIL ?? "bmezaouda@gmail.com",
  locale: "ar_AR",
  language: "ar",
  themeColorLight: "#f6faf8",
  themeColorDark: "#050b0a"
} as const;

export const owner = {
  name: process.env.NEXT_PUBLIC_OWNER_NAME ?? "مشرف الموقع",
  role: "مالك الموقع ومشرف المحتوى",
  email: siteConfig.email,
  get initials() {
    return this.name.trim().charAt(0) || "M";
  }
} as const;

export const adsense = {
  client: process.env.NEXT_PUBLIC_ADSENSE_CLIENT ?? "",
  defaultSlot: process.env.NEXT_PUBLIC_ADSENSE_SLOT ?? "",
  enabled: Boolean(
    (process.env.NEXT_PUBLIC_ADSENSE_CLIENT ?? "").startsWith("ca-pub-") &&
      (process.env.NEXT_PUBLIC_ADSENSE_SLOT ?? "").length > 0
  )
} as const;

export const verification = {
  googleSite: process.env.NEXT_PUBLIC_GOOGLE_SITE_VERIFICATION ?? "",
  googleAdsense: process.env.NEXT_PUBLIC_ADSENSE_CLIENT ?? ""
} as const;

export type ToolMeta = {
  slug: string;
  href: string;
  title: string;
  shortTitle: string;
  description: string;
  keywords: string;
  category: "format" | "encode" | "developer";
  icon: string;
  features: string[];
  faq: { question: string; answer: string }[];
};

export const tools: ToolMeta[] = [
  {
    slug: "json-formatter",
    href: "/tools/json-formatter",
    title: "منسق ومصحح JSON",
    shortTitle: "JSON Formatter",
    description:
      "نسّق، صغّر، فرز المفاتيح، تحقق وانسخ JSON بسهولة مع رسائل أخطاء واضحة وموضع دقيق للخطأ.",
    keywords: "json formatter validator format minify sort keys json منسق مصحح تنسيق",
    category: "format",
    icon: "braces",
    features: [
      "تنسيق بأسطر متطابقة مع 2 أو 4 مسافات بادئة",
      "تصغير JSON لإزالة كل المسافات غير الضرورية",
      "التحقق من صحة JSON مع رقم السطر والعمود عند الخطأ",
      "فرز المفاتيح أبجدياً أو حسب الحجم",
      "نسخ النتيجة أو تنزيلها كملف .json"
    ],
    faq: [
      {
        question: "هل تُرسل بيانات JSON إلى خادم؟",
        answer:
          "لا. كل المعالجة تتم في متصفحك عبر JavaScript فقط، ولا تغادر بياناتك جهازك إلى أي خادم."
      },
      {
        question: "لماذا تظهر رسالة خطأ؟",
        answer:
          "الرسالة توضّح نوع الخطأ وموضعه بالسطر والعمود، ما يساعدك على إصلاحه بسرعة. غالباً يكون السبب فاصلة زائدة أو اقتباس غير مغلق."
      },
      {
        question: "هل يمكنني تنسيق ملفات JSON كبيرة؟",
        answer:
          "نعم. تتم المعالجة محلياً على جهازك، لذلك لا يوجد حد يفرضه الخادم على حجم الملف."
      }
    ]
  },
  {
    slug: "json-to-typescript",
    href: "/tools/json-to-typescript",
    title: "محول JSON إلى TypeScript",
    shortTitle: "JSON → TS",
    description:
      "حوّل بيانات JSON إلى TypeScript Interfaces جاهزة للاستخدام في React وNext.js وNode.js، مع تسمية الواجهات وترتيبها تلقائياً.",
    keywords: "json to typescript types interfaces convert json مولد typescript تحويل json",
    category: "developer",
    icon: "code",
    features: [
      "توليد export interface لكل كائن متداخل",
      "تسمية الواجهات تلقائياً من أسماء المفاتيح",
      "التعامل مع المصفوفات: كائنات متداخلة، أنواع مختلطة، unknown[]",
      "تنزيل النتيجة كملف interfaces.ts أو نسخها",
      "تحديد اسم الواجهة الرئيسية يدوياً"
    ],
    faq: [
      {
        question: "كيف تُسقى الواجهات؟",
        answer:
          "من اسم المفتاح مع تصغير أول حرف، فالمفتاح profile ينتج Profile. المصفوفات من الكائنات تنتج Item مثلاً ProfileItem."
      },
      {
        question: "ماذا يحدث مع المفاتيح التي بها مسافات؟",
        answer:
          "تُغلَّف بعلامات اقتباس تلقائياً لتبقى صالحة في TypeScript، مثل: \"first-name\": string."
      },
      {
        question: "هل تُرسل بياناتي إلى الخادم؟",
        answer: "لا. التحويل يتم في متصفحك فقط ولا تغادر بياناتك جهازك."
      }
    ]
  }
];

export const categories = [
  {
    id: "format",
    title: "تنسيق وصياغة",
    description: "أدوات لتنسيق الأكواد والتحقق من صحتها."
  },
  {
    id: "encode",
    title: "ترميز وفك ترميز",
    description: "تحويل البيانات بين الصيغ المختلفة."
  },
  {
    id: "developer",
    title: "أدوات المطوّر",
    description: "مساعدات يومية تسرّع سير عملك."
  }
] as const;

export const navLinks = [
  { href: "/tools", label: "الأدوات" },
  { href: "/articles", label: "المقالات" },
  { href: "/tools/json-formatter", label: "JSON Formatter" },
  { href: "/tools/json-to-typescript", label: "JSON → TS" },
  { href: "/about", label: "من نحن" },
  { href: "/contact", label: "اتصل بنا" }
];

export const legalLinks = [
  { href: "/privacy", label: "سياسة الخصوصية" },
  { href: "/cookies", label: "سياسة ملفات تعريف الارتباط" },
  { href: "/terms", label: "شروط الاستخدام" },
  { href: "/disclaimer", label: "إخلاء المسؤولية" },
  { href: "/contact", label: "اتصل بنا" }
];

export function absoluteUrl(path = ""): string {
  return `${siteConfig.url}${path.startsWith("/") ? path : `/${path}`}`;
}
