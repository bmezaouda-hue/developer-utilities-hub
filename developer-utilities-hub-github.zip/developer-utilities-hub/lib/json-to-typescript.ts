export type JsonValue =
  | string
  | number
  | boolean
  | null
  | JsonValue[]
  | { [key: string]: JsonValue };

export type GenerateResult =
  | { ok: true; code: string; interfaceCount: number }
  | { ok: false; message: string };

const RESERVED_PREFIX = /^\d/;

export function sanitizeName(name: string): string {
  const cleaned = name
    .replace(/[^a-zA-Z0-9_$]/g, "_")
    .replace(/^[^a-zA-Z_$]+/, "")
    .replace(RESERVED_PREFIX, "");
  return cleaned || "Root";
}

function capitalize(name: string): string {
  return name.charAt(0).toUpperCase() + name.slice(1);
}

function isPlainObject(value: JsonValue): value is Record<string, JsonValue> {
  return typeof value === "object" && value !== null && !Array.isArray(value);
}

function inferType(value: JsonValue, keyName: string, interfaces: string[]): string {
  if (value === null) return "null";

  if (Array.isArray(value)) {
    if (value.length === 0) return "unknown[]";

    const first = value[0];
    if (isPlainObject(first)) {
      const interfaceName = `${capitalize(sanitizeName(keyName))}Item`;
      buildInterface(interfaceName, first, interfaces);
      return `${interfaceName}[]`;
    }

    const types = [...new Set(value.map(item => inferType(item, keyName, interfaces)))];
    return types.length === 1 ? `${types[0]}[]` : `(${types.join(" | ")})[]`;
  }

  if (isPlainObject(value)) {
    const interfaceName = capitalize(sanitizeName(keyName));
    buildInterface(interfaceName, value, interfaces);
    return interfaceName;
  }

  if (typeof value === "string") return "string";
  if (typeof value === "number") return "number";
  if (typeof value === "boolean") return "boolean";

  return "unknown";
}

function buildInterface(name: string, obj: Record<string, JsonValue>, interfaces: string[]) {
  const lines: string[] = [`export interface ${name} {`];

  for (const [key, value] of Object.entries(obj)) {
    const safeKey = /^[a-zA-Z_$][a-zA-Z0-9_$]*$/.test(key) ? key : JSON.stringify(key);
    lines.push(`  ${safeKey}: ${inferType(value, key, interfaces)};`);
  }

  lines.push("}");
  lines.push("");
  interfaces.push(lines.join("\n"));
}

export function generateTypes(input: string, rootName: string): GenerateResult {
  if (!input.trim()) {
    return { ok: false, message: "أدخل JSON أولاً." };
  }

  let parsed: JsonValue;
  try {
    parsed = JSON.parse(input) as JsonValue;
  } catch {
    return { ok: false, message: "تعذّر تحليل JSON. تأكد من صحة البنية." };
  }

  if (!isPlainObject(parsed)) {
    return { ok: false, message: "يجب أن يكون JSON الأساسي عبارة عن كائن (Object)." };
  }

  const interfaces: string[] = [];
  const root = capitalize(sanitizeName(rootName));

  buildInterface(root, parsed, interfaces);

  return {
    ok: true,
    code: interfaces.reverse().join("\n").trimEnd(),
    interfaceCount: interfaces.length
  };
}

export const TS_SAMPLE = `{
  "id": 123,
  "name": "Ahmed",
  "email": "ahmed@example.com",
  "active": true,
  "profile": {
    "age": 28,
    "city": "Oran"
  },
  "roles": ["admin", "editor"],
  "tags": [],
  "owner": null
}`;
