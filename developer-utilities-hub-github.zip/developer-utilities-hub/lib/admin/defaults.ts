import type { AdminSettings } from "./types";
import { adsense, owner, siteConfig } from "@/lib/site";

export const SETTINGS_VALIDATION = {
  email: /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/,
  maxAnnouncement: 160,
  maxMaintenance: 300
};

export function defaultSettings(): AdminSettings {
  return {
    ownerName: owner.name,
    contactEmail: siteConfig.email,
    siteUrl: siteConfig.url,
    announcement: { enabled: false, text: "", link: "" },
    maintenance: {
      enabled: process.env.MAINTENANCE === "1",
      message: "الموقع تحت الصيانة حالياً. سنعود قريباً — شكراً لتفهمك."
    },
    adsEnabled: adsense.enabled,
    trackVisits: true
  };
}

export function sanitizeSettings(input: unknown, base: AdminSettings): AdminSettings {
  const data = (input ?? {}) as Partial<AdminSettings>;
  const email = typeof data.contactEmail === "string" ? data.contactEmail.trim() : base.contactEmail;
  const siteUrl = typeof data.siteUrl === "string" ? data.siteUrl.trim() : base.siteUrl;
  const announcement = data.announcement ?? base.announcement;
  const maintenance = data.maintenance ?? base.maintenance;

  return {
    ownerName: (typeof data.ownerName === "string" ? data.ownerName.trim() : base.ownerName).slice(0, 80) || base.ownerName,
    contactEmail: SETTINGS_VALIDATION.email.test(email) ? email : base.contactEmail,
    siteUrl: /^https?:\/\/[^\s]+$/.test(siteUrl) ? siteUrl.replace(/\/$/, "") : base.siteUrl,
    announcement: {
      enabled: Boolean(announcement.enabled),
      text: (announcement.text ?? "").slice(0, SETTINGS_VALIDATION.maxAnnouncement),
      link: /^(\/|https?:\/\/)/.test(announcement.link ?? "") ? (announcement.link ?? "").trim() : ""
    },
    maintenance: {
      enabled: Boolean(maintenance.enabled),
      message: (maintenance.message ?? "").slice(0, SETTINGS_VALIDATION.maxMaintenance)
    },
    adsEnabled: typeof data.adsEnabled === "boolean" ? data.adsEnabled : base.adsEnabled,
    trackVisits: typeof data.trackVisits === "boolean" ? data.trackVisits : base.trackVisits
  };
}
