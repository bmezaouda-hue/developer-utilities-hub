import { promises as fs } from "node:fs";
import path from "node:path";
import { defaultSettings, sanitizeSettings } from "./defaults";
import type { AdminSettings, StatsSnapshot, ToolOverride, ToolOverrides } from "./types";

const upstashUrl = process.env.UPSTASH_REDIS_REST_URL?.replace(/\/$/, "");
const upstashToken = process.env.UPSTASH_REDIS_REST_TOKEN;
const useUpstash = Boolean(upstashUrl && upstashToken);

export const storeDriver = useUpstash ? "upstash" : "file";

const SETTINGS_KEY = "duh:settings";
const TOOLS_KEY = "duh:tools";
const TOTAL_KEY = "duh:stats:total";
const RETENTION_DAYS = 120;
const dayKey = (date: string) => `duh:stats:day:${date}`;

type FileShape = {
  settings: AdminSettings;
  tools: ToolOverrides;
  days: Record<string, Record<string, number>>;
  totals: Record<string, number>;
};

const storePath = path.join(process.cwd(), "data", "store.json");
let queue: Promise<unknown> = Promise.resolve();

function withLock<T>(fn: () => Promise<T>): Promise<T> {
  const run = queue.then(fn, fn);
  queue = run.then(
    () => undefined,
    () => undefined
  );
  return run;
}

async function readFile(): Promise<FileShape> {
  try {
    const raw = await fs.readFile(storePath, "utf8");
    const parsed = JSON.parse(raw) as Partial<FileShape>;
    return {
      settings: parsed.settings ?? defaultSettings(),
      tools: parsed.tools ?? {},
      days: parsed.days ?? {},
      totals: parsed.totals ?? {}
    };
  } catch {
    return { settings: defaultSettings(), tools: {}, days: {}, totals: {} };
  }
}

async function writeFile(data: FileShape) {
  await fs.mkdir(path.dirname(storePath), { recursive: true });
  const temp = `${storePath}.tmp`;
  await fs.writeFile(temp, JSON.stringify(data, null, 2), "utf8");
  await fs.rename(temp, storePath);
}

function prune(days: Record<string, Record<string, number>>) {
  const keys = Object.keys(days).sort();
  while (keys.length > RETENTION_DAYS) {
    const oldest = keys.shift();
    if (oldest) delete days[oldest];
  }
}

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function lastDays(count: number) {
  const out: string[] = [];
  const cursor = new Date();
  for (let index = count - 1; index >= 0; index -= 1) {
    out.push(new Date(cursor.getTime() - index * 86400000).toISOString().slice(0, 10));
  }
  return out;
}

function normalizePath(value: string) {
  const clean = value.split("?")[0].split("#")[0].slice(0, 120);
  if (!clean.startsWith("/") || clean.includes("..")) return null;
  return clean;
}

async function pipeline(commands: (string | number)[][]) {
  const response = await fetch(`${upstashUrl}/pipeline`, {
    method: "POST",
    headers: {
      authorization: `Bearer ${upstashToken}`,
      "content-type": "application/json"
    },
    body: JSON.stringify(commands),
    cache: "no-store"
  });
  if (!response.ok) throw new Error(`storage_upstream_${response.status}`);
  const data = (await response.json()) as { result: unknown }[];
  return data.map(item => item.result);
}

function asMap(result: unknown): Record<string, number> {
  if (!result || typeof result !== "object") return {};
  return Object.fromEntries(
    Object.entries(result as Record<string, unknown>).map(([key, value]) => [key, Number(value) || 0])
  );
}

export async function readSettings(): Promise<AdminSettings> {
  if (!useUpstash) return (await readFile()).settings;
  const [result] = await pipeline([["GET", SETTINGS_KEY]]);
  const raw = typeof result === "string" ? result : null;
  if (!raw) return defaultSettings();
  try {
    return sanitizeSettings(JSON.parse(raw), defaultSettings());
  } catch {
    return defaultSettings();
  }
}

export async function writeSettings(patch: Partial<AdminSettings>): Promise<AdminSettings> {
  if (!useUpstash) {
    return withLock(async () => {
      const data = await readFile();
      data.settings = sanitizeSettings({ ...data.settings, ...patch }, defaultSettings());
      await writeFile(data);
      return data.settings;
    });
  }
  const current = await readSettings();
  const next = sanitizeSettings({ ...current, ...patch }, defaultSettings());
  await pipeline([["SET", SETTINGS_KEY, JSON.stringify(next)]]);
  return next;
}

export async function readTools(): Promise<ToolOverrides> {
  if (!useUpstash) return (await readFile()).tools;
  const [result] = await pipeline([["GET", TOOLS_KEY]]);
  if (typeof result !== "string") return {};
  try {
    return JSON.parse(result) as ToolOverrides;
  } catch {
    return {};
  }
}

export async function writeTools(next: ToolOverrides): Promise<ToolOverrides> {
  const clean: ToolOverrides = Object.fromEntries(
    Object.entries(next).map(([slug, value]: [string, ToolOverride]) => [
      slug,
      {
        enabled: Boolean(value?.enabled),
        title: String(value?.title ?? "").slice(0, 120),
        description: String(value?.description ?? "").slice(0, 300)
      }
    ])
  );
  if (!useUpstash) {
    return withLock(async () => {
      const data = await readFile();
      data.tools = clean;
      await writeFile(data);
      return clean;
    });
  }
  await pipeline([["SET", TOOLS_KEY, JSON.stringify(clean)]]);
  return clean;
}

export async function trackView(rawPath: string, date = todayKey()): Promise<void> {
  const target = normalizePath(rawPath);
  if (!target) return;
  if (!useUpstash) {
    await withLock(async () => {
      const data = await readFile();
      const day = data.days[date] ?? {};
      day[target] = (day[target] ?? 0) + 1;
      data.days[date] = day;
      data.totals[target] = (data.totals[target] ?? 0) + 1;
      prune(data.days);
      await writeFile(data);
    });
    return;
  }
  await pipeline([
    ["HINCRBY", dayKey(date), target, 1],
    ["EXPIRE", dayKey(date), RETENTION_DAYS * 86400],
    ["HINCRBY", TOTAL_KEY, target, 1]
  ]);
}

export async function readStats(days = 14): Promise<StatsSnapshot> {
  const dates = lastDays(Math.max(1, Math.min(days, RETENTION_DAYS)));

  if (!useUpstash) {
    const data = await readFile();
    const points = dates.map(date => ({
      date,
      views: Object.values(data.days[date] ?? {}).reduce((sum, value) => sum + value, 0)
    }));
    const topPages = Object.entries(data.totals)
      .map(([path, views]) => ({ path, views }))
      .sort((a, b) => b.views - a.views)
      .slice(0, 12);
    return {
      totalViews: Object.values(data.totals).reduce((sum, value) => sum + value, 0),
      todayViews: points.at(-1)?.views ?? 0,
      days: points,
      topPages,
      trackedPaths: Object.keys(data.totals).length,
      updatedAt: Date.now()
    };
  }

  const results = await pipeline([
    ...dates.map(date => ["HGETALL", dayKey(date)]),
    ["HGETALL", TOTAL_KEY]
  ]);
  const dayMaps = results.slice(0, dates.length).map(asMap);
  const totals = asMap(results[results.length - 1]);
  const points = dates.map((date, index) => ({
    date,
    views: Object.values(dayMaps[index] ?? {}).reduce((sum, value) => sum + value, 0)
  }));
  const topPages = Object.entries(totals)
    .map(([path, views]) => ({ path, views }))
    .sort((a, b) => b.views - a.views)
    .slice(0, 12);

  return {
    totalViews: Object.values(totals).reduce((sum, value) => sum + value, 0),
    todayViews: points.at(-1)?.views ?? 0,
    days: points,
    topPages,
    trackedPaths: Object.keys(totals).length,
    updatedAt: Date.now()
  };
}

export async function resetStats(): Promise<void> {
  if (!useUpstash) {
    await withLock(async () => {
      const data = await readFile();
      data.days = {};
      data.totals = {};
      await writeFile(data);
    });
    return;
  }
  const keys = await pipeline([["KEYS", "duh:stats:*"]]);
  const found = Array.isArray(keys[0]) ? (keys[0] as string[]) : [];
  if (found.length === 0) return;
  await pipeline(found.map(key => ["DEL", key]));
}
