export type Announcement = {
  enabled: boolean;
  text: string;
  link: string;
};

export type Maintenance = {
  enabled: boolean;
  message: string;
};

export type AdminSettings = {
  ownerName: string;
  contactEmail: string;
  siteUrl: string;
  announcement: Announcement;
  maintenance: Maintenance;
  adsEnabled: boolean;
  trackVisits: boolean;
};

export type ToolOverride = {
  enabled: boolean;
  title: string;
  description: string;
};

export type ToolOverrides = Record<string, ToolOverride>;

export type DayPoint = { date: string; views: number };

export type PagePoint = { path: string; views: number };

export type StatsSnapshot = {
  totalViews: number;
  todayViews: number;
  days: DayPoint[];
  topPages: PagePoint[];
  trackedPaths: number;
  updatedAt: number;
};

export type PublicConfig = {
  settings: Pick<
    AdminSettings,
    | "ownerName"
    | "contactEmail"
    | "siteUrl"
    | "announcement"
    | "maintenance"
    | "adsEnabled"
    | "trackVisits"
  >;
  tools: ToolOverrides;
};
