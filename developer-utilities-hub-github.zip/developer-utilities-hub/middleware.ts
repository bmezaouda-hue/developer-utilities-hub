import { NextResponse, type NextRequest } from "next/server";

const ADMIN_COOKIE = "duh_admin";
const PUBLIC = ["/admin/login", "/api/admin/login", "/api/admin/session"];
const ALLOWED_DURING_MAINTENANCE = [
  "/admin",
  "/api/admin",
  "/api/track",
  "/contact",
  "/privacy",
  "/cookies",
  "/terms",
  "/disclaimer",
  "/robots.txt",
  "/sitemap.xml",
  "/ads.txt",
  "/manifest.webmanifest",
  "/icon.svg",
  "/opengraph-image"
];

function isPublic(pathname: string) {
  return PUBLIC.some(path => pathname === path || pathname.startsWith(`${path}/`));
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;
  const hasSessionCookie = Boolean(request.cookies.get(ADMIN_COOKIE)?.value);

  if (process.env.MAINTENANCE === "1" && !hasSessionCookie) {
    const allowed = ALLOWED_DURING_MAINTENANCE.some(
      path => pathname === path || pathname.startsWith(`${path}/`)
    );
    if (!allowed) {
      return new NextResponse(
        "<!doctype html><html lang=\"ar\" dir=\"rtl\"><head><meta charset=\"utf-8\"><title>صيانة</title></head><body style=\"font-family:system-ui;display:grid;place-items:center;min-height:100vh;margin:0;background:#f4f9f6;color:#0b1f19\"><main style=\"text-align:center;padding:2rem\"><h1>الموقع تحت الصيانة</h1><p>نعود قريباً.</p></main></body></html>",
        { status: 503, headers: { "content-type": "text/html; charset=utf-8", "retry-after": "3600" } }
      );
    }
  }

  const adminRoute = pathname.startsWith("/admin") || pathname.startsWith("/api/admin");
  if (adminRoute && !isPublic(pathname)) {
    if (!hasSessionCookie) {
      if (pathname.startsWith("/api/")) {
        return NextResponse.json({ error: "unauthorized" }, { status: 401 });
      }
      const url = request.nextUrl.clone();
      url.pathname = "/admin/login";
      url.search = pathname === "/admin" ? "" : `?next=${encodeURIComponent(pathname)}`;
      return NextResponse.redirect(url);
    }
    const response = NextResponse.next();
    response.headers.set("X-Robots-Tag", "noindex, nofollow");
    return response;
  }

  if (pathname === "/admin" || pathname === "/admin/login") {
    const response = NextResponse.next();
    response.headers.set("X-Robots-Tag", "noindex, nofollow");
    return response;
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|icon.svg|opengraph-image|robots.txt|sitemap.xml|ads.txt|manifest.webmanifest).*)"
  ]
};
