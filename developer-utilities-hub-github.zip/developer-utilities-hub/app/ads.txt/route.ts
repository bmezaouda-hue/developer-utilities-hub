const GOOGLE_DIRECT_LINE = "google.com, %CLIENT%, DIRECT, f08c47fec0942fa0";

export const dynamic = "force-static";

export function GET() {
  const client = (
    process.env.ADSENSE_CLIENT ??
    process.env.NEXT_PUBLIC_ADSENSE_CLIENT ??
    ""
  ).trim();

  const headers = {
    "content-type": "text/plain; charset=utf-8",
    "cache-control": "public, max-age=3600, must-revalidate"
  };

  if (!client.startsWith("pub-")) {
    return new Response(
      "# ads.txt غير مفعّل بعد.\n" +
        "# أضف ADSENSE_CLIENT=pub-XXXXXXXXXXXXXXX في .env.local ثم أعد النشر.\n" +
        "# يجب أن يحتوي على: " + GOOGLE_DIRECT_LINE.replace("%CLIENT%", "pub-XXXXXXXXXXXXXXX") + "\n",
      { headers }
    );
  }

  return new Response(`${GOOGLE_DIRECT_LINE.replace("%CLIENT%", client)}\n`, { headers });
}
