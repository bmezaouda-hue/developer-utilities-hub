import Link from "next/link";
import { ArrowLeft, Home, Search } from "lucide-react";
import { tools } from "@/lib/site";

export default function NotFound() {
  return (
    <div className="container-shell grid min-h-[70vh] place-items-center py-16 text-center">
      <div>
        <p className="code-font text-7xl font-black text-[var(--accent-strong)]">404</p>
        <h1 className="mt-4 text-2xl font-black tracking-tight md:text-3xl">الصفحة غير موجودة</h1>
        <p className="mx-auto mt-3 max-w-md text-sm leading-8 muted">
          ربما تم نقل الرابط أو حذفه. يمكنك العودة للرئيسية أو الانتقال مباشرة إلى إحدى الأدوات.
        </p>

        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <Link href="/" className="btn btn-primary">
            <Home size={16} aria-hidden />
            الرئيسية
          </Link>
          <Link href="/tools" className="btn btn-ghost">
            <Search size={16} aria-hidden />
            كل الأدوات
          </Link>
        </div>

        <ul className="mt-10 grid gap-2 text-sm sm:grid-cols-2">
          {tools.map(tool => (
            <li key={tool.slug}>
              <Link
                href={tool.href}
                className="flex items-center justify-center gap-2 text-[var(--muted)] transition hover:text-[var(--accent-strong)]"
              >
                {tool.title}
                <ArrowLeft size={14} aria-hidden />
              </Link>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
