"use client";

import { useEffect } from "react";
import Link from "next/link";
import { RotateCcw, TriangleAlert } from "lucide-react";

export default function GlobalError({
  error,
  reset
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <div className="container-shell grid min-h-[70vh] place-items-center py-16 text-center">
      <div>
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-red-500/10 text-red-500">
          <TriangleAlert size={26} aria-hidden />
        </span>
        <h1 className="mt-5 text-2xl font-black tracking-tight md:text-3xl">حدث خطأ غير متوقع</h1>
        <p className="mx-auto mt-3 max-w-md text-sm leading-8 muted">
          تعذّر عرض هذه الصفحة. يمكنك إعادة المحاولة، أو العودة للرئيسية ومتابعة العمل من هناك.
        </p>
        {error.digest && (
          <p className="code-font mt-3 text-xs muted" dir="ltr">
            Reference: {error.digest}
          </p>
        )}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
          <button onClick={reset} className="btn btn-primary">
            <RotateCcw size={16} aria-hidden />
            إعادة المحاولة
          </button>
          <Link href="/" className="btn btn-ghost">
            الرئيسية
          </Link>
        </div>
      </div>
    </div>
  );
}
