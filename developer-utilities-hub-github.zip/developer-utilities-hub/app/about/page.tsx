import type { Metadata } from "next";
import Link from "next/link";
import { Gauge, Lock, Mail, ShieldCheck, Sparkles } from "lucide-react";
import { PageShell } from "@/components/PageShell";
import { owner, siteConfig, tools } from "@/lib/site";

export const metadata: Metadata = {
  title: "من نحن",
  description: "تعرف على هدف Developer Utilities Hub ومبادئه.",
  alternates: { canonical: "/about" }
};

const principles = [
  {
    icon: Lock,
    title: "خصوصية افتراضية",
    description: "نفضّل المعالجة داخل المتصفح كلما أمكن، حتى لا تمسّ بياناتك أي خادم."
  },
  {
    icon: Gauge,
    title: "أداء حقيقي",
    description: "صفحات خفيفة وسريعة، مع lazily-loaded وثبات في التخطيط."
  },
  {
    icon: Sparkles,
    title: "بسيطة بالعربية",
    description: "واجهة عربية واضحة ومن اليمين إلى اليسار منذ البداية."
  }
];

export default function AboutPage() {
  return (
    <PageShell
      title="من نحن"
      badge="عن المنصة"
      description={`${siteConfig.name} منصة عربية لأدوات المطورين، تعمل مباشرة في المتصفح بدون خوادم وبلا تسجيل.`}
      updated="سبتمبر 2026"
    >
      <h2>هدف المنصة</h2>
      <p>
        نركّز على الأدوات التي توفر وقتاً في المهام المتكررة: تنسيق الأكواد، التحقق من صحتها،
        وفحص البيانات. الأولوية دائماً لوضوح النتيجة وسهولة نسخها، بدل الواجهات المعقدة.
      </p>

      <h2>مبادئنا</h2>
      <div className="my-6 grid gap-4 not-prose sm:grid-cols-3">
        {principles.map(principle => (
          <div key={principle.title} className="rounded-2xl border border-[var(--border)] p-4">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent-strong)]">
              <principle.icon size={18} aria-hidden />
            </span>
            <h3 className="mt-3 text-sm font-bold">{principle.title}</h3>
            <p className="mt-1 text-xs leading-7 muted">{principle.description}</p>
          </div>
        ))}
      </div>

      <h2>مالك الموقع ومشرفه</h2>
      <div className="not-prose my-6 flex flex-col gap-5 rounded-2xl border border-[var(--border)] p-5 sm:flex-row sm:items-center sm:justify-between">
        <div className="flex items-center gap-4">
          <span className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-[var(--accent)] to-[var(--accent-strong)] text-xl font-black text-[var(--accent-ink)]">
            {owner.initials}
          </span>
          <div>
            <p className="text-base font-extrabold">{owner.name}</p>
            <p className="text-sm muted">{owner.role}</p>
            <p className="mt-1 flex items-center gap-1.5 text-xs muted">
              <ShieldCheck size={13} className="text-[var(--accent)]" aria-hidden />
              هذا هو المالك الوحيد والمسؤول عن المحتوى؛ لا يوجد في الموقع حسابات أو لوحة تحكم.
            </p>
          </div>
        </div>
        <a href={`mailto:${owner.email}`} className="btn btn-ghost shrink-0">
          <Mail size={15} aria-hidden />
          <span dir="ltr">{owner.email}</span>
        </a>
      </div>

      <h2>الأدوات المتاحة</h2>
      <ul>
        {tools.map(tool => (
          <li key={tool.slug}>
            <Link href={tool.href}>{tool.title}</Link> — {tool.description}
          </li>
        ))}
      </ul>

      <h2>مساهماتك</h2>
      <p>
        المنصة مفتوحة للاقتراحات. إذا كانت لديك فكرة أداة تختصر عليك وقتاً يومياً، راسلنا عبر صفحة{" "}
        <Link href="/contact">اتصل بنا</Link> وسننظر فيها.
      </p>
    </PageShell>
  );
}
