﻿import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Check, Keyboard, ShieldCheck, Sparkles } from "lucide-react";
import { JsonFormatter } from "@/components/JsonFormatter";
import { AdSlot } from "@/components/AdSlot";
import { ToolCard } from "@/components/ToolCard";
import { absoluteUrl, siteConfig, tools } from "@/lib/site";

const tool = tools.find(item => item.slug === "json-formatter")!;

export const metadata: Metadata = {
  title: "منسق ومصحح JSON — JSON Formatter & Validator",
  description: tool.description,
  keywords: tool.keywords.split(" "),
  alternates: { canonical: tool.href },
  openGraph: {
    type: "website",
    title: `${tool.title} | ${siteConfig.shortName}`,
    description: tool.description,
    url: absoluteUrl(tool.href)
  }
};

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: tool.faq.map(item => ({
    "@type": "Question",
    name: item.question,
    acceptedAnswer: { "@type": "Answer", text: item.answer }
  }))
};

const softwareSchema = {
  "@context": "https://schema.org",
  "@type": "SoftwareApplication",
  name: `${tool.title} — ${siteConfig.name}`,
  applicationCategory: "DeveloperApplication",
  operatingSystem: "Any (web browser)",
  url: absoluteUrl(tool.href),
  description: tool.description,
  offers: { "@type": "Offer", price: "0", priceCurrency: "USD" },
  featureList: tool.features
};

const structuredData = {
  "@context": "https://schema.org",
  "@graph": [softwareSchema, faqSchema]
};

export default function JsonFormatterPage() {
  if (!tool) notFound();

  return (
    <div className="container-shell py-10 md:py-14">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <nav aria-label="مسار التنقل" className="mb-6 flex flex-wrap items-center gap-2 text-xs font-semibold muted">
        <Link href="/" className="transition hover:text-[var(--accent-strong)]">
          الرئيسية
        </Link>
        <ArrowLeft size={13} aria-hidden />
        <Link href="/tools" className="transition hover:text-[var(--accent-strong)]">
          الأدوات
        </Link>
        <ArrowLeft size={13} aria-hidden />
        <span className="text-[var(--foreground)]">{tool.title}</span>
      </nav>

      <header className="mb-8 max-w-3xl">
        <div className="flex flex-wrap items-center gap-2">
          <span className="chip chip-accent">
            <Sparkles size={13} aria-hidden />
            مجاني وبدون تسجيل
          </span>
          <span className="chip">
            <ShieldCheck size={13} aria-hidden />
            المعالجة في متصفحك
          </span>
          <span className="chip">
            <Keyboard size={13} aria-hidden />
            Ctrl + Enter
          </span>
        </div>
        <h1 className="mt-4 text-3xl font-black tracking-tight md:text-4xl">
          منسق ومصحح أكواد <span className="text-[var(--accent-strong)]">JSON</span>
        </h1>
        <p className="mt-3 leading-8 muted">{tool.description}</p>
      </header>

      <AdSlot label="Banner Ad — JSON Tool" />

      <JsonFormatter />

      <AdSlot label="Responsive Ad — أسفل الأداة" format="rectangle" />

      <div className="mt-10 grid gap-6 lg:grid-cols-2">
        <article className="prose-lite card p-6 md:p-8">
          <h2>كيفية الاستخدام</h2>
          <p>
            الصق بيانات JSON في مربع الإدخال على اليمين، ثم اختر <strong>Format</strong> للحصول على
            نص منسّق، أو <strong>Minify</strong> للحصول على نسخة مضغوطة. إذا كان النص غير صالح
            ستظهر رسالة توضّح رقم السطر والعمود，方便 تحديد المشكلة فوراً.
          </p>
          <h2>خيارات متقدمة</h2>
          <ul>
            <li>اختر المسافة البادئة: 2 أو 4 مسافات أو Tab.</li>
            <li>رتّب المفاتيح أبجدياً أو حسب حجم القيمة.</li>
            <li>نزّل النتيجة كملف <code>.json</code> أو انسخها مباشرة.</li>
            <li>استخدم عجلة الفأرة مع <code>Ctrl</code> للتكبير داخل النتيجة.</li>
          </ul>
        </article>

        <article className="prose-lite card p-6 md:p-8">
          <h2>الخصوصية والأمان</h2>
          <p>
            الأداة مكتوبة بالكامل في جانب العميل (Client-side). لا يوجد أي طلب شبكة يرسل محتواك،
            ولا نحفظ نسخاً من ملفاتك. بمجرد تحديث الصفحة أو إغلاقها تختفي كل البيانات.
          </p>
          <h2>متى أستخدمها؟</h2>
          <ul>
            <li>مراجعة ملفات <code>package.json</code> أو ملفات الإعدادات قبل Commit.</li>
            <li>استخراج جزء من ردود API كبيرة.</li>
            <li>التأكد من صحة بيانات قبل إرسالها لنظام آخر.</li>
            <li>تقليل حجم JSON لتوفير البيانات في النطاق.</li>
          </ul>
        </article>
      </div>

      <section className="py-12">
        <h2 className="text-2xl font-black tracking-tight">مزايا الأداة</h2>
        <ul className="mt-5 grid gap-3 sm:grid-cols-2">
          {tool.features.map(feature => (
            <li key={feature} className="card flex items-start gap-3 p-4 text-sm">
              <Check size={17} className="mt-0.5 shrink-0 text-[var(--accent-strong)]" aria-hidden />
              <span className="muted">{feature}</span>
            </li>
          ))}
        </ul>
      </section>

      <section className="py-8">
        <h2 className="text-2xl font-black tracking-tight">أسئلة شائعة</h2>
        <div className="mt-5 grid gap-3">
          {tool.faq.map(faq => (
            <details key={faq.question} className="card group p-5">
              <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-bold marker:hidden">
                {faq.question}
                <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--accent-soft)] text-[var(--accent-strong)] transition-transform group-open:rotate-45">
                  +
                </span>
              </summary>
              <p className="mt-3 text-sm leading-8 muted">{faq.answer}</p>
            </details>
          ))}
        </div>
      </section>

      <section className="py-10">
        <div className="mb-5 flex items-center justify-between">
          <h2 className="text-2xl font-black tracking-tight">أدوات أخرى</h2>
          <Link href="/tools" className="text-sm font-semibold text-[var(--accent-strong)]">
            كل الأدوات ←
          </Link>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {tools
            .filter(item => item.slug !== tool.slug)
            .map(item => (
              <ToolCard key={item.slug} tool={item} compact />
            ))}
          <Link href="/contact" className="card grid place-items-center gap-2 p-5 text-center transition hover:border-[var(--accent)]">
            <span className="text-3xl">+</span>
            <span className="text-sm font-bold">اقترح أداة جديدة</span>
            <span className="text-xs muted">أخبرنا بما تحتاجه</span>
          </Link>
        </div>
      </section>
    </div>
  );
}
