﻿import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Compass } from "lucide-react";
import { AdSlot } from "@/components/AdSlot";
import { ToolsExplorer } from "@/components/ToolsExplorer";
import { categories, siteConfig, tools } from "@/lib/site";

export const metadata: Metadata = {
  title: "كل الأدوات",
  description:
    "فهرس أدوات المطورين المتاحة في Developer Utilities Hub، يعمل كلها داخل المتصفح بدون رفع بياناتك.",
  alternates: { canonical: "/tools" },
  openGraph: {
    title: `كل الأدوات | ${siteConfig.shortName}`,
    description: "فهرس كامل لأدوات المطورين التي تعمل محلياً في المتصفح."
  }
};

export default function ToolsPage() {
  return (
    <div className="container-shell py-12 md:py-16">
      <nav aria-label="مسار التنقل" className="mb-6 flex items-center gap-2 text-xs font-semibold muted">
        <Link href="/" className="transition hover:text-[var(--accent-strong)]">
          الرئيسية
        </Link>
        <ArrowLeft size={13} aria-hidden />
        <span className="text-[var(--foreground)]">الأدوات</span>
      </nav>

      <header className="max-w-2xl">
        <span className="chip chip-accent">
          <Compass size={14} aria-hidden />
          {tools.length} أداة متاحة
        </span>
        <h1 className="mt-4 text-3xl font-black tracking-tight md:text-4xl">كل الأدوات</h1>
        <p className="mt-3 leading-8 muted">
          كل أداة هنا تعمل في متصفحك مباشرة، بلا تسجيل وبلا إرسال بيانات إلى أي خادم. نضيف أدوات
          جديدة تدريجياً حسب الطلب.
        </p>
      </header>

      <AdSlot label="Banner Ad — صفحة الأدوات" />

      <div className="py-4">
        <ToolsExplorer tools={tools} />
      </div>

      <section className="py-10">
        <h2 className="text-xl font-black">تصنيفات</h2>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {categories.map(category => (
            <div key={category.id} className="card p-5">
              <h3 className="font-bold">{category.title}</h3>
              <p className="mt-1 text-sm muted">{category.description}</p>
            </div>
          ))}
        </div>
      </section>

      <AdSlot label="Responsive Ad — أسفل صفحة الأدوات" />
    </div>
  );
}
