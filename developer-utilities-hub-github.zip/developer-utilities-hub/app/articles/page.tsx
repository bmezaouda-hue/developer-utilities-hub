import type { Metadata } from "next";
import { ArticleCard } from "@/components/ArticleCard";
import { articles } from "@/lib/articles";

export const metadata: Metadata = {
  title: "المقالات",
  description:
    "مقالات وأدلة عملية للمطورين: أخطاء JSON الشائعة، توليد أنواع TypeScript من البيانات، تحسين أداء Next.js، وتشخيص مشاكل الواجهات البرمجية."
};

export default function ArticlesPage() {
  const [featured, ...rest] = articles;

  return (
    <div className="container-shell py-10 md:py-14">
      <header className="max-w-2xl">
          <span className="chip chip-accent">مدوّنة</span>
          <h1 className="mt-4 text-3xl font-black tracking-tight md:text-4xl">مقالات وأدلة عملية</h1>
          <p className="mt-4 leading-8 muted">
            شروحات مكتوبة للمطورين العرب، تركّز على مشكلات حقيقية واجهتها أثناء العمل: أخطاء في
            البيانات، سلامة الأنواع، الأداء، وتشخيص الأعطال. كل مقال مكتوب ليكون مرجعاً عملياً
            يمكنك العودة إليه أثناء العمل.
          </p>
        </header>

      <div className="mt-10 grid gap-6">
        {featured && <ArticleCard article={featured} featured />}

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {rest.map(article => (
            <ArticleCard key={article.slug} article={article} />
          ))}
        </div>
      </div>
    </div>
  );
}
