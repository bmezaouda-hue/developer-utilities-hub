import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CalendarDays, Clock, FileText } from "lucide-react";
import { ArticleBody } from "@/components/ArticleBody";
import { Breadcrumbs } from "@/components/PageShell";
import { articles, getArticle } from "@/lib/articles";
import { absoluteUrl, siteConfig } from "@/lib/site";

export function generateStaticParams() {
  return articles.map(article => ({ slug: article.slug }));
}

export async function generateMetadata({
  params
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const article = getArticle(slug);
  if (!article) return { title: "المقال غير موجود" };

  return {
    title: article.title,
    description: article.description,
    keywords: article.keywords,
    alternates: { canonical: `/articles/${article.slug}` },
    openGraph: {
      title: article.title,
      description: article.description,
      type: "article",
      url: absoluteUrl(`/articles/${article.slug}`),
      publishedTime: article.publishedAt,
      modifiedTime: article.updatedAt ?? article.publishedAt,
      images: [{ url: article.cover, width: 1600, height: 900, alt: article.coverAlt }]
    },
    twitter: {
      card: "summary_large_image",
      title: article.title,
      description: article.description,
      images: [article.cover]
    }
  };
}

function formatDate(value: string) {
  return new Intl.DateTimeFormat("ar-EG", {
    year: "numeric",
    month: "long",
    day: "numeric"
  }).format(new Date(value));
}

export default async function ArticlePage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const article = getArticle(slug);
  if (!article) notFound();

  const toc = article.body.filter(
    (block): block is Extract<typeof block, { type: "h2" }> => block.type === "h2"
  );
  const related = articles.filter(item => item.slug !== article.slug).slice(0, 3);

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: article.title,
    description: article.description,
    image: [article.cover],
    datePublished: article.publishedAt,
    dateModified: article.updatedAt ?? article.publishedAt,
    inLanguage: "ar",
    keywords: article.keywords,
    author: { "@type": "Organization", name: siteConfig.name },
    publisher: { "@type": "Organization", name: siteConfig.name },
    mainEntityOfPage: { "@type": "WebPage", "@id": absoluteUrl(`/articles/${article.slug}`) }
  };

  return (
    <>
      <div className="container-shell py-10 md:py-14">
        <Breadcrumbs items={[{ href: "/articles", label: "المقالات" }, { href: "#", label: article.title }]} />

        <article className="card overflow-hidden">
          <div className="relative">
            <Image
              src={article.cover}
              alt={article.coverAlt}
              width={1600}
              height={900}
              priority
              sizes="(max-width: 1140px) 100vw, 1140px"
              className="article-cover"
            />
          </div>

          <div className="p-7 md:p-10">
            <header className="border-b border-[var(--border)] pb-6">
              <span className="chip chip-accent">{article.category}</span>
              <h1 className="mt-4 text-2xl font-black leading-snug tracking-tight md:text-4xl">
                {article.title}
              </h1>
              <p className="mt-4 max-w-3xl leading-8 muted">{article.description}</p>

              <div className="mt-5 flex flex-wrap items-center gap-4 text-xs muted">
                <span className="flex items-center gap-1.5">
                  <CalendarDays size={14} aria-hidden />
                  {formatDate(article.publishedAt)}
                </span>
                {article.updatedAt && (
                  <span>آخر تحديث: {formatDate(article.updatedAt)}</span>
                )}
                <span className="flex items-center gap-1.5">
                  <Clock size={14} aria-hidden />
                  {article.readingMinutes} دقائق قراءة
                </span>
              </div>
            </header>

            <div className="grid gap-10 pt-8 lg:grid-cols-[1fr_15rem]">
              <ArticleBody blocks={article.body} />

              {toc.length > 1 && (
                <aside className="lg:sticky lg:top-24 lg:h-fit">
                  <nav className="toc" aria-label="محتويات المقال">
                    <p className="mb-2 flex items-center gap-2 text-xs font-black">
                      <FileText size={14} aria-hidden />
                      في هذا المقال
                    </p>
                    {toc.map(item => (
                      <a key={item.id} href={`#${item.id}`}>
                        {item.text}
                      </a>
                    ))}
                  </nav>
                </aside>
              )}
            </div>
          </div>
        </article>

        {related.length > 0 && (
          <section className="mt-10">
            <h2 className="text-xl font-black tracking-tight">مقالات ذات صلة</h2>
            <div className="mt-5 grid gap-4 sm:grid-cols-3">
              {related.map(item => (
                <Link
                  key={item.slug}
                  href={`/articles/${item.slug}`}
                  className="card group p-5 transition hover:-translate-y-1 hover:shadow-[var(--shadow-md)]"
                >
                  <span className="text-[0.7rem] font-bold text-[var(--accent-strong)]">
                    {item.category}
                  </span>
                  <h3 className="mt-2 text-sm font-black leading-snug">{item.title}</h3>
                  <span className="mt-3 flex items-center gap-1.5 text-xs font-semibold text-[var(--accent-strong)]">
                    اقرأ
                    <ArrowLeft size={13} aria-hidden />
                  </span>
                </Link>
              ))}
            </div>
          </section>
        )}
      </div>

      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
    </>
  );
}
