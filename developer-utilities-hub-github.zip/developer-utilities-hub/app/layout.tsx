import type { Metadata, Viewport } from "next";
import "./globals.css";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ThemeProvider, themeInitScript } from "@/components/ThemeProvider";
import { ConsentProvider } from "@/components/ConsentProvider";
import { SiteConfigProvider } from "@/components/SiteConfigProvider";
import { PageViewTracker } from "@/components/PageViewTracker";
import { AutoPageSkin } from "@/components/AutoPageSkin";
import { absoluteUrl, owner, siteConfig, tools, verification } from "@/lib/site";

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: siteConfig.themeColorLight },
    { media: "(prefers-color-scheme: dark)", color: siteConfig.themeColorDark }
  ]
};

export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.url),
  title: {
    default: siteConfig.title,
    template: `%s | ${siteConfig.shortName}`
  },
  description: siteConfig.description,
  applicationName: siteConfig.name,
  authors: [{ name: owner.name, url: absoluteUrl("/about") }],
  creator: owner.name,
  publisher: siteConfig.name,
  category: "developer tools",
  keywords: [
    "developer tools",
    "json formatter",
    "json validator",
    "json beautifier",
    "json to typescript",
    "web utilities",
    "أدوات المطورين",
    "تنسيق JSON"
  ],
  alternates: { canonical: "/" },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large", "max-snippet": -1 }
  },
  formatDetection: { telephone: false, address: false, email: false },
  other: {
    ...(verification.googleSite ? { "google-site-verification": verification.googleSite } : {}),
    ...(verification.googleAdsense.startsWith("ca-pub-")
      ? { "google-adsense-account": verification.googleAdsense }
      : {})
  },
  openGraph: {
    type: "website",
    siteName: siteConfig.name,
    title: siteConfig.title,
    description: siteConfig.description,
    url: absoluteUrl("/"),
    locale: siteConfig.locale
  },
  twitter: {
    card: "summary_large_image",
    title: siteConfig.title,
    description: siteConfig.description
  }
};

const structuredData = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "WebSite",
      "@id": absoluteUrl("/#website"),
      url: absoluteUrl("/"),
      name: siteConfig.name,
      description: siteConfig.description,
      inLanguage: "ar",
      publisher: { "@id": absoluteUrl("/#organization") }
    },
    {
      "@type": "Organization",
      "@id": absoluteUrl("/#organization"),
      name: siteConfig.name,
      url: absoluteUrl("/"),
      email: siteConfig.email,
      logo: absoluteUrl("/icon.svg"),
      founder: { "@type": "Person", name: owner.name, email: owner.email },
      contactPoint: {
        "@type": "ContactPoint",
        contactType: "customer support",
        email: siteConfig.email,
        url: absoluteUrl("/contact"),
        availableLanguage: ["ar", "en"]
      }
    },
    {
      "@type": "ItemList",
      "@id": absoluteUrl("/#tools"),
      name: "أدوات المطورين",
      numberOfItems: tools.length,
      itemListElement: tools.map((tool, index) => ({
        "@type": "ListItem",
        position: index + 1,
        name: tool.title,
        url: absoluteUrl(tool.href),
        description: tool.description
      }))
    }
  ]
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang={siteConfig.language} dir="rtl" suppressHydrationWarning>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
        />
        <link rel="alternate" hrefLang="ar" href={absoluteUrl("/")} />
      </head>
      <body>
        <div className="app-bg" aria-hidden="true" />
        <a href="#main" className="skip-link">
          تخطَّ إلى المحتوى
        </a>
        <ThemeProvider>
          <SiteConfigProvider>
            <ConsentProvider>
              <PageViewTracker />
              <Header />
              <main id="main" className="min-h-[60vh]">
                <AutoPageSkin>{children}</AutoPageSkin>
              </main>
              <Footer />
            </ConsentProvider>
          </SiteConfigProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
