import { Suspense } from "react";
import { redirect } from "next/navigation";
import { Breadcrumbs } from "@/components/PageShell";
import { AdminLogin } from "@/components/admin/AdminLogin";
import { isAuthenticated } from "@/lib/admin/guard";
import { adminEnabled } from "@/lib/admin/session";

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  if (!adminEnabled()) {
    return (
      <div className="card mx-auto max-w-lg p-8 text-center">
        <h1 className="text-xl font-black">لوحة التحكم غير مفعّلة</h1>
        <p className="mt-3 text-sm leading-8 muted">
          أضف <code className="code-font">ADMIN_PASSWORD_HASH</code> (أو{" "}
          <code className="code-font">ADMIN_PASSWORD</code>) في ملف البيئة ثم أعد البناء.
        </p>
      </div>
    );
  }

  if (await isAuthenticated()) redirect("/admin");

  return (
    <Suspense fallback={null}>
      <div className="container-shell py-10">
        <Breadcrumbs items={[{ href: "#", label: "لوحة التحكم" }]} />
        <AdminLogin />
      </div>
    </Suspense>
  );
}
