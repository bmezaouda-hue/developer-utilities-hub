import { redirect } from "next/navigation";
import { AdminPanel } from "@/components/admin/AdminPanel";
import { isAuthenticated } from "@/lib/admin/guard";
import { storeDriver } from "@/lib/admin/store";
import { readSettings, readStats, readTools } from "@/lib/admin/store";
import { tools } from "@/lib/site";

export const dynamic = "force-dynamic";

export default async function AdminPage() {
  if (!(await isAuthenticated())) redirect("/admin/login");

  const [settings, overrides, stats] = await Promise.all([
    readSettings(),
    readTools(),
    readStats(14)
  ]);

  return (
    <AdminPanel
      initialSettings={settings}
      initialTools={overrides}
      initialStats={stats}
      knownTools={tools}
      driver={storeDriver}
    />
  );
}
