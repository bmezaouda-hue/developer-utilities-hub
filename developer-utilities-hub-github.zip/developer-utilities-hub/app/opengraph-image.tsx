import { ImageResponse } from "next/og";
import { siteConfig } from "@/lib/site";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";
export const alt = siteConfig.name;

export default function OpengraphImage() {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "center",
          padding: 80,
          background: "linear-gradient(135deg, #04110d 0%, #062b22 55%, #0b4c3a 100%)",
          color: "#ffffff",
          fontFamily: "sans-serif"
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 18 }}>
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: 18,
              background: "linear-gradient(135deg, #34d399, #047857)",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              fontSize: 34,
              fontWeight: 800
            }}
          >
            {"</>"}
          </div>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <div style={{ fontSize: 30, fontWeight: 700, opacity: 0.85 }}>Developer Utilities</div>
            <div style={{ fontSize: 46, fontWeight: 800 }}>{siteConfig.shortName}</div>
          </div>
        </div>

        <div style={{ marginTop: 48, fontSize: 76, fontWeight: 800, lineHeight: 1.15 }}>
          Fast, private developer tools
        </div>
        <div style={{ marginTop: 24, fontSize: 32, opacity: 0.75 }}>
          100% client-side &middot; No sign-up &middot; Arabic &amp; English ready
        </div>

        <div style={{ marginTop: 56, display: "flex", gap: 14 }}>
          {["JSON Formatter", "JSON Validator", "Minify", "Sort Keys"].map(label => (
            <div
              key={label}
              style={{
                padding: "12px 22px",
                borderRadius: 999,
                border: "2px solid rgba(52,211,153,0.45)",
                color: "#a7f3d0",
                fontSize: 26,
                fontWeight: 600
              }}
            >
              {label}
            </div>
          ))}
        </div>
      </div>
    ),
    size
  );
}
