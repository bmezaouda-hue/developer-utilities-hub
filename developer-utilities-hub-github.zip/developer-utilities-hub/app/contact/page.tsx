import type { Metadata } from "next";
import { Clock, MessageSquare, ShieldCheck, Wrench } from "lucide-react";
import { Breadcrumbs } from "@/components/PageShell";
import { ContactForm } from "@/components/ContactForm";
import { owner } from "@/lib/site";

export const metadata: Metadata = {
  title: "اتصل بنا",
  description: "تواصل مع فريق Developer Utilities Hub: اقتراحات، بلاغات، أو أسئلة.",
  alternates: { canonical: "/contact" }
};

const reasons = [
  {
    icon: Wrench,
    title: "اقتراح أداة",
    description: "لديك فكرة أداة تختصر عليك وقتاً؟ أرسلها وسنقيّمها."
  },
  {
    icon: MessageSquare,
    title: "بلاغ عن خطأ",
    description: "وجدت مشكلة في أداة أو رابط؟ أخبرنا بخطوات إعادة إنتاج المشكلة."
  },
  {
    icon: Clock,
    title: "استفسار عام",
    description: "أسئلة حول الخصوصية أو الاستخدام أو حالة الموقع."
  }
];

export default function ContactPage() {
  return (
    <div className="container-shell py-10 md:py-14">
      <Breadcrumbs items={[{ href: "#", label: "اتصل بنا" }]} />

      <div className="grid gap-10 lg:grid-cols-[1.1fr_1fr]">
        <div>
          <span className="chip chip-accent">دعم وتواصل</span>
          <h1 className="mt-4 text-3xl font-black tracking-tight md:text-4xl">اتصل بنا</h1>
          <p className="mt-4 max-w-xl leading-8 muted">
            نرحّب بكل ملاحظة أو اقتراح. النموذج التالي يفتح رسالة في برنامج البريد على جهازك، ولا
            تُخزَّن أي رسالة في قاعدة بيانات لدينا.
          </p>

          <ul className="mt-8 grid gap-4">
            {reasons.map(reason => (
              <li key={reason.title} className="card flex gap-4 p-4">
                <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent-strong)]">
                  <reason.icon size={18} aria-hidden />
                </span>
                <div>
                  <h2 className="text-sm font-bold">{reason.title}</h2>
                  <p className="mt-1 text-sm muted">{reason.description}</p>
                </div>
              </li>
            ))}
          </ul>

          <p className="mt-8 text-sm muted">
            تفضّل التواصل بالبريد مباشرة؟ راسلنا على{" "}
            <a
              href={`mailto:${owner.email}`}
              className="font-semibold text-[var(--accent-strong)] underline underline-offset-4"
              dir="ltr"
            >
              {owner.email}
            </a>
          </p>

          <p className="mt-4 flex items-start gap-2 text-xs leading-7 muted">
            <ShieldCheck size={14} className="mt-1 shrink-0 text-[var(--accent)]" aria-hidden />
            {owner.name} — {owner.role}، وهو المسؤول الوحيد عن هذا الموقع ومحتواه. لا نشارك
            الرسائل مع أي طرف ثالث.
          </p>
        </div>

        <div className="card h-fit p-6 md:p-8">
          <h2 className="text-lg font-extrabold">أرسل رسالة</h2>
          <p className="mt-1 text-sm muted">الحقول المعلّمة بـ * مطلوبة.</p>
          <ContactForm />
        </div>
      </div>
    </div>
  );
}
