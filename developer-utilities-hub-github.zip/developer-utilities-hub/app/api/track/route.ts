import { NextResponse } from "next/server";
import { trackView } from "@/lib/admin/store";

export const dynamic = "force-dynamic";

const BLOCKED = ["/admin", "/api"];

export async function POST(request: Request) {
  let path = "";
  try {
    const body = (await request.json()) as { path?: unknown };
    path = typeof body.path === "string" ? body.path : "";
  } catch {
    return NextResponse.json({ error: "invalid_request" }, { status: 400 });
  }

  if (!path || BLOCKED.some(prefix => path.startsWith(prefix))) {
    return new NextResponse(null, { status: 204 });
  }

  await trackView(path);
  return new NextResponse(null, { status: 204 });
}
