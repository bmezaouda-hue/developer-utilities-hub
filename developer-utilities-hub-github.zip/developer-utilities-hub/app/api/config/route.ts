import { NextResponse } from "next/server";
import { readSettings, readTools } from "@/lib/admin/store";
import type { PublicConfig } from "@/lib/admin/types";

export const revalidate = 0;

export async function GET() {
  const settings = await readSettings();
  const payload: PublicConfig = {
    settings: {
      ownerName: settings.ownerName,
      contactEmail: settings.contactEmail,
      siteUrl: settings.siteUrl,
      announcement: settings.announcement,
      maintenance: settings.maintenance,
      adsEnabled: settings.adsEnabled,
      trackVisits: settings.trackVisits
    },
    tools: await readTools()
  };
  return NextResponse.json(payload, {
    headers: { "cache-control": "public, max-age=60, stale-while-revalidate=300" }
  });
}
