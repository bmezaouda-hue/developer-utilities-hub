import { NextResponse } from "next/server";
import { isAuthenticated } from "@/lib/admin/guard";
import { adminEnabled } from "@/lib/admin/session";

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ enabled: adminEnabled(), authenticated: await isAuthenticated() });
}
