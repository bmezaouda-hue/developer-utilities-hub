import { NextResponse } from "next/server";
import { badRequest, isAuthenticated, unauthorized } from "@/lib/admin/guard";
import { readTools, writeTools } from "@/lib/admin/store";
import { tools } from "@/lib/site";
import type { ToolOverrides } from "@/lib/admin/types";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAuthenticated())) return unauthorized();
  return NextResponse.json({ tools: await readTools(), known: tools.map(tool => tool.slug) });
}

export async function POST(request: Request) {
  if (!(await isAuthenticated())) return unauthorized();

  let incoming: ToolOverrides;
  try {
    incoming = ((await request.json()) as { tools?: ToolOverrides })?.tools ?? {};
  } catch {
    return badRequest("invalid_request");
  }

  const allowed = new Set(tools.map(tool => tool.slug));
  const filtered = Object.fromEntries(
    Object.entries(incoming).filter(([slug]) => allowed.has(slug))
  ) as ToolOverrides;

  return NextResponse.json({ tools: await writeTools(filtered) });
}
