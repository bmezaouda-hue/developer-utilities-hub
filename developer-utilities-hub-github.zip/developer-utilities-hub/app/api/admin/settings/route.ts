import { NextResponse } from "next/server";
import { badRequest, isAuthenticated, unauthorized } from "@/lib/admin/guard";
import { readSettings, writeSettings } from "@/lib/admin/store";
import type { AdminSettings } from "@/lib/admin/types";

export const dynamic = "force-dynamic";

export async function GET() {
  if (!(await isAuthenticated())) return unauthorized();
  return NextResponse.json({ settings: await readSettings() });
}

export async function POST(request: Request) {
  if (!(await isAuthenticated())) return unauthorized();

  let body: Partial<AdminSettings>;
  try {
    body = ((await request.json()) as { settings?: Partial<AdminSettings> })?.settings ?? {};
  } catch {
    return badRequest("invalid_request");
  }

  const settings = await writeSettings(body);
  return NextResponse.json({ settings });
}
