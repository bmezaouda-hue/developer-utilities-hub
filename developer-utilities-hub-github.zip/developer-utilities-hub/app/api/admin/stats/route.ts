import { NextResponse } from "next/server";
import { isAuthenticated, unauthorized } from "@/lib/admin/guard";
import { readStats, resetStats } from "@/lib/admin/store";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (!(await isAuthenticated())) return unauthorized();
  const days = Number(new URL(request.url).searchParams.get("days") ?? 14);
  return NextResponse.json({ stats: await readStats(days), driver: process.env.UPSTASH_REDIS_REST_URL ? "upstash" : "file" });
}

export async function POST() {
  if (!(await isAuthenticated())) return unauthorized();
  await resetStats();
  return NextResponse.json({ ok: true });
}
