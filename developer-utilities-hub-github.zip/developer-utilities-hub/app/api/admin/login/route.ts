import { NextResponse, type NextRequest } from "next/server";
import { clearRateLimit, rateLimit } from "@/lib/admin/guard";
import {
  ADMIN_COOKIE,
  adminEnabled,
  createSessionToken,
  sessionCookieOptions,
  verifyPassword
} from "@/lib/admin/session";

export const dynamic = "force-dynamic";

function clientKey(request: NextRequest) {
  const forwarded = request.headers.get("x-forwarded-for") ?? "";
  return forwarded.split(",")[0].trim() || request.headers.get("x-real-ip") || "local";
}

export async function POST(request: NextRequest) {
  if (!adminEnabled()) {
    return NextResponse.json({ error: "admin_disabled" }, { status: 404 });
  }

  const key = `login:${clientKey(request)}`;
  const limit = rateLimit(key);
  if (!limit.ok) {
    return NextResponse.json(
      { error: "too_many_attempts", retryAfter: limit.retryAfter },
      { status: 429, headers: { "retry-after": String(limit.retryAfter) } }
    );
  }

  let password = "";
  try {
    const body = (await request.json()) as { password?: unknown };
    password = typeof body.password === "string" ? body.password : "";
  } catch {
    return NextResponse.json({ error: "invalid_request" }, { status: 400 });
  }

  if (!password || !verifyPassword(password)) {
    await new Promise(resolve => setTimeout(resolve, 400));
    return NextResponse.json({ error: "invalid_credentials" }, { status: 401 });
  }

  clearRateLimit(key);
  const response = NextResponse.json({ ok: true });
  response.cookies.set(ADMIN_COOKIE, await createSessionToken(), sessionCookieOptions);
  return response;
}
