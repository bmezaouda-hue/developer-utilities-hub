﻿import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowLeft,
  Braces,
  Gauge,
  KeyRound,
  Lock,
  MessageSquarePlus,
  ShieldCheck,
  Sparkles,
  Zap
} from "lucide-react";
import { AdSlot } from "@/components/AdSlot";
import { ToolsExplorer } from "@/components/ToolsExplorer";
import { absoluteUrl, siteConfig, tools } from "@/lib/site";

export const metadata: Metadata = {
  alternates: { canonical: "/" }
};

const features = [
  {
    icon: Lock,
    title: "خصوصية كاملة",
    description:
      "كل الأدوات تعمل داخل متصفحك عبر JavaScript. لا نرفع محتواك ولا نخزّنه ولا نحلله على خوادمنا."
  },
  {
    icon: Zap,
    title: "أداء فوري",
    description: "لا انتظار ولا معالجة على الخادم. النتيجة تظهر بمجرد الضغط على الزر."
  },
  {
    icon: KeyRound,
    title: "بدون تسجيل",
    description: "لا حسابات ولا بريد ولا تتبّع. افتح الأداة واستخدمها فوراً."
  }
];

const steps = [
  { title: "اختر الأداة", description: "تصفّح القائمة أو استخدم البحث في الصفحة الرئيسية." },
  { title: "الصق بياناتك", description: "ألصق النص أو الكود في مربع الإدخال." },
  { title: "انسخ النتيجة", description: "اضغط زر التنفيذ ثم انسخ أو نزّل النتيجة." }
];

const faqs = [
  {
    question: "هل أدوات الموقع مجانية؟",
    answer: "نعم، جميع الأدوات مجانية ولا تتطلب تسجيل حساب أو اشتراكاً."
  },
  {
    question: "هل تُرسل بياناتي إلى الخادم؟",
    answer:
      "لا. المعالجة تتم في متصفحك مباشرة، لذلك لا تغادر بياناتك جهازك، وحتى نتائج الأدوات لا تُحفظ في أي قاعدة بيانات."
  },
  {
    question: "هل يعمل الموقع على الجوال؟",
    answer: "نعم، الواجهات متجاوبة وتعمل على الجوال والحاسوب، مع دعم الوضع الداكن والفاتح."
  },
  {
    question: "هل يمكن اقتراح أداة جديدة؟",
    answer: "بالتأكيد. أرسل اقتراحك من صفحة اتصل بنا وسيتم рассматриته."
  }
];

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: [
    ...faqs.map(item => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer }
    })),
    ...tools[0].faq.map(item => ({
      "@type": "Question",
      name: item.question,
      acceptedAnswer: { "@type": "Answer", text: item.answer }
    }))
  ]
};

export default function HomePage() {
  return (
    <div>
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <section className="container-shell pb-12 pt-16 text-center md:pb-16 md:pt-24">
        <span className="chip chip-accent mx-auto">
          <Sparkles size={14} aria-hidden />
          {siteConfig.shortName} — أدوات تعمل داخل متصفحك
        </span>

        <h1 className="mx-auto mt-6 max-w-3xl text-4xl font-black leading-[1.25] tracking-tight md:text-6xl">
          أدوات المطورين، <span className="text-[var(--accent-strong)]">أسرع وأبسط</span> من أي
          خادم.
        </h1>

        <p className="mx-auto mt-5 max-w-2xl text-base leading-9 muted md:text-lg">
          {siteConfig.description}
        </p>

        <ToolsExplorer tools={tools} variant="hero" />

        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <Link href="/tools/json-formatter" className="btn btn-primary">
            <Braces size={17} aria-hidden />
            منسق JSON
          </Link>
          <Link href="/tools" className="btn btn-ghost">
            كل الأدوات
            <ArrowLeft size={16} aria-hidden />
          </Link>
        </div>

        <dl className="mx-auto mt-14 grid max-w-3xl grid-cols-3 gap-4">
          {[
            { value: "100%", label: "معالجة محلية" },
            { value: "0", label: "تسجيلات" },
            { value: "∞", label: "استخدامات" }
          ].map(stat => (
            <div key={stat.label} className="card px-3 py-4">
              <dt className="order-2 mt-1 text-xs font-semibold muted">{stat.label}</dt>
              <dd className="order-1 text-2xl font-black text-[var(--accent-strong)]">{stat.value}</dd>
            </div>
          ))}
        </dl>
      </section>

      <div className="container-shell">
        <AdSlot label="Banner Ad — أعلى شبكة الأدوات" />
      </div>

      <section className="container-shell py-16" id="tools">
        <div className="mb-8 text-center">
          <h2 className="text-3xl font-black tracking-tight md:text-4xl">كل الأدوات</h2>
          <p className="mt-3 muted">ابحث باسم الأداة أو وظيفتها.</p>
        </div>
        <ToolsExplorer tools={tools} />
      </section>

      <section className="container-shell py-8">
        <div className="grid gap-5 md:grid-cols-3">
          {features.map(feature => (
            <article key={feature.title} className="card p-6">
              <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-strong)]">
                <feature.icon size={20} aria-hidden />
              </span>
              <h3 className="mt-4 text-lg font-extrabold">{feature.title}</h3>
              <p className="mt-2 text-sm leading-8 muted">{feature.description}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="container-shell py-12">
        <div className="card overflow-hidden">
          <div className="grid gap-8 p-8 md:grid-cols-[1fr_1.2fr] md:p-10">
            <div>
              <span className="chip chip-accent">
                <Gauge size={14} aria-hidden />
                ثلاث خطوات فقط
              </span>
              <h2 className="mt-4 text-2xl font-black tracking-tight">كيف تستخدم أي أداة؟</h2>
              <p className="mt-3 text-sm leading-8 muted">
                واجهة موحّدة لكل الأدوات: نفس مكان الإدخال، نفس الأزرار، ونفس طريقة النسخ.
              </p>
              <Link href="/tools/json-formatter" className="btn btn-primary mt-6">
                ابدأ الآن
                <ArrowLeft size={16} aria-hidden />
              </Link>
            </div>
            <ol className="grid gap-4">
              {steps.map((step, index) => (
                <li key={step.title} className="flex gap-4 rounded-2xl border border-[var(--border)] p-4">
                  <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-[var(--accent-soft)] text-sm font-black text-[var(--accent-strong)]">
                    {index + 1}
                  </span>
                  <div>
                    <h3 className="font-bold">{step.title}</h3>
                    <p className="mt-1 text-sm muted">{step.description}</p>
                  </div>
                </li>
              ))}
            </ol>
          </div>
        </div>
      </section>

      <section className="container-shell py-12">
        <div className="mx-auto max-w-3xl">
          <h2 className="text-center text-2xl font-black tracking-tight md:text-3xl">
            الأسئلة الشائعة
          </h2>
          <div className="mt-8 grid gap-3">
            {faqs.map(faq => (
              <details key={faq.question} className="card group p-5">
                <summary className="flex cursor-pointer list-none items-center justify-between gap-4 font-bold marker:hidden">
                  {faq.question}
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-[var(--accent-soft)] text-[var(--accent-strong)] transition-transform group-open:rotate-45">
                    +
                  </span>
                </summary>
                <p className="mt-3 text-sm leading-8 muted">{faq.answer}</p>
              </details>
            ))}
          </div>
        </div>
      </section>

      <div className="container-shell">
        <AdSlot label="Responsive Ad — أسفل الصفحة" />
      </div>

      <section className="container-shell py-16">
        <div className="card grid-noise relative overflow-hidden p-8 text-center md:p-12">
          <div className="relative">
            <h2 className="text-2xl font-black tracking-tight md:text-3xl">تحتاج أداة غير موجودة؟</h2>
            <p className="mx-auto mt-3 max-w-xl text-sm leading-8 muted">
              أرسل لنا اقتراحك وسنضيفه إن كان ذلك مفيداً لمجتمع المطورين. كل الاقتراحات مرحّب بها.
            </p>
            <Link href="/contact" className="btn btn-primary mt-6">
              <MessageSquarePlus size={17} aria-hidden />
              اقترح أداة
            </Link>
            <p className="mt-6 text-xs muted">
              <ShieldCheck size={13} className="ms-1 inline" aria-hidden />
              الموقع مستقل تماماً: {absoluteUrl("/")} — لا نبيع بيانات ولا نشاركها.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
