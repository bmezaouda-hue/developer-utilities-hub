import type { ArtVariant } from "@/lib/page-themes";

export function PageArt({ variant }: { variant: ArtVariant }) {
  return (
    <svg
      className="page-art"
      viewBox="0 0 1440 720"
      preserveAspectRatio="xMidYMid slice"
      aria-hidden
      focusable="false"
    >
      <defs>
        <linearGradient id={`fade-${variant}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="currentColor" stopOpacity="0.5" />
          <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
        </linearGradient>
      </defs>

      {variant === "grid" && (
        <g fill="none" stroke="currentColor" strokeOpacity="0.22">
          {Array.from({ length: 16 }).map((_, row) =>
            Array.from({ length: 26 }).map((__, col) => (
              <circle
                key={`${row}-${col}`}
                cx={col * 58 + 30}
                cy={row * 48 + 26}
                r={row % 4 === col % 4 ? 3.4 : 1.5}
                fill="currentColor"
                fillOpacity={row % 4 === col % 4 ? 0.5 : 0.22}
                stroke="none"
              />
            ))
          )}
        </g>
      )}

      {variant === "circuit" && (
        <g fill="none" stroke="currentColor" strokeOpacity="0.28" strokeWidth="1.5">
          <path d="M0 180h240l60 60h300l60-60h420l60 60h300" />
          <path d="M0 420h180l60-60h360l60 60h360l60-60h300" />
          <path d="M0 300h120l60 60h540l60-60h360" strokeOpacity="0.16" />
          {[
            [300, 240],
            [660, 180],
            [1020, 240],
            [600, 360],
            [960, 420],
            [240, 420],
            [1380, 300]
          ].map(([cx, cy]) => (
            <g key={`${cx}-${cy}`}>
              <circle cx={cx} cy={cy} r="9" fill="currentColor" fillOpacity="0.32" stroke="none" />
              <circle cx={cx} cy={cy} r="17" strokeOpacity="0.18" />
            </g>
          ))}
        </g>
      )}

      {variant === "braces" && (
        <g fill="none" stroke="currentColor" strokeWidth="3" strokeOpacity="0.2" strokeLinecap="round">
          <path d="M430 90v54a44 44 0 0 1-44 44 44 44 0 0 0-44 44v60a44 44 0 0 1-44 44 44 44 0 0 0-44 44v54a44 44 0 0 0 44 44 44 44 0 0 1 44 44v54" />
          <path d="M1010 90v54a44 44 0 0 0 44 44 44 44 0 0 1 44 44v60a44 44 0 0 0 44 44 44 44 0 0 1 44 44v54a44 44 0 0 1-44 44 44 44 0 0 0-44 44v54" />
          <g strokeOpacity="0.12">
            <path d="M640 200h160M640 280h160M640 360h160M640 440h160" strokeWidth="2" />
          </g>
        </g>
      )}

      {variant === "layers" && (
        <g>
          {[
            { y: 150, o: 0.26, w: 720 },
            { y: 260, o: 0.2, w: 900 },
            { y: 370, o: 0.15, w: 1080 },
            { y: 480, o: 0.1, w: 620 }
          ].map(layer => (
            <path
              key={layer.y}
              d={`M720 ${layer.y}l${layer.w / 2} 52- ${layer.w / 2} 52- ${layer.w / 2}-52Z`}
              fill="currentColor"
              fillOpacity={layer.o}
            />
          ))}
        </g>
      )}

      {variant === "waves" && (
        <g fill="none" stroke="currentColor" strokeWidth="2">
          {[0, 1, 2, 3, 4, 5, 6].map(index => (
            <path
              key={index}
              d={`M-40 ${120 + index * 78} C 260 ${40 + index * 78}, 520 ${210 + index * 78}, 760 ${130 + index * 78} S 1220 ${40 + index * 78}, 1480 ${150 + index * 78}`}
              strokeOpacity={0.22 - index * 0.022}
            />
          ))}
        </g>
      )}

      {variant === "orbit" && (
        <g fill="none" stroke="currentColor" strokeOpacity="0.18">
          {[150, 230, 320, 410].map((r, index) => (
            <circle
              key={r}
              cx="1120"
              cy="250"
              r={r}
              strokeOpacity={0.2 - index * 0.035}
              strokeDasharray={index % 2 === 0 ? "none" : "14 12"}
            />
          ))}
          <circle cx="1120" cy="250" r="46" fill="currentColor" fillOpacity="0.2" stroke="none" />
          <circle cx="1270" cy="500" r="26" fill="currentColor" fillOpacity="0.16" stroke="none" />
          <circle cx="960" cy="520" r="16" fill="currentColor" fillOpacity="0.12" stroke="none" />
        </g>
      )}
    </svg>
  );
}
