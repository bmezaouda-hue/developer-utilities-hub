﻿"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, Monitor, Moon, Sun, Terminal, X } from "lucide-react";
import { useTheme } from "./ThemeProvider";
import { navLinks, siteConfig } from "@/lib/site";

export function Header() {
  const pathname = usePathname();
  const { theme, setTheme, toggle } = useTheme();
  const [open, setOpen] = useState(false);

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  const isActive = (href: string) =>
    href === "/" ? pathname === "/" : pathname === href || pathname.startsWith(`${href}/`);

  return (
    <header className="glass sticky top-0 z-50 border-b border-[var(--border)]">
      <div className="container-shell flex h-16 items-center justify-between gap-4">
        <Link href="/" className="group flex items-center gap-2.5" aria-label={siteConfig.name}>
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[var(--accent)] to-[var(--accent-strong)] text-[var(--accent-ink)] shadow-[0_8px_18px_-10px_var(--accent)] transition-transform group-hover:scale-105">
            <Terminal size={18} />
          </span>
          <span className="flex flex-col leading-tight">
            <span className="text-[0.95rem] font-extrabold tracking-tight">Dev Utilities</span>
            <span className="hidden text-[0.65rem] font-semibold text-[var(--muted)] sm:block">
              أدوات المطورين
            </span>
          </span>
        </Link>

        <nav className="hidden items-center gap-1 text-sm md:flex" aria-label="التنقل الرئيسي">
          {navLinks.map(link => (
            <Link
              key={link.href}
              href={link.href}
              aria-current={isActive(link.href) ? "page" : undefined}
              className={`rounded-xl px-3 py-2 font-semibold transition ${
                isActive(link.href)
                  ? "bg-[var(--accent-soft)] text-[var(--accent-strong)]"
                  : "text-[var(--muted)] hover:bg-[var(--card)] hover:text-[var(--foreground)]"
              }`}
            >
              {link.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-2">
          <div
            className="hidden items-center rounded-xl border border-[var(--border)] bg-[var(--card)] p-0.5 sm:flex"
            role="group"
            aria-label="مظهر الموقع"
          >
            <button
              onClick={() => setTheme("light")}
              aria-label="مظهر فاتح"
              aria-pressed={theme === "light"}
              className={`rounded-lg p-1.5 transition ${theme === "light" ? "bg-[var(--accent-soft)] text-[var(--accent-strong)]" : "text-[var(--muted)] hover:text-[var(--foreground)]"}`}
            >
              <Sun size={16} />
            </button>
            <button
              onClick={() => setTheme("dark")}
              aria-label="مظهر داكن"
              aria-pressed={theme === "dark"}
              className={`rounded-lg p-1.5 transition ${theme === "dark" ? "bg-[var(--accent-soft)] text-[var(--accent-strong)]" : "text-[var(--muted)] hover:text-[var(--foreground)]"}`}
            >
              <Moon size={16} />
            </button>
            <button
              onClick={() => setTheme("system")}
              aria-label="حسب النظام"
              aria-pressed={theme === "system"}
              className={`rounded-lg p-1.5 transition ${theme === "system" ? "bg-[var(--accent-soft)] text-[var(--accent-strong)]" : "text-[var(--muted)] hover:text-[var(--foreground)]"}`}
            >
              <Monitor size={16} />
            </button>
          </div>
          <button
            onClick={toggle}
            aria-label="تبديل المظهر"
            className="btn btn-ghost p-2! sm:hidden"
          >
            {theme === "dark" ? <Sun size={17} /> : <Moon size={17} />}
          </button>
          <Link href="/tools/json-formatter" className="btn btn-primary hidden py-2! sm:inline-flex">
            جرّب الأداة
          </Link>
          <button
            onClick={() => setOpen(v => !v)}
            aria-label={open ? "إغلاق القائمة" : "فتح القائمة"}
            aria-expanded={open}
            className="btn btn-ghost p-2! md:hidden"
          >
            {open ? <X size={18} /> : <Menu size={18} />}
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-[var(--border)] bg-[var(--card)] md:hidden">
          <nav className="container-shell grid gap-1 py-3" aria-label="تنقل الجوال">
            {navLinks.map(link => (
              <Link
                key={link.href}
                href={link.href}
                className={`rounded-xl px-3 py-2.5 text-sm font-semibold ${
                  isActive(link.href)
                    ? "bg-[var(--accent-soft)] text-[var(--accent-strong)]"
                    : "text-[var(--muted)]"
                }`}
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>
      )}
    </header>
  );
}
