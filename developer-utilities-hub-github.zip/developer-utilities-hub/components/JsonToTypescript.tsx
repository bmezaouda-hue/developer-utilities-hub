"use client";

import { useMemo, useState } from "react";
import {
  Check,
  Clipboard,
  Copy,
  Download,
  Eraser,
  Sparkles,
  TriangleAlert,
  Type,
  Wand2
} from "lucide-react";
import { describeParseError } from "@/lib/json-tools";
import { generateTypes, TS_SAMPLE } from "@/lib/json-to-typescript";

export function JsonToTypescript() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [rootName, setRootName] = useState("ApiResponse");
  const [status, setStatus] = useState<{ type: "idle" | "success" | "error"; text: string }>({
    type: "idle",
    text: ""
  });
  const [copied, setCopied] = useState(false);
  const [interfaceCount, setInterfaceCount] = useState(0);

  const inputError = useMemo(() => {
    if (!input.trim()) return null;
    try {
      JSON.parse(input);
      return null;
    } catch (error) {
      return describeParseError(error, input);
    }
  }, [input]);

  function generate() {
    const result = generateTypes(input, rootName);
    if (!result.ok) {
      setOutput("");
      setInterfaceCount(0);
      setStatus({ type: "error", text: result.message });
      return;
    }
    setOutput(result.code);
    setInterfaceCount(result.interfaceCount);
    setCopied(false);
    setStatus({
      type: "success",
      text: `تم توليد ${result.interfaceCount === 1 ? "واجهة واحدة" : `${result.interfaceCount} واجهات`} بنجاح.`
    });
  }

  async function copyOutput() {
    if (!output) return;
    try {
      await navigator.clipboard.writeText(output);
      setCopied(true);
      setTimeout(() => setCopied(false), 1600);
    } catch {
      setStatus({ type: "error", text: "تعذّر النسخ تلقائياً. حدّد النص وانسخه يدوياً." });
    }
  }

  function download() {
    if (!output) return;
    const blob = new Blob([output], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "interfaces.ts";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  function clearAll() {
    setInput("");
    setOutput("");
    setInterfaceCount(0);
    setCopied(false);
    setStatus({ type: "idle", text: "" });
  }

  return (
    <div className="grid gap-5">
      <div className="card flex flex-wrap items-end gap-4 p-4">
        <label className="grid min-w-[220px] flex-1 gap-2 text-sm font-bold">
          اسم الواجهة الرئيسية
          <input
            value={rootName}
            onChange={event => setRootName(event.target.value)}
            dir="ltr"
            spellCheck={false}
            placeholder="ApiResponse"
            className="input code-font"
          />
        </label>
        <button onClick={() => setInput(TS_SAMPLE)} className="btn btn-ghost">
          <Sparkles size={16} aria-hidden />
          تحميل مثال
        </button>
        <button onClick={generate} className="btn btn-primary">
          <Wand2 size={16} aria-hidden />
          توليد TypeScript
        </button>
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        <section className="card flex flex-col overflow-hidden">
          <div className="flex items-center justify-between gap-2 border-b border-[var(--border)] px-4 py-3">
            <div className="flex items-center gap-2">
              <Type size={16} className="text-[var(--accent-strong)]" aria-hidden />
              <h2 className="font-bold">JSON</h2>
              <span className="text-xs muted">
                {input.length.toLocaleString("en-US")} حرف
              </span>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => void navigator.clipboard.writeText(input)}
                disabled={!input}
                className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)] disabled:opacity-40"
                aria-label="نسخ المدخل"
                title="نسخ المدخل"
              >
                <Copy size={15} />
              </button>
              <button
                onClick={clearAll}
                className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)]"
                aria-label="مسح الكل"
                title="مسح الكل"
              >
                <Eraser size={15} />
              </button>
            </div>
          </div>
          <textarea
            value={input}
            onChange={event => {
              setInput(event.target.value);
              if (status.type === "error") setStatus({ type: "idle", text: "" });
            }}
            spellCheck={false}
            dir="ltr"
            placeholder={'{\n  "id": 123,\n  "name": "Example"\n}'}
            aria-label="JSON input"
            className="code-font min-h-[360px] w-full flex-1 resize-y bg-transparent p-5 text-sm leading-7 outline-none"
          />
          {inputError?.line ? (
            <div className="border-t border-[var(--border)] px-4 py-2 text-xs font-semibold text-red-500">
              خطأ في السطر {inputError.line}، العمود {inputError.column}
            </div>
          ) : null}
        </section>

        <section className="card flex flex-col overflow-hidden">
          <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border)] px-4 py-3">
            <div className="flex items-center gap-2">
              <Check size={16} className="text-[var(--accent-strong)]" aria-hidden />
              <h2 className="font-bold">TypeScript</h2>
              {interfaceCount > 0 && (
                <span className="text-xs muted">
                  {interfaceCount} واجهة
                </span>
              )}
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={download}
                disabled={!output}
                className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)] disabled:opacity-40"
                aria-label="تنزيل النتيجة"
                title="تنزيل interfaces.ts"
              >
                <Download size={15} />
              </button>
              <button
                onClick={copyOutput}
                disabled={!output}
                className="flex items-center gap-1.5 rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-semibold transition hover:border-[var(--accent)] hover:text-[var(--accent-strong)] disabled:opacity-40"
              >
                {copied ? <Check size={15} /> : <Clipboard size={15} />}
                {copied ? "تم النسخ" : "نسخ"}
              </button>
            </div>
          </div>
          <textarea
            value={output}
            onChange={event => setOutput(event.target.value)}
            readOnly={false}
            spellCheck={false}
            dir="ltr"
            placeholder={"export interface ApiResponse {\n  id: number;\n}"}
            aria-label="TypeScript output"
            className="code-font min-h-[360px] w-full flex-1 resize-y bg-transparent p-5 text-sm leading-7 outline-none"
          />
        </section>
      </div>

      {status.type !== "idle" && (
        <div
          role="status"
          aria-live="polite"
          className={`flex items-center gap-2 rounded-2xl border px-4 py-3 text-sm ${
            status.type === "error"
              ? "border-red-300 bg-red-500/10 text-red-600"
              : "border-emerald-300 bg-emerald-500/10 text-emerald-700"
          }`}
        >
          {status.type === "error" && <TriangleAlert size={16} aria-hidden />}
          {status.text}
        </div>
      )}

      <p className="text-xs leading-7 muted">
        التحويل يتم محلياً داخل متصفحك: لا يتم إرسال بيانات JSON إلى أي خادم. المفاتيح التي تحتوي
        مسافات تُحوَّل تلقائياً إلى خصائص بين علامتي اقتباس، والمصفوفات الفارغة تصبح{" "}
        <code className="code-font">unknown[]</code>.
      </p>
    </div>
  );
}
