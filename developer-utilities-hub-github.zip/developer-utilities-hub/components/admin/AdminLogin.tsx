"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { KeyRound, Loader2, ShieldCheck } from "lucide-react";

export function AdminLogin() {
  const router = useRouter();
  const params = useSearchParams();
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setBusy(true);
    setError("");
    try {
      const response = await fetch("/api/admin/login", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ password })
      });
      if (response.ok) {
        router.replace(params.get("next") || "/admin");
        router.refresh();
        return;
      }
      if (response.status === 429) {
        setError("محاولات كثيرة. انتظر قليلاً ثم أعد المحاولة.");
      } else if (response.status === 404) {
        setError("لوحة التحكم غير مفعّلة على هذا الموقع.");
      } else {
        setError("كلمة المرور غير صحيحة.");
      }
    } catch {
      setError("تعذّر الاتصال بالخادم.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="mx-auto max-w-md">
      <div className="card p-7">
        <span className="grid h-12 w-12 place-items-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-strong)]">
          <ShieldCheck size={22} aria-hidden />
        </span>
        <h1 className="mt-5 text-2xl font-black tracking-tight">لوحة تحكم المدير</h1>
        <p className="mt-2 text-sm leading-7 muted">
          هذه المنطقة مخصصة لصاحب الموقع فقط. أدخل كلمة المرور للمتابعة.
        </p>

        <form onSubmit={submit} className="mt-6 grid gap-4">
          <label className="grid gap-2 text-sm font-bold">
            كلمة المرور
            <input
              type="password"
              required
              autoFocus
              autoComplete="current-password"
              value={password}
              onChange={event => setPassword(event.target.value)}
              className="input"
              placeholder="••••••••"
            />
          </label>

          {error && (
            <p role="alert" className="rounded-xl border border-red-300 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-600">
              {error}
            </p>
          )}

          <button type="submit" disabled={busy} className="btn btn-primary">
            {busy ? <Loader2 size={16} className="animate-spin" aria-hidden /> : <KeyRound size={16} aria-hidden />}
            {busy ? "جارٍ التحقق..." : "دخول"}
          </button>
        </form>

        <p className="mt-5 text-xs leading-7 muted">
          الجلسة صالحة 7 أيام. تُقفل اللوحة مؤقتاً بعد 5 محاولات فاشلة. لتغيير كلمة المرور غيّر
          المتغير <code className="code-font">ADMIN_PASSWORD_HASH</code> ثم أعد النشر.
        </p>
      </div>
    </div>
  );
}
