"use client";

import { useCallback, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import {
  BarChart3,
  Eye,
  FileText,
  Loader2,
  LogOut,
  RotateCcw,
  Save,
  Settings2,
  Wrench,
  type LucideIcon
} from "lucide-react";
import type { ToolMeta } from "@/lib/site";
import type { AdminSettings, StatsSnapshot, ToolOverrides } from "@/lib/admin/types";

type Tab = "overview" | "tools" | "settings";

const driverLabel: Record<string, string> = {
  file: "تخزين محلي (ملف)",
  upstash: "Upstash Redis"
};

const tabs: { id: Tab; label: string; icon: LucideIcon }[] = [
  { id: "overview", label: "نظرة عامة", icon: BarChart3 },
  { id: "tools", label: "الأدوات", icon: Wrench },
  { id: "settings", label: "الإعدادات", icon: Settings2 }
];

export function AdminPanel({
  initialSettings,
  initialTools,
  initialStats,
  knownTools,
  driver
}: {
  initialSettings: AdminSettings;
  initialTools: ToolOverrides;
  initialStats: StatsSnapshot;
  knownTools: ToolMeta[];
  driver: string;
}) {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("overview");
  const [settings, setSettings] = useState<AdminSettings>(initialSettings);
  const [overrides, setOverrides] = useState<ToolOverrides>(initialTools);
  const [stats, setStats] = useState<StatsSnapshot>(initialStats);
  const [days, setDays] = useState(14);
  const [busy, setBusy] = useState<"" | "settings" | "tools" | "stats" | "reset" | "logout">("");
  const [message, setMessage] = useState<{ kind: "ok" | "error"; text: string } | null>(null);

  const notify = useCallback((kind: "ok" | "error", text: string) => {
    setMessage({ kind, text });
    window.setTimeout(() => setMessage(null), 4000);
  }, []);

  async function saveSettings() {
    setBusy("settings");
    try {
      const response = await fetch("/api/admin/settings", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ settings })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      setSettings(data.settings);
      notify("ok", "تم حفظ الإعدادات.");
    } catch {
      notify("error", "تعذّر حفظ الإعدادات.");
    } finally {
      setBusy("");
    }
  }

  async function saveTools() {
    setBusy("tools");
    try {
      const response = await fetch("/api/admin/tools", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ tools: overrides })
      });
      const data = await response.json();
      if (!response.ok) throw new Error(data.error);
      setOverrides(data.tools);
      notify("ok", "تم حفظ إعدادات الأدوات.");
    } catch {
      notify("error", "تعذّر حفظ الأدوات.");
    } finally {
      setBusy("");
    }
  }

  const loadStats = useCallback(
    async (range: number, silent = false) => {
      if (!silent) setBusy("stats");
      try {
        const response = await fetch(`/api/admin/stats?days=${range}`, { cache: "no-store" });
        const data = await response.json();
        if (!response.ok) throw new Error(data.error);
        setStats(data.stats);
      } catch {
        if (!silent) notify("error", "تعذّر تحميل الإحصائيات.");
      } finally {
        if (!silent) setBusy("");
      }
    },
    [notify]
  );

  async function resetStats() {
    if (!window.confirm("سيتم حذف كل الزيارات المسجّلة نهائياً. هل أنت متأكد؟")) return;
    setBusy("reset");
    try {
      const response = await fetch("/api/admin/stats", { method: "POST" });
      if (!response.ok) throw new Error("reset_failed");
      await loadStats(days, true);
      notify("ok", "تم تصفير الإحصائيات.");
    } catch {
      notify("error", "تعذّر تصفير الإحصائيات.");
    } finally {
      setBusy("");
    }
  }

  async function logout() {
    setBusy("logout");
    await fetch("/api/admin/logout", { method: "POST" }).catch(() => undefined);
    router.replace("/admin/login");
    router.refresh();
  }

  const maxDay = useMemo(
    () => Math.max(1, ...stats.days.map(point => point.views)),
    [stats.days]
  );

  return (
    <div className="grid gap-6">
      <header className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-black tracking-tight md:text-3xl">لوحة التحكم</h1>
          <p className="mt-2 text-sm muted">
            مرحباً <span className="font-bold text-[var(--foreground)]">{settings.ownerName}</span> —{" "}
            {driverLabel[driver] ?? driver}
          </p>
        </div>
        <button onClick={logout} disabled={busy === "logout"} className="btn btn-ghost">
          {busy === "logout" ? (
            <Loader2 size={16} className="animate-spin" aria-hidden />
          ) : (
            <LogOut size={16} aria-hidden />
          )}
          خروج
        </button>
      </header>

      {message && (
        <p
          role="status"
          className={`rounded-xl border px-4 py-3 text-sm font-semibold ${
            message.kind === "ok"
              ? "border-emerald-300 bg-emerald-500/10 text-emerald-700"
              : "border-red-300 bg-red-500/10 text-red-600"
          }`}
        >
          {message.text}
        </p>
      )}

      <nav className="flex flex-wrap gap-2">
        {tabs.map(item => (
          <button
            key={item.id}
            onClick={() => setTab(item.id)}
            className={`btn ${tab === item.id ? "btn-primary" : "btn-ghost"}`}
          >
            <item.icon size={16} aria-hidden />
            {item.label}
          </button>
        ))}
      </nav>

      {tab === "overview" && (
        <section className="grid gap-6">
          <div className="grid gap-4 sm:grid-cols-3">
            <StatCard
              icon={Eye}
              label="إجمالي الزيارات"
              value={stats.totalViews.toLocaleString("ar-EG")}
            />
            <StatCard
              icon={BarChart3}
              label="زيارات اليوم"
              value={stats.todayViews.toLocaleString("ar-EG")}
            />
            <StatCard
              icon={FileText}
              label="مسارات متتبَّعة"
              value={stats.trackedPaths.toLocaleString("ar-EG")}
            />
          </div>

          <div className="card p-6">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <h2 className="text-base font-black">الزيارات اليومية</h2>
              <div className="flex items-center gap-2">
                <select
                  value={days}
                  onChange={event => {
                    const range = Number(event.target.value);
                    setDays(range);
                    void loadStats(range);
                  }}
                  className="input w-auto py-2 text-xs"
                  aria-label="المدى الزمني"
                >
                  <option value={7}>آخر 7 أيام</option>
                  <option value={14}>آخر 14 يوماً</option>
                  <option value={30}>آخر 30 يوماً</option>
                </select>
                <button
                  onClick={resetStats}
                  disabled={busy === "reset"}
                  className="btn btn-ghost"
                  title="حذف كل الإحصائيات"
                >
                  {busy === "reset" ? (
                    <Loader2 size={15} className="animate-spin" aria-hidden />
                  ) : (
                    <RotateCcw size={15} aria-hidden />
                  )}
                  تصفير
                </button>
              </div>
            </div>

            <div className="mt-6 flex h-44 items-end gap-1.5" dir="ltr">
              {stats.days.map(point => (
                <div key={point.date} className="group flex flex-1 flex-col items-center gap-1.5">
                  <div
                    className="w-full rounded-t-md bg-[var(--accent)]/70 transition group-hover:bg-[var(--accent)]"
                    style={{ height: `${Math.round((point.views / maxDay) * 100)}%`, minHeight: 3 }}
                    title={`${point.date}: ${point.views}`}
                  />
                </div>
              ))}
            </div>
            <div className="mt-2 flex justify-between text-[0.65rem] muted" dir="ltr">
              <span>{stats.days[0]?.date}</span>
              <span>{stats.days[stats.days.length - 1]?.date}</span>
            </div>
          </div>

          <div className="card p-6">
            <h2 className="text-base font-black">أكثر الصفحات زيارة</h2>
            {stats.topPages.length === 0 ? (
              <p className="mt-4 text-sm muted">لا توجد زيارات مسجّلة بعد.</p>
            ) : (
              <ul className="mt-4 grid gap-2">
                {stats.topPages.map(page => (
                  <li
                    key={page.path}
                    className="flex items-center justify-between gap-4 rounded-xl bg-[var(--card)] px-4 py-3 text-sm"
                  >
                    <code className="code-font truncate" dir="ltr">
                      {page.path}
                    </code>
                    <span className="shrink-0 font-bold text-[var(--accent-strong)]">
                      {page.views.toLocaleString("ar-EG")}
                    </span>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </section>
      )}

      {tab === "tools" && (
        <section className="card p-6">
          <h2 className="text-base font-black">إدارة الأدوات</h2>
          <p className="mt-2 text-xs muted">
            يمكنك إخفاء أي أداة من الصفحة الرئيسية، أو تعديل عنوانها ووصفها دون لمس الكود.
          </p>

          <ul className="mt-5 grid gap-4">
            {knownTools.map(tool => {
              const override = overrides[tool.slug] ?? {
                enabled: true,
                title: "",
                description: ""
              };
              return (
                <li key={tool.slug} className="grid gap-3 rounded-2xl border border-[var(--border)] p-4">
                  <label className="flex items-center justify-between gap-3">
                    <span className="font-bold">{tool.title}</span>
                    <span className="flex items-center gap-2 text-xs muted">
                      {override.enabled ? "مفعّلة" : "مخفية"}
                      <input
                        type="checkbox"
                        checked={override.enabled}
                        onChange={event =>
                          setOverrides(current => ({
                            ...current,
                            [tool.slug]: { ...override, enabled: event.target.checked }
                          }))
                        }
                        className="h-5 w-5 accent-[var(--accent)]"
                      />
                    </span>
                  </label>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <label className="grid gap-1.5 text-xs font-bold">
                      عنوان مخصص
                      <input
                        value={override.title}
                        onChange={event =>
                          setOverrides(current => ({
                            ...current,
                            [tool.slug]: { ...override, title: event.target.value }
                          }))
                        }
                        placeholder={tool.title}
                        className="input"
                      />
                    </label>
                    <label className="grid gap-1.5 text-xs font-bold">
                      وصف مخصص
                      <input
                        value={override.description}
                        onChange={event =>
                          setOverrides(current => ({
                            ...current,
                            [tool.slug]: { ...override, description: event.target.value }
                          }))
                        }
                        placeholder={tool.description.slice(0, 60)}
                        className="input"
                      />
                    </label>
                  </div>
                </li>
              );
            })}
          </ul>

          <button onClick={saveTools} disabled={busy === "tools"} className="btn btn-primary mt-5">
            {busy === "tools" ? (
              <Loader2 size={16} className="animate-spin" aria-hidden />
            ) : (
              <Save size={16} aria-hidden />
            )}
            حفظ الأدوات
          </button>
        </section>
      )}

      {tab === "settings" && (
        <section className="card p-6">
          <h2 className="text-base font-black">إعدادات الموقع</h2>

          <div className="mt-5 grid gap-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="grid gap-1.5 text-sm font-bold">
                اسم المالك
                <input
                  value={settings.ownerName}
                  onChange={event =>
                    setSettings(current => ({ ...current, ownerName: event.target.value }))
                  }
                  className="input"
                />
              </label>
              <label className="grid gap-1.5 text-sm font-bold">
                بريد التواصل
                <input
                  type="email"
                  value={settings.contactEmail}
                  onChange={event =>
                    setSettings(current => ({ ...current, contactEmail: event.target.value }))
                  }
                  className="input"
                  dir="ltr"
                />
              </label>
            </div>

            <label className="grid gap-1.5 text-sm font-bold">
              رابط الموقع
              <input
                value={settings.siteUrl}
                onChange={event =>
                  setSettings(current => ({ ...current, siteUrl: event.target.value }))
                }
                className="input"
                dir="ltr"
              />
            </label>

            <fieldset className="grid gap-3 rounded-2xl border border-[var(--border)] p-4">
              <legend className="px-2 text-sm font-black">شريط الإعلان</legend>
              <label className="flex items-center gap-2 text-sm font-bold">
                <input
                  type="checkbox"
                  checked={settings.announcement.enabled}
                  onChange={event =>
                    setSettings(current => ({
                      ...current,
                      announcement: { ...current.announcement, enabled: event.target.checked }
                    }))
                  }
                  className="h-5 w-5 accent-[var(--accent)]"
                />
                إظهار شريط الإعلان
              </label>
              <input
                value={settings.announcement.text}
                maxLength={160}
                onChange={event =>
                  setSettings(current => ({
                    ...current,
                    announcement: { ...current.announcement, text: event.target.value }
                  }))
                }
                placeholder="نص الإعلان (حتى 160 حرفاً)"
                className="input"
                disabled={!settings.announcement.enabled}
              />
              <input
                value={settings.announcement.link}
                onChange={event =>
                  setSettings(current => ({
                    ...current,
                    announcement: { ...current.announcement, link: event.target.value }
                  }))
                }
                placeholder="رابط اختياري: /tools أو https://..."
                className="input"
                dir="ltr"
                disabled={!settings.announcement.enabled}
              />
            </fieldset>

            <fieldset className="grid gap-3 rounded-2xl border border-[var(--border)] p-4">
              <legend className="px-2 text-sm font-black">وضع الصيانة</legend>
              <label className="flex items-center gap-2 text-sm font-bold">
                <input
                  type="checkbox"
                  checked={settings.maintenance.enabled}
                  onChange={event =>
                    setSettings(current => ({
                      ...current,
                      maintenance: { ...current.maintenance, enabled: event.target.checked }
                    }))
                  }
                  className="h-5 w-5 accent-[var(--accent)]"
                />
                تفعيل وضع الصيانة
              </label>
              <textarea
                value={settings.maintenance.message}
                maxLength={300}
                rows={3}
                onChange={event =>
                  setSettings(current => ({
                    ...current,
                    maintenance: { ...current.maintenance, message: event.target.value }
                  }))
                }
                className="input"
                disabled={!settings.maintenance.enabled}
              />
              <p className="text-xs muted">
                هذا يحجب الزوار بمتصفحهم فقط. للإغلاق الكامل على الخادم استخدم المتغير{" "}
                <code className="code-font">MAINTENANCE=1</code> ثم أعد النشر.
              </p>
            </fieldset>

            <div className="grid gap-3">
              <ToggleRow
                label="عرض الإعلانات"
                hint="يتطلب أيضاً ضبط معرّف AdSense في متغيرات البيئة."
                checked={settings.adsEnabled}
                onChange={value => setSettings(current => ({ ...current, adsEnabled: value }))}
              />
              <ToggleRow
                label="تسجيل الزيارات"
                hint="يرسل كل زيارة مسار الصفحة إلى /api/track لتظهر في الإحصائيات."
                checked={settings.trackVisits}
                onChange={value => setSettings(current => ({ ...current, trackVisits: value }))}
              />
            </div>

            <button onClick={saveSettings} disabled={busy === "settings"} className="btn btn-primary">
              {busy === "settings" ? (
                <Loader2 size={16} className="animate-spin" aria-hidden />
              ) : (
                <Save size={16} aria-hidden />
              )}
              حفظ الإعدادات
            </button>

            <p className="text-xs leading-7 muted">
              البريد واسم المالك ورابط الموقع يُستخدمون أيضاً في بيانات SEO وبيانات المنظّمة
              (JSON-LD)، وتغييرها يحتاج إعادة بناء ونشر لتظهر في نتائج البحث.
            </p>
          </div>
        </section>
      )}
    </div>
  );
}

function StatCard({ icon: Icon, label, value }: { icon: LucideIcon; label: string; value: string }) {
  return (
    <div className="card p-5">
      <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--accent-soft)] text-[var(--accent-strong)]">
        <Icon size={18} aria-hidden />
      </span>
      <p className="mt-4 text-2xl font-black tracking-tight">{value}</p>
      <p className="mt-1 text-xs muted">{label}</p>
    </div>
  );
}

function ToggleRow({
  label,
  hint,
  checked,
  onChange
}: {
  label: string;
  hint: string;
  checked: boolean;
  onChange: (value: boolean) => void;
}) {
  return (
    <label className="flex items-start justify-between gap-4 rounded-2xl border border-[var(--border)] p-4">
      <span>
        <span className="block text-sm font-bold">{label}</span>
        <span className="mt-1 block text-xs muted">{hint}</span>
      </span>
      <input
        type="checkbox"
        checked={checked}
        onChange={event => onChange(event.target.checked)}
        className="mt-1 h-5 w-5 shrink-0 accent-[var(--accent)]"
      />
    </label>
  );
}
