"use client";

import { usePathname } from "next/navigation";
import { getTheme, themeStyle } from "@/lib/page-themes";
import { getArticle } from "@/lib/articles";
import { PageArt } from "./PageArt";

function themeFor(pathname: string): string {
  if (pathname === "/") return "home";
  if (pathname.startsWith("/tools/json-formatter")) return "formatter";
  if (pathname.startsWith("/tools/json-to-typescript")) return "typescript";
  if (pathname.startsWith("/tools")) return "tools";
  if (pathname.startsWith("/articles/")) {
    return getArticle(pathname.replace("/articles/", "").split("/")[0])?.theme ?? "articles";
  }
  if (pathname.startsWith("/articles")) return "articles";
  if (pathname.startsWith("/about")) return "about";
  if (pathname.startsWith("/contact")) return "contact";
  if (
    pathname.startsWith("/privacy") ||
    pathname.startsWith("/terms") ||
    pathname.startsWith("/cookies") ||
    pathname.startsWith("/disclaimer")
  ) {
    return "legal";
  }
  return "home";
}

export function AutoPageSkin({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const theme = getTheme(themeFor(pathname));

  return (
    <div className="page-skin" style={themeStyle(theme)} data-theme={theme.id} data-art={theme.art}>
      <div className="page-art-wrap" aria-hidden>
        <PageArt variant={theme.art} />
      </div>
      {children}
    </div>
  );
}
