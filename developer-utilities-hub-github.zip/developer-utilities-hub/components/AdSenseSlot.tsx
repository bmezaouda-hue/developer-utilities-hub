"use client";

import Script from "next/script";
import { useConsent } from "./ConsentProvider";

declare global {
  interface Window {
    adsbygoogle?: unknown[];
  }
}

export function AdSenseSlot({
  slot,
  label,
  format = "auto"
}: {
  slot?: string;
  label: string;
  format?: "auto" | "rectangle";
}) {
  const { consent } = useConsent();
  const client = process.env.NEXT_PUBLIC_ADSENSE_CLIENT ?? "";
  const slotId = slot || process.env.NEXT_PUBLIC_ADSENSE_SLOT || "";

  if (!client.startsWith("ca-pub-") || !slotId) return null;
  if (consent !== "granted") return null;

  return (
    <div className="my-6 w-full overflow-hidden" aria-label={label} data-ad-slot-id={slotId}>
      <ins
        className="adsbygoogle block w-full"
        style={{ display: "block", minHeight: format === "rectangle" ? 250 : 100 }}
        data-ad-client={client}
        data-ad-slot={slotId}
        data-ad-format={format}
        data-full-width-responsive="true"
      />
      <Script
        id="adsense-loader"
        strategy="afterInteractive"
        src={`https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=${client}`}
        onLoad={() => {
          try {
            (window.adsbygoogle = window.adsbygoogle || []).push({});
          } catch {
            /* ad block or script failure */
          }
        }}
      />
    </div>
  );
}
