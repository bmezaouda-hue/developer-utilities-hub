﻿"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowDownUp,
  Check,
  Clipboard,
  Copy,
  Download,
  Eraser,
  FileJson,
  Minimize2,
  Sparkles,
  Wand2
} from "lucide-react";
import {
  analyzeJson,
  describeParseError,
  formatBytes,
  stringifyJson,
  type JsonStats,
  type SortMode
} from "@/lib/json-tools";

type Status = { type: "idle" | "success" | "error"; text: string; hint?: string };

const SAMPLE = `{"name":"Developer Utilities Hub","version":1,"private":false,"keywords":["json","formatter","developer","tools"],"maintainer":{"name":"Team","contact":{"email":"hello@example.com","url":"https://example.com"}},"scripts":{"dev":"next dev","build":"next build","start":"next start"},"engines":{"node":">=20"}}`;

const indentOptions: { value: string; label: string }[] = [
  { value: "2", label: "2 مسافات" },
  { value: "4", label: "4 مسافات" },
  { value: "\t", label: "Tab" }
];

const sortOptions: { value: SortMode; label: string }[] = [
  { value: "none", label: "بدون ترتيب" },
  { value: "asc", label: "أبجدي تصاعدي" },
  { value: "desc", label: "أبجدي تنازلي" },
  { value: "size", label: "حسب الحجم" }
];

export function JsonFormatter() {
  const [input, setInput] = useState("");
  const [output, setOutput] = useState("");
  const [indent, setIndent] = useState("2");
  const [sort, setSort] = useState<SortMode>("none");
  const [stats, setStats] = useState<JsonStats | null>(null);
  const [status, setStatus] = useState<Status>({ type: "idle", text: "" });
  const [copied, setCopied] = useState<"output" | "input" | null>(null);
  const outputRef = useRef<HTMLPreElement>(null);

  const parsed = useMemo(() => {
    if (!input.trim()) return { ok: false as const, value: null, error: null };
    try {
      return { ok: true as const, value: JSON.parse(input) as unknown, error: null };
    } catch (error) {
      return { ok: false as const, value: null, error: describeParseError(error, input) };
    }
  }, [input]);

  useEffect(() => {
    if (!input.trim()) {
      setStats(null);
      return;
    }
    if (parsed.ok) {
      setStats(analyzeJson(parsed.value, input));
    } else {
      setStats(null);
    }
  }, [input, parsed]);

  const run = useCallback(
    (mode: "format" | "minify") => {
      if (!input.trim()) {
        setOutput("");
        setStatus({ type: "error", text: "أدخل JSON أولاً." });
        return;
      }
      if (!parsed.ok) {
        setOutput("");
        setStatus({
          type: "error",
          text: parsed.error?.line
            ? `JSON غير صالح: ${parsed.error.message} — السطر ${parsed.error.line}، العمود ${parsed.error.column}.`
            : `JSON غير صالح: ${parsed.error?.message ?? "خطأ غير معروف."}`
        });
        return;
      }
      const width = mode === "minify" ? 0 : indent === "\t" ? "\t" : Number(indent);
      const result = stringifyJson(parsed.value, width, sort);
      setOutput(result);
      setStatus({
        type: "success",
        text: mode === "format" ? "تم التنسيق بنجاح." : "تم التصغير بنجاح.",
        hint: sort === "none" ? undefined : "طُبّق الترتيب المحدد على المفاتيح."
      });
    },
    [input, parsed, indent, sort]
  );

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
        event.preventDefault();
        run("format");
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [run]);

  async function copyText(text: string, which: "output" | "input") {
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      setCopied(which);
      setTimeout(() => setCopied(null), 1600);
    } catch {
      setStatus({ type: "error", text: "تعذّر النسخ تلقائياً. حدّد النص وانسخه يدوياً." });
    }
  }

  function clearAll() {
    setInput("");
    setOutput("");
    setStats(null);
    setStatus({ type: "idle", text: "" });
    setCopied(null);
  }

  function download() {
    if (!output) return;
    const blob = new Blob([output], { type: "application/json;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = "formatted.json";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  }

  const inputChars = input.length;
  const savings =
    output && input && input.length > 0
      ? Math.max(0, Math.round((1 - output.length / input.length) * 100))
      : null;

  return (
    <div className="grid gap-5 lg:grid-cols-[1fr_auto_1fr]">
      <section className="card flex flex-col overflow-hidden">
        <div className="flex items-center justify-between gap-2 border-b border-[var(--border)] px-4 py-3">
          <div className="flex items-center gap-2">
            <FileJson size={16} className="text-[var(--accent-strong)]" aria-hidden />
            <h2 className="font-bold">المدخل</h2>
            <span className="text-xs muted">{inputChars.toLocaleString("en-US")} حرف</span>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => setInput(SAMPLE)}
              className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)]"
              aria-label="تحميل مثال"
              title="تحميل مثال"
            >
              <Sparkles size={15} />
            </button>
            <button
              onClick={() => copyText(input, "input")}
              disabled={!input}
              className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)] disabled:opacity-40"
              aria-label="نسخ المدخل"
              title="نسخ المدخل"
            >
              {copied === "input" ? <Check size={15} /> : <Copy size={15} />}
            </button>
            <button
              onClick={clearAll}
              className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)]"
              aria-label="مسح الكل"
              title="مسح الكل"
            >
              <Eraser size={15} />
            </button>
          </div>
        </div>
        <textarea
          value={input}
          onChange={event => setInput(event.target.value)}
          spellCheck={false}
          dir="ltr"
          placeholder={'{\n  "name": "Developer Utilities Hub",\n  "version": 1\n}'}
          aria-label="JSON input"
          className="code-font min-h-[360px] w-full flex-1 resize-y bg-transparent p-5 text-sm leading-7 outline-none"
        />
        {parsed.error?.line ? (
          <div className="border-t border-[var(--border)] px-4 py-2 text-xs font-semibold text-red-500">
            خطأ في السطر {parsed.error.line}، العمود {parsed.error.column}
          </div>
        ) : null}
      </section>

      <div className="flex flex-row items-center justify-center gap-3 lg:flex-col">
        <button onClick={() => run("format")} className="btn btn-primary px-5!">
          <Wand2 size={17} aria-hidden />
          Format
        </button>
        <button onClick={() => run("minify")} className="btn btn-ghost px-5!">
          <Minimize2 size={17} aria-hidden />
          Minify
        </button>
        <span className="hidden h-px w-full bg-[var(--border)] lg:block" aria-hidden />
        <span className="text-[0.65rem] font-semibold text-[var(--muted)] lg:writing-mode-vertical">
          Ctrl + Enter
        </span>
      </div>

      <section className="card flex flex-col overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[var(--border)] px-4 py-3">
          <div className="flex items-center gap-2">
            <Check size={16} className="text-[var(--accent-strong)]" aria-hidden />
            <h2 className="font-bold">النتيجة</h2>
            {output && <span className="text-xs muted">{formatBytes(new Blob([output]).size)}</span>}
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={download}
              disabled={!output}
              className="rounded-lg p-2 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)] disabled:opacity-40"
              aria-label="تنزيل نتيجة"
              title="تنزيل .json"
            >
              <Download size={15} />
            </button>
            <button
              onClick={() => copyText(output, "output")}
              disabled={!output}
              className="flex items-center gap-1.5 rounded-lg border border-[var(--border)] px-3 py-1.5 text-xs font-semibold transition hover:border-[var(--accent)] hover:text-[var(--accent-strong)] disabled:opacity-40"
            >
              {copied === "output" ? <Check size={15} /> : <Clipboard size={15} />}
              {copied === "output" ? "تم النسخ" : "نسخ"}
            </button>
          </div>
        </div>
        <pre
          ref={outputRef}
          dir="ltr"
          className="code-font min-h-[360px] flex-1 overflow-auto whitespace-pre-wrap break-words p-5 text-sm leading-7"
        >
          {output || (input ? "// اضغط Format لتظهر النتيجة هنا..." : "// النتيجة ستظهر هنا...")}
        </pre>
      </section>

      <div className="lg:col-span-3">
        <div className="card flex flex-wrap items-center gap-x-6 gap-y-4 p-4">
          <label className="flex items-center gap-2 text-sm font-semibold">
            المسافة البادئة
            <select
              value={indent}
              onChange={event => setIndent(event.target.value)}
              className="input w-auto! py-1.5! text-sm"
            >
              {indentOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>

          <label className="flex items-center gap-2 text-sm font-semibold">
            <ArrowDownUp size={15} className="text-[var(--muted)]" aria-hidden />
            ترتيب المفاتيح
            <select
              value={sort}
              onChange={event => setSort(event.target.value as SortMode)}
              className="input w-auto! py-1.5! text-sm"
            >
              {sortOptions.map(option => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </label>

          {stats && (
            <dl className="flex flex-wrap items-center gap-x-5 gap-y-1 text-xs muted">
              <div className="flex gap-1">
                <dt>الحجم:</dt>
                <dd className="font-bold text-[var(--foreground)]">{formatBytes(stats.bytes)}</dd>
              </div>
              <div className="flex gap-1">
                <dt>المفاتيح:</dt>
                <dd className="font-bold text-[var(--foreground)]">
                  {stats.keys.toLocaleString("en-US")}
                </dd>
              </div>
              <div className="flex gap-1">
                <dt>العناصر:</dt>
                <dd className="font-bold text-[var(--foreground)]">
                  {stats.values.toLocaleString("en-US")}
                </dd>
              </div>
              <div className="flex gap-1">
                <dt>العمق:</dt>
                <dd className="font-bold text-[var(--foreground)]">{stats.depth}</dd>
              </div>
              <div className="flex gap-1">
                <dt>كائنات:</dt>
                <dd className="font-bold text-[var(--foreground)]">{stats.objects}</dd>
              </div>
              <div className="flex gap-1">
                <dt>مصفوفات:</dt>
                <dd className="font-bold text-[var(--foreground)]">{stats.arrays}</dd>
              </div>
            </dl>
          )}

          {savings !== null && (
            <span className="chip chip-accent">توفير {savings}% من الحجم</span>
          )}
        </div>

        {status.type !== "idle" && (
          <div
            role="status"
            aria-live="polite"
            className={`mt-4 rounded-2xl border px-4 py-3 text-sm ${
              status.type === "error"
                ? "border-red-300 bg-red-500/10 text-red-600"
                : "border-emerald-300 bg-emerald-500/10 text-emerald-700"
            }`}
          >
            {status.text}
            {status.hint && <span className="block text-xs muted">{status.hint}</span>}
          </div>
        )}

        <p className="mt-4 text-xs leading-7 muted">
          المعالجة تتم محلياً داخل متصفحك: لا يتم إرسال محتوى JSON إلى أي خادم، ولا يتم حفظه بعد
          تحديث الصفحة. اختصار <kbd className="code-font rounded-md border border-[var(--border)] px-1.5 py-0.5 text-[0.7rem]">Ctrl</kbd> + <kbd className="code-font rounded-md border border-[var(--border)] px-1.5 py-0.5 text-[0.7rem]">Enter</kbd> يشغّل التنسيق.
        </p>
      </div>
    </div>
  );
}
