"use client";

import { usePathname } from "next/navigation";
import { useEffect, useRef } from "react";
import { useSiteConfig } from "./SiteConfigProvider";

export function PageViewTracker() {
  const pathname = usePathname();
  const { settings } = useSiteConfig();
  const lastPath = useRef<string | null>(null);

  useEffect(() => {
    if (!settings.trackVisits) return;
    if (!pathname || pathname === lastPath.current) return;
    lastPath.current = pathname;
    const payload = JSON.stringify({ path: pathname });
    if (navigator.sendBeacon) {
      navigator.sendBeacon("/api/track", new Blob([payload], { type: "application/json" }));
      return;
    }
    void fetch("/api/track", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: payload,
      keepalive: true
    });
  }, [pathname, settings.trackVisits]);

  return null;
}
