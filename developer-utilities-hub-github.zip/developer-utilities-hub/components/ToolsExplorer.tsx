﻿"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { Search, X } from "lucide-react";
import { ToolCard } from "./ToolCard";
import { useSiteConfig } from "./SiteConfigProvider";
import type { ToolMeta } from "@/lib/site";

type Category = "all" | ToolMeta["category"];

const categoryLabels: Record<Category, string> = {
  all: "الكل",
  format: "تنسيق وصياغة",
  encode: "ترميز وفك ترميز",
  developer: "أدوات المطوّر"
};

function normalize(value: string) {
  return value
    .toLowerCase()
    .replace(/[ً-ٟ]/g, "")
    .replace(/[أإآ]/g, "ا")
    .replace(/ة/g, "ه")
    .replace(/\s+/g, " ")
    .trim();
}

export function ToolsExplorer({
  tools,
  variant = "grid"
}: {
  tools: ToolMeta[];
  variant?: "grid" | "hero";
}) {
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<Category>("all");
  const inputRef = useRef<HTMLInputElement>(null);
  const { tools: overrides } = useSiteConfig();

  const visibleTools = useMemo(
    () =>
      tools
        .filter(tool => overrides[tool.slug]?.enabled !== false)
        .map(tool => {
          const override = overrides[tool.slug];
          if (!override) return tool;
          return {
            ...tool,
            title: override.title.trim() || tool.title,
            description: override.description.trim() || tool.description
          };
        }),
    [tools, overrides]
  );

  useEffect(() => {
    if (variant !== "hero") return;
    const onKeyDown = (event: KeyboardEvent) => {
      const target = event.target as HTMLElement | null;
      const typing =
        target?.tagName === "INPUT" ||
        target?.tagName === "TEXTAREA" ||
        target?.isContentEditable === true;
      if (event.key === "/" && !typing) {
        event.preventDefault();
        inputRef.current?.focus();
      }
      if (event.key === "Escape") {
        setQuery("");
        inputRef.current?.blur();
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [variant]);

  const filtered = useMemo(() => {
    const q = normalize(query);
    return visibleTools.filter(tool => {
      const inCategory = category === "all" || tool.category === category;
      if (!inCategory) return false;
      if (!q) return true;
      return normalize(`${tool.title} ${tool.shortTitle} ${tool.description} ${tool.keywords}`).includes(q);
    });
  }, [query, category, visibleTools]);
  const hasFilters = query.trim().length > 0 || category !== "all";

  return (
    <div className={variant === "hero" ? "mx-auto mt-8 max-w-2xl" : ""}>
      <div className="relative">
        <Search
          size={20}
          className="pointer-events-none absolute top-1/2 -translate-y-1/2 text-[var(--muted)] start-4"
          aria-hidden
        />
        <input
          ref={inputRef}
          value={query}
          onChange={event => setQuery(event.target.value)}
          type="search"
          aria-label="ابحث عن أداة"
          placeholder={variant === "hero" ? "ابحث عن أداة… (اضغط /)" : "تصفية الأدوات…"}
          className="input py-3.5! ps-12! pe-11!"
        />
        {query && (
          <button
            onClick={() => setQuery("")}
            aria-label="مسح البحث"
            className="absolute top-1/2 -translate-y-1/2 rounded-lg p-1.5 text-[var(--muted)] transition hover:bg-[var(--accent-soft)] hover:text-[var(--accent-strong)] end-3"
          >
            <X size={16} />
          </button>
        )}
      </div>

      {variant === "hero" ? (
        <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
          <span className="text-xs font-semibold text-[var(--muted)]">الأكثر استخداماً:</span>
          {visibleTools.map(tool => (
            <button
              key={tool.slug}
              onClick={() => setQuery(tool.shortTitle)}
              className="chip transition hover:border-[var(--accent)] hover:text-[var(--accent-strong)]"
            >
              {tool.shortTitle}
            </button>
          ))}
        </div>
      ) : (
        <>
          <div className="mt-4 flex flex-wrap items-center gap-2">
            {(Object.keys(categoryLabels) as Category[]).map(id => (
              <button
                key={id}
                onClick={() => setCategory(id)}
                aria-pressed={category === id}
                className={`chip transition ${
                  category === id
                    ? "border-[var(--accent)] bg-[var(--accent-soft)] text-[var(--accent-strong)]"
                    : "hover:border-[var(--border-strong)]"
                }`}
              >
                {categoryLabels[id]}
              </button>
            ))}
            <span className="ms-auto text-xs font-semibold text-[var(--muted)]">
              {filtered.length} من {visibleTools.length}
            </span>
          </div>

          {filtered.length > 0 ? (
            <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
              {filtered.map(tool => (
                <ToolCard key={tool.slug} tool={tool} />
              ))}
            </div>
          ) : (
            <div className="card mt-6 grid place-items-center gap-3 p-12 text-center">
              <p className="font-bold">لم نعثر على أداة مطابقة</p>
              <p className="text-sm muted">جرّب كلمة أخرى أو أزل عوامل التصفية.</p>
              <button onClick={() => (setQuery(""), setCategory("all"))} className="btn btn-ghost">
                إعادة ضبط البحث
              </button>
            </div>
          )}

          {hasFilters && filtered.length > 0 && (
            <p className="mt-6 text-center text-xs muted">
              يتم التصفية حسب بحثك داخل هذه الصفحة فقط.
            </p>
          )}
        </>
      )}
    </div>
  );
}
