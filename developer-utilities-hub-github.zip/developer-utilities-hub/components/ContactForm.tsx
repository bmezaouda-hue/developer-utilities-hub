﻿"use client";

import { useState } from "react";
import { Check, Mail, Send } from "lucide-react";
import { siteConfig } from "@/lib/site";

type Errors = { name?: string; email?: string; message?: string };
type Sent = "idle" | "ok";

export function ContactForm() {
  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [errors, setErrors] = useState<Errors>({});
  const [sent, setSent] = useState<Sent>("idle");

  function validate() {
    const next: Errors = {};
    if (form.name.trim().length < 2) next.name = "اكتب اسماً لا يقل عن حرفين.";
    if (/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(form.email.trim()))
      next.email = "اكتب بريداً إلكترونياً صحيحاً.";
    if (form.message.trim().length < 10) next.message = "اكتب رسالة لا تقل عن 10 أحرف.";
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  function submit(event: React.FormEvent) {
    event.preventDefault();
    if (!validate()) return;
    const subject = encodeURIComponent(`رسالة من ${form.name.trim()}`);
    const body = encodeURIComponent(
      `الاسم: ${form.name.trim()}\nالبريد: ${form.email.trim()}\n\n${form.message.trim()}`
    );
    setSent("ok");
    window.location.href = `mailto:${siteConfig.email}?subject=${subject}&body=${body}`;
  }

  const fieldClass = (error?: string) =>
    `input ${error ? "!border-red-400 focus:!border-red-500" : ""}`;

  return (
    <form onSubmit={submit} noValidate className="mt-8 grid gap-5">
      <div className="grid gap-5 sm:grid-cols-2">
        <label className="grid gap-2 text-sm font-bold">
          الاسم
          <input
            required
            value={form.name}
            onChange={event => setForm({ ...form, name: event.target.value })}
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "name-error" : undefined}
            className={fieldClass(errors.name)}
            placeholder="اسمك"
          />
          {errors.name && (
            <span id="name-error" className="text-xs font-semibold text-red-500">
              {errors.name}
            </span>
          )}
        </label>

        <label className="grid gap-2 text-sm font-bold">
          البريد الإلكتروني
          <input
            required
            type="email"
            dir="ltr"
            value={form.email}
            onChange={event => setForm({ ...form, email: event.target.value })}
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "email-error" : undefined}
            className={`${fieldClass(errors.email)} text-start`}
            placeholder="you@example.com"
          />
          {errors.email && (
            <span id="email-error" className="text-xs font-semibold text-red-500">
              {errors.email}
            </span>
          )}
        </label>
      </div>

      <label className="grid gap-2 text-sm font-bold">
        الرسالة
        <textarea
          required
          rows={7}
          value={form.message}
          onChange={event => setForm({ ...form, message: event.target.value })}
          aria-invalid={Boolean(errors.message)}
          aria-describedby={errors.message ? "message-error" : undefined}
          className={fieldClass(errors.message)}
          placeholder="اكتب اقتراحك أو بلّغ عن مشكلة…"
        />
        {errors.message && (
          <span id="message-error" className="text-xs font-semibold text-red-500">
            {errors.message}
          </span>
        )}
      </label>

      <div className="flex flex-wrap items-center gap-3">
        <button type="submit" className="btn btn-primary">
          <Send size={16} aria-hidden />
          فتح البريد وإرسال الرسالة
        </button>
        <a href={`mailto:${siteConfig.email}`} className="btn btn-ghost">
          <Mail size={16} aria-hidden />
          {siteConfig.email}
        </a>
      </div>

      {sent === "ok" && (
        <p role="status" className="flex items-center gap-2 text-sm font-semibold text-emerald-600">
          <Check size={16} aria-hidden />
          تم تجهيز الرسالة في برنامج البريد لديك.
        </p>
      )}

      <p className="text-xs leading-7 muted">
        النموذج لا يرسل بيانات إلى خادمنا؛ يفتح رسالة في برنامج البريد على جهازك. لم تُضبط بعد
        قيمة <code className="code-font">NEXT_PUBLIC_CONTACT_EMAIL</code> في{" "}
        <code className="code-font">.env.local</code>؟
      </p>
    </form>
  );
}
