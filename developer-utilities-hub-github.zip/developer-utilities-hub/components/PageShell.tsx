import Link from "next/link";
import { ArrowLeft } from "lucide-react";

type Crumb = { href: string; label: string };

export function Breadcrumbs({ items }: { items: Crumb[] }) {
  return (
    <nav aria-label="مسار التنقل" className="mb-6 flex flex-wrap items-center gap-2 text-xs font-semibold muted">
      <Link href="/" className="transition hover:text-[var(--accent-strong)]">
        الرئيسية
      </Link>
      {items.map(item => (
        <span key={item.href} className="flex items-center gap-2">
          <ArrowLeft size={13} aria-hidden />
          {item.href === "#" ? (
            <span className="text-[var(--foreground)]">{item.label}</span>
          ) : (
            <Link href={item.href} className="transition hover:text-[var(--accent-strong)]">
              {item.label}
            </Link>
          )}
        </span>
      ))}
    </nav>
  );
}

export function PageShell({
  title,
  description,
  badge,
  updated,
  children,
  wide = false
}: {
  title: string;
  description?: string;
  badge?: string;
  updated?: string;
  children: React.ReactNode;
  wide?: boolean;
}) {
  return (
    <div className="container-shell py-10 md:py-14">
      <Breadcrumbs items={[{ href: "#", label: title }]} />
      <article className="card p-7 md:p-10">
        <header className="border-b border-[var(--border)] pb-6">
          {badge && <span className="chip chip-accent">{badge}</span>}
          <h1 className="mt-3 text-3xl font-black tracking-tight md:text-4xl">{title}</h1>
          {description && <p className="mt-3 max-w-3xl leading-8 muted">{description}</p>}
          {updated && <p className="mt-4 text-xs muted">آخر تحديث: {updated}</p>}
        </header>
        <div className={`prose-lite pt-6 ${wide ? "" : "max-w-3xl"}`}>{children}</div>
      </article>
    </div>
  );
}
