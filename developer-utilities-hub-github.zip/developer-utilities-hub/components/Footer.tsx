import Link from "next/link";
import { Heart, Terminal } from "lucide-react";
import { legalLinks, owner, siteConfig, tools } from "@/lib/site";

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="mt-24 border-t border-[var(--border)] bg-[var(--card)]/40">
      <div className="container-shell grid gap-10 py-14 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2.5">
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-gradient-to-br from-[var(--accent)] to-[var(--accent-strong)] text-[var(--accent-ink)]">
              <Terminal size={18} />
            </span>
            <span className="font-extrabold tracking-tight">{siteConfig.name}</span>
          </div>
          <p className="mt-4 max-w-md text-sm leading-8 muted">{siteConfig.description}</p>
          <div className="mt-5 flex flex-wrap gap-2">
            <span className="chip chip-accent">تعمل محلياً</span>
            <span className="chip">بدون تسجيل</span>
            <span className="chip">بدون تحليلات</span>
          </div>
        </div>

        <div>
          <h2 className="text-sm font-bold">الأدوات</h2>
          <ul className="mt-4 grid gap-2.5 text-sm muted">
            {tools.map(tool => (
              <li key={tool.slug}>
                <Link href={tool.href} className="transition hover:text-[var(--accent-strong)]">
                  {tool.title}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/tools" className="transition hover:text-[var(--accent-strong)]">
                كل الأدوات
              </Link>
            </li>
          </ul>
        </div>

        <div>
          <h2 className="text-sm font-bold">الموقع</h2>
          <ul className="mt-4 grid gap-2.5 text-sm muted">
            {legalLinks.map(link => (
              <li key={link.href}>
                <Link href={link.href} className="transition hover:text-[var(--accent-strong)]">
                  {link.label}
                </Link>
              </li>
            ))}
            <li>
              <Link href="/about" className="transition hover:text-[var(--accent-strong)]">
                من نحن
              </Link>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-[var(--border)]">
        <div className="container-shell flex flex-col items-center justify-between gap-3 py-6 text-xs muted md:flex-row">
          <p>
            © {year} {siteConfig.name}. جميع الحقوق محفوظة · {owner.role}:{" "}
            <a
              href={`mailto:${owner.email}`}
              className="font-semibold text-[var(--accent-strong)] hover:underline"
              dir="ltr"
            >
              {owner.email}
            </a>
          </p>
          <p className="flex items-center gap-1.5">
            صُنع بعناية للمطورين
            <Heart size={13} className="text-[var(--accent)]" aria-hidden />
          </p>
        </div>
      </div>
    </footer>
  );
}
