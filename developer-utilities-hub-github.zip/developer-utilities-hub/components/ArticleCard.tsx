import Image from "next/image";
import Link from "next/link";
import { ArrowLeft, Clock } from "lucide-react";
import type { Article } from "@/lib/articles";
import { articleUrl } from "@/lib/articles";

export function ArticleCard({ article, featured = false }: { article: Article; featured?: boolean }) {
  return (
    <Link
      href={articleUrl(article.slug)}
      className="card group overflow-hidden transition hover:-translate-y-1 hover:shadow-[var(--shadow-md)]"
    >
      <div className="relative overflow-hidden">
        <Image
          src={article.cover}
          alt={article.coverAlt}
          width={1600}
          height={900}
          sizes={featured ? "(max-width: 900px) 100vw, 60vw" : "(max-width: 900px) 100vw, 33vw"}
          className="article-cover transition duration-500 group-hover:scale-105"
        />
        <span className="absolute top-3 start-3 rounded-full bg-[var(--card)]/92 px-3 py-1 text-[0.7rem] font-bold text-[var(--accent-strong)] backdrop-blur">
          {article.category}
        </span>
      </div>

      <div className="p-5">
        <h3 className={`font-black leading-snug ${featured ? "text-xl md:text-2xl" : "text-base"}`}>
          {article.title}
        </h3>
        <p className="mt-2.5 text-sm leading-7 muted">{article.excerpt}</p>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 text-xs muted">
          <span className="flex items-center gap-1.5">
            <Clock size={13} aria-hidden />
            {article.readingMinutes} دقائق قراءة
          </span>
          <span className="flex items-center gap-1.5 font-semibold text-[var(--accent-strong)]">
            اقرأ المقال
            <ArrowLeft size={13} aria-hidden />
          </span>
        </div>
      </div>
    </Link>
  );
}
