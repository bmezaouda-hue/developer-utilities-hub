"use client";

import { createContext, useCallback, useContext, useEffect, useState } from "react";
import Link from "next/link";
import { Cookie, ShieldCheck } from "lucide-react";

type ConsentState = "granted" | "denied" | null;

type ConsentContextValue = {
  consent: ConsentState;
  ready: boolean;
  grant: () => void;
  deny: () => void;
};

const STORAGE_KEY = "duh-ads-consent";

const ConsentContext = createContext<ConsentContextValue>({
  consent: null,
  ready: false,
  grant: () => {},
  deny: () => {}
});

export function ConsentProvider({ children }: { children: React.ReactNode }) {
  const [consent, setConsent] = useState<ConsentState>(null);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    const stored = window.localStorage.getItem(STORAGE_KEY);
    setConsent(stored === "granted" || stored === "denied" ? stored : null);
    setReady(true);
  }, []);

  const grant = useCallback(() => {
    window.localStorage.setItem(STORAGE_KEY, "granted");
    setConsent("granted");
  }, []);

  const deny = useCallback(() => {
    window.localStorage.setItem(STORAGE_KEY, "denied");
    setConsent("denied");
  }, []);

  return (
    <ConsentContext.Provider value={{ consent, ready, grant, deny }}>
      {children}
      {ready && consent === null && (
        <div
          role="dialog"
          aria-live="polite"
          aria-label="الموافقة على ملفات تعريف الارتباط"
          className="glass fixed inset-x-0 bottom-0 z-[60] border-t border-[var(--border)] shadow-[var(--shadow-md)]"
        >
          <div className="container-shell flex flex-col gap-4 py-4 sm:flex-row sm:items-center sm:justify-between">
            <p className="flex items-start gap-3 text-xs leading-7 muted sm:items-center">
              <Cookie size={18} className="mt-1 shrink-0 text-[var(--accent-strong)] sm:mt-0" aria-hidden />
              <span>
                نستخدم التخزين المحلي لتذكر مظهر الموقع، وعند الموافقة نستخدم ملفات تعريف ارتباط
                لدى Google لعرض إعلانات وقياسها. لا نستخدم أدوات تحليلات في الموقع حالياً.{" "}
                <Link href="/cookies" className="font-semibold text-[var(--accent-strong)] underline underline-offset-4">
                  سياسة ملفات تعريف الارتباط
                </Link>
              </span>
            </p>
            <div className="flex shrink-0 items-center gap-2">
              <button onClick={deny} className="btn btn-ghost flex-1 sm:flex-none">
                رفض
              </button>
              <button onClick={grant} className="btn btn-primary flex-1 sm:flex-none">
                <ShieldCheck size={15} aria-hidden />
                موافقة
              </button>
            </div>
          </div>
        </div>
      )}
    </ConsentContext.Provider>
  );
}

export const useConsent = () => useContext(ConsentContext);
