import Link from "next/link";
import { ArrowLeft, ShieldCheck, Zap } from "lucide-react";
import { ToolIcon } from "./ToolIcon";
import type { ToolMeta } from "@/lib/site";

export function ToolCard({ tool, compact = false }: { tool: ToolMeta; compact?: boolean }) {
  return (
    <Link
      href={tool.href}
      className="card group relative flex flex-col overflow-hidden p-5 transition duration-200 hover:-translate-y-1 hover:border-[var(--accent)] hover:shadow-[var(--shadow-md)]"
    >
      <span
        className="pointer-events-none absolute -left-10 -top-10 h-28 w-28 rounded-full bg-[var(--accent-soft)] opacity-0 blur-2xl transition-opacity duration-300 group-hover:opacity-100"
        aria-hidden
      />
      <div className="flex items-start justify-between gap-4">
        <span className="grid h-11 w-11 place-items-center rounded-2xl bg-[var(--accent-soft)] text-[var(--accent-strong)] transition-transform duration-200 group-hover:scale-110">
          <ToolIcon name={tool.icon} />
        </span>
        <ArrowLeft
          size={18}
          className="muted transition-transform duration-200 group-hover:-translate-x-1 group-hover:text-[var(--accent-strong)]"
          aria-hidden
        />
      </div>

      <h3 className="mt-5 text-lg font-extrabold">{tool.title}</h3>
      <p className={`mt-2 text-sm leading-8 muted ${compact ? "line-clamp-2" : ""}`}>
        {tool.description}
      </p>

      {!compact && (
        <div className="mt-5 flex flex-wrap items-center gap-2 border-t border-[var(--border)] pt-4 text-[0.7rem] font-semibold text-[var(--muted)]">
          <span className="flex items-center gap-1">
            <Zap size={13} aria-hidden /> فوري
          </span>
          <span className="flex items-center gap-1">
            <ShieldCheck size={13} aria-hidden /> محلي 100%
          </span>
        </div>
      )}
    </Link>
  );
}
