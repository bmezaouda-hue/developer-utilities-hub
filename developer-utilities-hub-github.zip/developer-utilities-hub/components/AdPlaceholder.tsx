export function AdPlaceholder({
  label = "مساحة إعلانية",
  format = "horizontal"
}: {
  label?: string;
  format?: "horizontal" | "rectangle";
}) {
  return (
    <aside className="ad-placeholder my-6" aria-label={label}>
      <span className="flex flex-col items-center gap-1 px-4">
        <span className="text-[0.7rem] font-bold tracking-wide uppercase opacity-80">{label}</span>
        <span className="text-[0.65rem]">
          مساحة إعلانية — تُفعَّل بعد موافقة AdSense
          {format === "rectangle" ? " · 300×250" : " · responsive"}
        </span>
      </span>
    </aside>
  );
}
