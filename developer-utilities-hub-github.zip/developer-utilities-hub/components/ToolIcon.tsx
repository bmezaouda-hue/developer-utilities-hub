import { Braces, Code2, type LucideIcon } from "lucide-react";

const registry: Record<string, LucideIcon> = {
  braces: Braces,
  code: Code2
};

export function ToolIcon({ name, size = 20 }: { name: string; size?: number }) {
  const Icon = registry[name] ?? Braces;
  return <Icon size={size} aria-hidden />;
}
