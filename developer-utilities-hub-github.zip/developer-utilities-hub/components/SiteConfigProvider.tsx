"use client";

import { createContext, useContext, useEffect, useMemo, useState } from "react";
import Link from "next/link";
import { Megaphone, X } from "lucide-react";
import type { PublicConfig } from "@/lib/admin/types";

const FALLBACK: PublicConfig = {
  settings: {
    ownerName: "",
    contactEmail: "",
    siteUrl: "",
    announcement: { enabled: false, text: "", link: "" },
    maintenance: { enabled: false, message: "" },
    adsEnabled: true,
    trackVisits: true
  },
  tools: {}
};

const SiteConfigContext = createContext<PublicConfig>(FALLBACK);

export function SiteConfigProvider({ children }: { children: React.ReactNode }) {
  const [config, setConfig] = useState<PublicConfig>(FALLBACK);

  useEffect(() => {
    let active = true;
    fetch("/api/config", { cache: "no-store" })
      .then(response => (response.ok ? response.json() : null))
      .then((data: PublicConfig | null) => {
        if (active && data?.settings) setConfig(data);
      })
      .catch(() => undefined);
    return () => {
      active = false;
    };
  }, []);

  const value = useMemo(() => config, [config]);

  return (
    <SiteConfigContext.Provider value={value}>
      {children}
      <AnnouncementBar config={value} />
      {config.settings.maintenance.enabled && <MaintenanceOverlay config={value} />}
    </SiteConfigContext.Provider>
  );
}

function AnnouncementBar({ config }: { config: PublicConfig }) {
  const [dismissed, setDismissed] = useState(false);
  const { announcement } = config.settings;

  useEffect(() => {
    if (dismissed) {
      window.sessionStorage.setItem("duh-announcement-dismissed", announcement.text);
    }
  }, [announcement.text, dismissed]);

  if (!announcement.enabled || !announcement.text || dismissed) return null;

  return (
    <div className="border-b border-[var(--border)] bg-[var(--accent-soft)]">
      <div className="container-shell flex items-center gap-3 py-2.5 text-xs">
        <Megaphone size={15} className="shrink-0 text-[var(--accent-strong)]" aria-hidden />
        <p className="flex-1 leading-6">
          {announcement.link ? (
            <Link
              href={announcement.link}
              className="font-semibold text-[var(--accent-strong)] underline underline-offset-4"
            >
              {announcement.text}
            </Link>
          ) : (
            announcement.text
          )}
        </p>
        <button
          onClick={() => setDismissed(true)}
          aria-label="إخفاء التنبيه"
          className="rounded-lg p-1.5 text-[var(--muted)] transition hover:bg-[var(--card)] hover:text-[var(--foreground)]"
        >
          <X size={15} />
        </button>
      </div>
    </div>
  );
}

function MaintenanceOverlay({ config }: { config: PublicConfig }) {
  const { maintenance } = config.settings;
  return (
    <div className="fixed inset-0 z-[70] grid place-items-center bg-[var(--background)]/95 px-4 backdrop-blur">
      <div className="card max-w-lg p-8 text-center">
        <h1 className="text-2xl font-black tracking-tight">الموقع تحت الصيانة</h1>
        <p className="mt-4 leading-8 muted">
          {maintenance.message || "نعمل على تحسين الأدوات. سنعود قريباً."}
        </p>
        <p className="mt-6 text-xs muted">
          إن كنت تحتاج أداة الآن، راسلنا على{" "}
          <a
            href={`mailto:${config.settings.contactEmail}`}
            className="font-semibold text-[var(--accent-strong)]"
            dir="ltr"
          >
            {config.settings.contactEmail}
          </a>
        </p>
      </div>
    </div>
  );
}

export const useSiteConfig = () => useContext(SiteConfigContext);
