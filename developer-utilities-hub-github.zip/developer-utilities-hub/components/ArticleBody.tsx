import { AlertTriangle, Info, Lightbulb } from "lucide-react";
import type { ArticleBlock } from "@/lib/articles";

const toneMap = {
  tip: { icon: Lightbulb, label: "نصيحة" },
  warn: { icon: AlertTriangle, label: "انتبه" },
  info: { icon: Info, label: "معلومة" }
} as const;

export function ArticleBody({ blocks }: { blocks: ArticleBlock[] }) {
  return (
    <div className="article-body">
      {blocks.map((block, index) => {
        const key = `${block.type}-${index}`;

        switch (block.type) {
          case "p":
            return <p key={key}>{block.text}</p>;

          case "h2":
            return (
              <h2 key={key} id={block.id}>
                {block.text}
              </h2>
            );

          case "h3":
            return (
              <h3 key={key} id={block.id}>
                {block.text}
              </h3>
            );

          case "ul":
            return (
              <ul key={key}>
                {block.items.map(item => (
                  <li key={item}>{item}</li>
                ))}
              </ul>
            );

          case "ol":
            return (
              <ol key={key}>
                {block.items.map(item => (
                  <li key={item}>{item}</li>
                ))}
              </ol>
            );

          case "code":
            return (
              <div key={key} className="code-block">
                <header>
                  <span>{block.file ?? block.lang}</span>
                  <span>{block.lang}</span>
                </header>
                <pre>
                  <code>{block.code}</code>
                </pre>
              </div>
            );

          case "callout": {
            const tone = toneMap[block.tone];
            return (
              <aside key={key} className="callout">
                <p className="flex items-center gap-2 font-black">
                  <tone.icon size={16} aria-hidden />
                  {block.title}
                  <span className="sr-only">{tone.label}</span>
                </p>
                <p>{block.text}</p>
              </aside>
            );
          }

          case "table":
            return (
              <div key={key} className="overflow-x-auto">
                <table className="data-table">
                  <thead>
                    <tr>
                      {block.head.map(cell => (
                        <th key={cell}>{cell}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {block.rows.map(row => (
                      <tr key={row.join("-")}>
                        {row.map(cell => (
                          <td key={cell}>{cell}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            );

          default:
            return null;
        }
      })}
    </div>
  );
}
