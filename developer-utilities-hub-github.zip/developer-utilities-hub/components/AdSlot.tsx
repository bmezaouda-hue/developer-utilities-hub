"use client";

import { useSiteConfig } from "./SiteConfigProvider";
import { AdPlaceholder } from "./AdPlaceholder";
import { AdSenseSlot } from "./AdSenseSlot";
import { adsense } from "@/lib/site";

export function AdSlot({
  label,
  format = "horizontal",
  slot
}: {
  label: string;
  format?: "horizontal" | "rectangle";
  slot?: string;
}) {
  const { settings } = useSiteConfig();
  const enabled = adsense.enabled && settings.adsEnabled;

  if (!enabled) {
    return <AdPlaceholder label={label} format={format} />;
  }

  return (
    <AdSenseSlot
      label={label}
      slot={slot}
      format={format === "rectangle" ? "rectangle" : "auto"}
    />
  );
}
