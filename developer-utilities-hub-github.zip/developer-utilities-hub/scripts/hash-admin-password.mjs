#!/usr/bin/env node
import { randomBytes, scryptSync } from "node:crypto";

const password = process.argv[2] ?? process.env.ADMIN_PASSWORD;

if (!password) {
  console.error("الاستخدام: node scripts/hash-admin-password.mjs \"كلمة-المرور\"");
  console.error("أو: ADMIN_PASSWORD=\"كلمة-المرور\" node scripts/hash-admin-password.mjs");
  process.exit(1);
}

if (password.length < 10) {
  console.error("خطأ: كلمة المرور يجب أن تكون 10 أحرف على الأقل.");
  process.exit(1);
}

const salt = randomBytes(16).toString("hex");
const digest = scryptSync(password, salt, 64).toString("hex");

console.log("\nأضف السطر التالي إلى متغيرات البيئة (Netlify أو .env.local):\n");
console.log(`ADMIN_PASSWORD_HASH=${salt}:${digest}`);
console.log("\nوثبّت ADMIN_SESSION_SECRET بقيمة عشوائية طويلة، مثل:");
console.log(`ADMIN_SESSION_SECRET=${randomBytes(32).toString("hex")}\n`);
